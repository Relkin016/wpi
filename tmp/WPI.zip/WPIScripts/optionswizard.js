//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// Windows Post - Install Wizard
// optionswizard.js
//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

// Temporary solution
var FoundOldStyle = false;

function OptionsUpdated()
{
   position = "optionswizard.js";
   whatfunc = "OptionsUpdated()";

   isOptionsSaved = false;
}

function CreateOptionsPage()
{
   position = "optionswizard.js";
   whatfunc = "CreateOptionsPage()";

   var zone = 0;

   OptionsWindow = dhxWins.createWindow("OptionsWindow", 50, 50, 700, 515);
   OptionsWindow.setText(getText(lblOptionsWizard));
   OptionsWindow.setModal(true);
   OptionsWindow.button("park").hide();
   OptionsWindow.button("minmax1").hide();
   OptionsWindow.button("close").hide();
   OptionsWindow.keepInViewport(true);
   OptionsWindow.denyResize();
   OptionsWindow.center();
   ActiveWindow = OptionsWindow.getText();
   BlockWindow = "OptionsWindow";

   StatusBar = OptionsWindow.attachStatusBar();

   var newDiv = document.createElement("div");
   var objDiv = document.getElementById("layergroup");

   newDiv.id = "layeroptions";
   newDiv.style.display = "none";
   newDiv.style.overflow = "auto";
   newDiv.style.width = "100%";
   newDiv.style.height = "100%";
   newDiv.style.padding = "10px";

   objDiv.appendChild(newDiv);

   OptionsWindow.attachObject("layeroptions");
   document.getElementById("layeroptions").style.visibility = 'hidden';

   CreateTab("\\Common\\optionswizardtemplate.htm", "layeroptions");
   CreateTab("\\Common\\optionswizardtemplate_window.htm", "tabtabWindow");
   CreateTab("\\Common\\optionswizardtemplate_general.htm", "tabtabGeneral");
   CreateTab("\\Common\\optionswizardtemplate_features.htm", "tabtabFeatures");
   CreateTab("\\Common\\optionswizardtemplate_tools.htm", "tabtabTools");
   CreateTab("\\Common\\optionswizardtemplate_audio.htm", "tabtabAudioPlayer");
   CreateTab("\\Common\\optionswizardtemplate_sounds.htm", "tabtabSounds");

   optionsTabs = new dhtmlXTabBar("OptionsTabs", "top");
   optionsTabs.setImagePath("../common/codebase/imgs/");
   optionsTabs.setStyle(dhxSkin);
   optionsTabs.enableForceHiding(true);
   var tablist = new Array('tabWindow', 'tabGeneral', 'tabFeatures', 'tabTools', 'tabAudioPlayer', 'tabSounds');
   for (var i = 0; i < tablist.length; i ++ )
   {
      optionsTabs.addTab("Tab" + (i + 1).toString(), getText(eval(tablist[i])), "" + Math.round((parseInt(document.getElementById("OptionsTabs").offsetWidth) - 16) / tablist.length) + "px");
   }

   LocalizeOptionsTexts();

   CreateLanguageCombo();

   AudioGrid = new dhtmlXGridObject('AudioGrid');
   AudioGrid.setImagePath("../common/codebase/imgs/");
   AudioGrid.setSkin(dhxSkin);
   AudioGrid.setHeader(getText(lblInstallFilesToPlay));
   AudioGrid.setInitWidths("*");
   AudioGrid.setColAlign("left");
   AudioGrid.setColTypes("ro");
   AudioGrid.setColSorting("str");
   AudioGrid.enableMultiselect(false);
   AudioGrid.enableMultiline(false);
   AudioGrid.enableKeyboardSupport(true);
   AudioGrid.enableDragAndDrop(true);
   AudioGrid.init();
   AudioGrid.objBox.style.overflowX = "hidden";

   VolumeSlider = new dhtmlxSlider("Install_Volume", 200, dhxSkin, false, 0, 100, Volume, 1);
   VolumeSlider.setImagePath("../common/codebase/imgs/");
   VolumeSlider.attachEvent("onChange", SetVolumeValue);
   VolumeSlider.init();

   for (var i = 0; i < tablist.length; i ++ )
   {
      optionsTabs.setContent("Tab" + (i + 1).toString(), "tab" + tablist[i]);
   }

   optionsTabs.setTabActive('Tab1');

   document.getElementById("layeroptions").style.visibility = 'visible';
   document.getElementById("layeroptions").style.display = 'block';
}

function LocalizeOptionsTexts()
{
   position = "optionswizard.js";
   whatfunc = "LocalizeOptionsTexts()";

   with (document)
   {
      getElementById("legWindowOptions").innerHTML = getText(lblWindowOptions);
      getElementById("lblShowWindowBorder").innerHTML = getText(lblShowWindowBorder);
      getElementById("legBorderType").innerHTML = getText(lblBorderType);
      getElementById("lblInnerBorder").innerHTML = getText(lblInnerBorder);
      getElementById("legBorderStyle").innerHTML = getText(lblBorderStyle);
      getElementById("legTitleBar").innerHTML = getText(lblTitleBar);
      getElementById("lblShowTitleBar").innerHTML = getText(lblShowTitleBar);
      getElementById("lblSysMenuEnabled").innerHTML = getText(lblSysMenuEnabled);
      getElementById("lblMinimizeEnabled").innerHTML = getText(lblMinimizeEnabled);
      getElementById("legStartingWindowState").innerHTML = getText(lblStartingWindowState);
      getElementById("lblShowInTaskBar").innerHTML = getText(lblShowInTaskBar);
      getElementById("legWindowCoordinates").innerHTML = getText(lblWindowCoordinates);
      getElementById("legMainWindow").innerHTML = getText(lblMainWindow);
      getElementById("lblWindowResolution").innerHTML = getText(lblWindowResolution);
      getElementById("lblMainWindowWidth").innerHTML = getText(lblMainWindowWidth);
      getElementById("lblMainWindowHeight").innerHTML = getText(lblMainWindowHeight);
      getElementById("lblOpenWindowAtXCoord1").innerHTML = getText(lblOpenWindowAtXCoord);
      getElementById("txtNegOneToCenter1").innerHTML = getText(txtNegOneToCenter);
      getElementById("lblOpenWindowAtYCoord1").innerHTML = getText(lblOpenWindowAtYCoord);
      getElementById("txtNegOneToCenter2").innerHTML = getText(txtNegOneToCenter);
      getElementById("legInstallerWindow").innerHTML = getText(lblInstallerWindow);
      getElementById("lblOpenWindowAtXCoord2").innerHTML = getText(lblOpenWindowAtXCoord);
      getElementById("txtNegOneToCenter3").innerHTML = getText(txtNegOneToCenter);
      getElementById("lblOpenWindowAtYCoord2").innerHTML = getText(lblOpenWindowAtYCoord);
      getElementById("txtNegOneToCenter4").innerHTML = getText(txtNegOneToCenter);
      getElementById("legNumberOfColumns").innerHTML = getText(lblNumberOfColumns);
      getElementById("legTimer").innerHTML = getText(lblTimer);
      getElementById("lblUseCountDownTimer").innerHTML = getText(lblUseCountDownTimer);
      getElementById("txtCountDownTimerSecs").innerHTML = getText(txtSeconds);
      getElementById("lblStartBeepAtTMinus").innerHTML = getText(lblStartBeepAtTMinus);
      getElementById("txtStartBeepAtSecs").innerHTML = getText(txtSeconds);
      getElementById("legLanguage").innerHTML = getText(lblLanguage);
      getElementById("legDefaultInstallPath").innerHTML = getText(legDefaultInstallPath);
      getElementById("legInstallationError").innerHTML = getText(legInstallationError);
      getElementById("lblAbortInstallIfFailure").innerHTML = getText(lblAbortInstallIfFailure);
      getElementById("lblExecuteCommandIfFailure").innerHTML = getText(lblExecuteCommandIfFailure);
      getElementById("lblContinueWhereFailed").innerHTML = getText(lblContinueWhereFailed);
      getElementById("legFeatures").innerHTML = getText(legFeatures);
      getElementById("lblShowExtraButtons").innerHTML = getText(lblShowExtraButtons);
      getElementById("lblDoNotShowIfCD").innerHTML = getText(lblDoNotShowIfCD);
      getElementById("lblUSSFSilentMode").innerHTML = getText(lblUSSFSilentMode);
      getElementById("lblVerifyInstallHDD").innerHTML = getText(lblVerifyInstallHDD);
      getElementById("lblAllowCheckForInternet").innerHTML = getText(lblAllowCheckForInternet);
      getElementById("lblLoadDesktopBeforeIns").innerHTML = getText(lblLoadDesktopBeforeIns);
      getElementById("lblReOpenAfterInstall").innerHTML = getText(lblReOpenAfterInstall);
      getElementById("lblDisableCatCheckBox").innerHTML = getText(lblDisableCatCheckBox);
      getElementById("lblSortWithinCats").innerHTML = getText(lblSortWithinCats);
      getElementById("lblDisableDepsNotMet").innerHTML = getText(lblDisableDepsNotMet);
      getElementById("lblShowScrollBar").innerHTML = getText(lblShowScrollBar);
      getElementById("lblNoColumnBreak").innerHTML = getText(lblNoColumnBreak);
      getElementById("lblInstallByCategory").innerHTML = getText(lblInstallByCategory);
      getElementById("lblForceInstallOnExit").innerHTML = getText(lblForceInstallOnExit);
      getElementById("lblDisableIfDoGray").innerHTML = getText(lblDisableIfDoGray);
      getElementById("txtInstallFonts").innerHTML = getText(txtInstallFonts);
      getElementById("lblShowCommandInInstaller").innerHTML = getText(lblShowCommandInInstaller);
      getElementById("lblShowInstallerImages").innerHTML = getText(lblShowInstallerImages);
      getElementById("lblAlwaysShowOutputWindow").innerHTML = getText(lblAlwaysShowOutputWindow);
      getElementById("lblEjectCDWhenDone").innerHTML = getText(lblEjectCDWhenDone);
      getElementById("lblDoNotShowIfUSB").innerHTML = getText(lblDoNotShowIfUSB);
      getElementById("lblDisableHotKeys").innerHTML = getText(lblDisableHotKeys);
      getElementById("lblShowDownloadOutput").innerHTML = getText(lblShowDownloadOutput);
      getElementById("lblDisableInstallCombobox").innerHTML = getText(lblDisableInstallCombobox);
      getElementById("lblMaintainAutoLogonCount").innerHTML = getText(lblMaintainAutoLogonCount);
      getElementById("legExecuteBefore").innerHTML = getText(lblExecuteBefore);
      getElementById("txtExecuteBefore").innerHTML = getText(txtExecuteBefore);
      getElementById("legExecuteAfter").innerHTML = getText(lblExecuteAfter);
      getElementById("txtExecuteAfter").innerHTML = getText(txtExecuteAfter);
      getElementById("legRestartComputer").innerHTML = getText(lblRestartComputer);
      getElementById("txtRestartComputer").innerHTML = getText(txtRestartComputer);
      getElementById("legRestartComputerType").innerHTML = getText(lblRestartComputerType);
      getElementById("radioRestart").innerHTML = getText(optRestart);
      getElementById("radioShutDown").innerHTML = getText(optShutDown);
      getElementById("legRestartDelay").innerHTML = getText(lblRestartDelay);
      getElementById("txtSeconds").innerHTML = getText(txtSeconds);
      getElementById("legDoNotLoadDesktop").innerHTML = getText(lblDoNotLoadDesktop);
      getElementById("txtDoNotLoadDesktop").innerHTML = getText(txtDoNotLoadDesktop);
      getElementById("legLogInstallProcess").innerHTML = getText(lblLogInstallProcess);
      getElementById("txtLogInstallProcess").innerHTML = getText(txtLogInstallProcess);
      getElementById("lblTimeStampLogFile").innerHTML = getText(lblTimeStampLogFile);
      getElementById("legInsAudioPlayer").innerHTML = getText(legAudioPlayer);
      getElementById("lblShowInstallAP").innerHTML = getText(lblShowInstallAP);
      getElementById("legInsControlsAudio").innerHTML = getText(lblControls);
      getElementById("Install_AudioAdd").innerHTML = getText(btnAdd);
      getElementById("Install_AudioDelete").innerHTML = getText(btnDelete);
      getElementById("lblVolume").innerHTML = getText(lblVolume);
      getElementById("lblShuffleAudio").innerHTML = getText(lblShuffle);
      getElementById("legCopyAudio").innerHTML = getText(legCopyAudio);
      getElementById("lblCopyAudioFolderToHD").innerHTML = getText(lblCopyAudioFolderToHD);
      getElementById("lblDeleteAudioFolder").innerHTML = getText(lblDeleteAudioFolder);
      getElementById("legSoundsScheme").innerHTML = getText(legSoundsScheme);
      getElementById("lblSndWPIStart").innerHTML = getText(lblSndWPIStart);
      getElementById("lblSndInstallStart").innerHTML = getText(lblSndInstallStart);
      getElementById("lblSndInstallSuccess").innerHTML = getText(lblSndInstallSuccess);
      getElementById("lblSndInstallWarning").innerHTML = getText(lblSndInstallWarning);
      getElementById("lblSndInstallFail").innerHTML = getText(lblSndInstallFail);
      getElementById("lblSndInstallFinish").innerHTML = getText(lblSndInstallFinish);
      getElementById("lblSndWPIExit").innerHTML = getText(lblSndWPIExit);
      getElementById("optionsNewOptions").innerHTML = getText(btnNewOptions);
      getElementById("optionsRead").innerHTML = getText(btnRead);
      getElementById("optionsSave").innerHTML = getText(btnSave);
      getElementById("optionsSaveAs").innerHTML = getText(btnSaveAs);
      getElementById("optionsExit").innerHTML = getText(btnExit);

      with (getElementById("BorderType"))
      {
         options[0].text = getText(optBorderTypeThick);
         options[1].text = getText(optBorderTypeThin);
         options[2].text = getText(optBorderTypeDialog);
      }
      with (getElementById("BorderStyle"))
      {
         options[0].text = getText(optBorderStyleNormal);
         options[1].text = getText(optBorderStyleComplex);
         options[2].text = getText(optBorderStyleRaised);
         options[3].text = getText(optBorderStyleStatic);
         options[4].text = getText(optBorderStyleSunken);
      }
      with (getElementById("StartingWindowState"))
      {
         options[0].text = getText(optWindowStateNormal);
         options[1].text = getText(optWindowStateMinimized);
         options[2].text = getText(optWindowStateMaximized);
      }

      getElementById("Resolution").options[0].text = getText(optBySystemDefault);
      var opt = getElementById("Resolution").getElementsByTagName("OPTGROUP");
      opt[0].label = getText(optStandard);
      opt[1].label = getText(optWidescreen);
      getElementById("Resolution").options[14].text = getText(optCustom);

      with (getElementById("DefaultInstallPath"))
      {
         options[0].text = getText(optBySystemDefault);
         options[4].text = getText(optCustom);
      }

      document.getElementById("VolumeValue").innerHTML = Volume;

   }
}

function HandleShowWindowBorderSelection()
{
   position = "optionswizard.js";
   whatfunc = "HandleShowWindowBorderSelection()";

   if (document.getElementById("ShowWindowBorder").checked)
   {
      document.getElementById("BorderType").disabled = false;
      document.getElementById("InnerBorder").disabled = false;
      document.getElementById("BorderStyle").disabled = false;
      document.getElementById("ShowTitleBar").disabled = false;
      HandleShowTitleBarSelection();
      document.getElementById("StartingWindowState").disabled = false;
      document.getElementById("ShowInTaskBar").disabled = false;
   }
   else
   {
      document.getElementById("BorderType").disabled = true;
      document.getElementById("InnerBorder").disabled = true;
      document.getElementById("BorderStyle").disabled = true;
      document.getElementById("ShowTitleBar").disabled = true;
      document.getElementById("SysMenuEnabled").disabled = true;
      document.getElementById("MinimizeEnabled").disabled = true;
      document.getElementById("StartingWindowState").disabled = true;
      document.getElementById("ShowInTaskBar").disabled = true;
   }
}

function HandleShowTitleBarSelection()
{
   position = "optionswizard.js";
   whatfunc = "HandleShowTitleBarSelection()";

   if (document.getElementById("ShowTitleBar").checked)
   {
      document.getElementById("SysMenuEnabled").disabled = false;
      HandleSysMenuEnabledSelection();
   }
   else
   {
      document.getElementById("SysMenuEnabled").disabled = true;
      document.getElementById("MinimizeEnabled").disabled = true;
   }
}

function HandleSysMenuEnabledSelection()
{
   position = "optionswizard.js";
   whatfunc = "HandleSysMenuEnabledSelection()";

   if (document.getElementById("SysMenuEnabled").checked)
   {
      document.getElementById("MinimizeEnabled").disabled = false;
   }
   else
   {
      document.getElementById("MinimizeEnabled").disabled = true;
   }
}

function HandleWindowResolution()
{
   position = "optionswizard.js";
   whatfunc = "HandleWindowResolution()";

   var idx = document.getElementById("Resolution").selectedIndex;
   var selRes = document.getElementById("Resolution").options[idx].value;

   if (selRes == 1)
   {
      document.getElementById("MainWindowWidth").disabled = false;
      document.getElementById("MainWindowHeight").disabled = false;
   }
   else
   {
      document.getElementById("MainWindowWidth").disabled = true;
      document.getElementById("MainWindowHeight").disabled = true;
   }
}

function HandleShowExtraButtonsSelection()
{
   position = "optionswizard.js";
   whatfunc = "HandleShowExtraButtonsSelection()";
}

function HandleTimerSelection()
{
   position = "optionswizard.js";
   whatfunc = "HandleTimerSelection()";

   if (document.getElementById("Timer").checked)
   {
      document.getElementById("Seconds").disabled = false;
      document.getElementById("StartBeepAtSecs").disabled = false;
   }
   else
   {
      document.getElementById("Seconds").disabled = true;
      document.getElementById("StartBeepAtSecs").disabled = true;
   }
}

function HandleStartBeepAt()
{
   position = "optionswizard.js";
   whatfunc = "HandleStartBeepAt()";

   StartBeepAtSecs = document.getElementById("StartBeepAtSecs").value;
   if (StartBeepAtSecs < 0)
   StartBeepAtSecs = 0;
   if (StartBeepAtSecs > document.getElementById("Seconds").value)
   StartBeepAtSecs = document.getElementById("Seconds").value;

   document.getElementById("StartBeepAtSecs").value = StartBeepAtSecs;
}

function HandleLanguageSelection()
{
   position = "optionswizard.js";
   whatfunc = "HandleLanguageSelection()";

   var sellang = LanguageCombo.getSelectedValue();

   if (sellang == 'zz')
   sellang = (navigator.language ? navigator.language : navigator.userLanguage).substr(0, 2);
   var file = "\\Lang\\lang_" + sellang + ".js";

   if ( ! FileExists(wpipath + file))
   {
      sellang = 'en';
      Alert("", getText(NoLanguageFile), getText(lblOK), "", 2, 0, 0, 0);
   }
   else
   {
      if (CheckLanguageFile(sellang, file) != '')
      {
         lang = sellang;
         Language = lang;
      }
   }

   OptionsUpdated();
}

function HandleDefaultInstallPath()
{
   position = "optionswizard.js";
   whatfunc = "HandleDefaultInstallPath()";

   DefaultInstallPath = document.getElementById("DefaultInstallPath").value;

   if (document.getElementById("DefaultInstallPath").value == "custom")
   document.getElementById("CustomInstallPath").disabled = false;
   else
   document.getElementById("CustomInstallPath").disabled = true;
}

function FocusDefaultInstallPath()
{
   position = "optionswizard.js";
   whatfunc = "FocusDefaultInstallPath()";

   if (document.getElementById("DefaultInstallPath").value == "custom")
   {
      document.getElementById('CustomInstallPath').focus();
      moveCaretToEnd(this.document.all.CustomInstallPath);
   }
}

function HandleCustomInstallPath()
{
   position = "optionswizard.js";
   whatfunc = "HandleCustomInstallPath()";

   var txt = document.getElementById("CustomInstallPath").value;

   if (txt.charAt(txt.length - 1) == "\\")
   {
      txt = txt.substring(0, txt.length - 1);
      document.getElementById("CustomInstallPath").value = txt;
   }
}

function HandleAbortInstallIfFailureSelection()
{
   position = "optionswizard.js";
   whatfunc = "HandleAbortInstallIfFailureSelection()";

   if (document.getElementById("AbortInstallIfFailure").checked)
   {
      document.getElementById("ExecuteCommandIfFailure").disabled = false;
      document.getElementById("ExecuteCommandIfFailureShow").style.display = 'block';
      document.getElementById("ExecuteCommandIfFailureHide").style.display = 'none';
      document.getElementById("ContinueWhereFailed").disabled = false;
   }
   else
   {
      document.getElementById("ExecuteCommandIfFailure").disabled = true;
      document.getElementById("ExecuteCommandIfFailureShow").style.display = 'none';
      document.getElementById("ExecuteCommandIfFailureHide").style.display = 'block';
      document.getElementById("ContinueWhereFailed").disabled = true;
   }
}

function clearExecuteCommandIfFailureBrowse()
{
   position = "optionswizard.js";
   whatfunc = "clearExecuteCommandIfFailureBrowse()";

   document.getElementById("div_ExecuteCommandIfFailureBrowse").innerHTML = "";
   document.getElementById("div_ExecuteCommandIfFailureBrowse").innerHTML = '<input id="ExecuteCommandIfFailureBrowse" type="file" style="display:none;">';
}

function SetExecuteCommandIfFailurePath()
{
   position = "optionswizard.js";
   whatfunc = "SetExecuteCommandIfFailurePath()";

   if (document.getElementById("ExecuteCommandIfFailureBrowse").value != "")
   {
      tempName = document.getElementById("ExecuteCommandIfFailureBrowse").value;

      if (theStart = tempName.indexOf(":") != - 1)
      tempName = trimString(tempName);

      document.getElementById("ExecuteCommandIfFailure").value = tempName;
   }
}

function HandleExecuteBeforeSelection()
{
   position = "optionswizard.js";
   whatfunc = "HandleExecuteBeforeSelection()";

   if (document.getElementById("ExecuteBeforeEnabled").checked)
   {
      document.getElementById("ExecuteBefore").disabled = false;
      document.getElementById("ExecuteBeforeShow").style.display = 'block';
      document.getElementById("ExecuteBeforeHide").style.display = 'none';
   }
   else
   {
      document.getElementById("ExecuteBefore").disabled = true;
      document.getElementById("ExecuteBeforeShow").style.display = 'none';
      document.getElementById("ExecuteBeforeHide").style.display = 'block';
   }
}

function clearExecuteBeforeBrowse()
{
   position = "optionswizard.js";
   whatfunc = "clearExecuteBeforeBrowse()";

   document.getElementById("div_ExecuteBeforeBrowse").innerHTML = "";
   document.getElementById("div_ExecuteBeforeBrowse").innerHTML = '<input id="ExecuteBeforeBrowse" type="file" style="display:none;">';
}

function SetExecuteBeforePath()
{
   position = "optionswizard.js";
   whatfunc = "SetExecuteBeforePath()";

   if (document.getElementById("ExecuteBeforeBrowse").value != "")
   {
      tempName = document.getElementById("ExecuteBeforeBrowse").value;

      if (theStart = tempName.indexOf(":") != - 1)
      tempName = trimString(tempName);

      document.getElementById("ExecuteBefore").value = tempName;
   }
}

function HandleExecuteAfterSelection()
{
   position = "optionswizard.js";
   whatfunc = "HandleExecuteAfterSelection()";

   if (document.getElementById("ExecuteAfterEnabled").checked)
   {
      document.getElementById("ExecuteAfter").disabled = false;
      document.getElementById("ExecuteAfterShow").style.display = 'block';
      document.getElementById("ExecuteAfterHide").style.display = 'none';
   }
   else
   {
      document.getElementById("ExecuteAfter").disabled = true;
      document.getElementById("ExecuteAfterShow").style.display = 'none';
      document.getElementById("ExecuteAfterHide").style.display = 'block';
   }
}

function clearExecuteAfterBrowse()
{
   position = "optionswizard.js";
   whatfunc = "clearExecuteAfterBrowse()";

   document.getElementById("div_ExecuteAfterBrowse").innerHTML = "";
   document.getElementById("div_ExecuteAfterBrowse").innerHTML = '<input id="ExecuteAfterBrowse" type="file" style="display:none;">';
}

function SetExecuteAfterPath()
{
   position = "optionswizard.js";
   whatfunc = "SetExecuteAfterPath()";

   if (document.getElementById("ExecuteAfterBrowse").value != "")
   {
      tempName = document.getElementById("ExecuteAfterBrowse").value;

      if (theStart = tempName.indexOf(":") != - 1)
      tempName = trimString(tempName);

      document.getElementById("ExecuteAfter").value = tempName;
   }
}

function HandleRestartComputerSelection()
{
   position = "optionswizard.js";
   whatfunc = "HandleRestartComputerSelection()";

   if (document.getElementById("RestartComputer").checked)
   {
      document.getElementById("RestartType0").disabled = false;
      document.getElementById("RestartType1").disabled = false;
      document.getElementById("RestartSeconds").disabled = false;
      document.getElementById("DoNotLoadDesktop").disabled = false;
   }
   else
   {
      document.getElementById("RestartType0").disabled = true;
      document.getElementById("RestartType1").disabled = true;
      document.getElementById("RestartSeconds").disabled = true;
      document.getElementById("DoNotLoadDesktop").disabled = true;
   }
}

function HandleLogInstallationSelection()
{
   position = "optionswizard.js";
   whatfunc = "HandleLogInstallationSelection()";

   if (document.getElementById("LogInstallation").checked)
   {
      document.getElementById("LogPath").disabled = false;
      document.getElementById("LogPathAddShow").style.display = 'block';
      document.getElementById("LogPathAddHide").style.display = 'none';

      if (document.getElementById("LogPath").value == "")
      document.getElementById("LogPath").value = DefaultLogPath;
   }
   else
   {
      document.getElementById("LogPath").disabled = true;
      document.getElementById("LogPathAddShow").style.display = 'none';
      document.getElementById("LogPathAddHide").style.display = 'block';
   }
}

function clearLogPathBrowse()
{
   position = "optionswizard.js";
   whatfunc = "clearLogPathBrowse()";

   document.getElementById("div_LogPathBrowse").innerHTML = "";
   document.getElementById("div_LogPathBrowse").innerHTML = '<input id="LogPathBrowse" type="file" style="display:none;">';
}

function SetLogPathPath()
{
   position = "optionswizard.js";
   whatfunc = "SetLogPathPath()";

   if (document.getElementById("LogPathBrowse").value != "")
   document.getElementById("LogPath").value = '"'+document.getElementById("LogPathBrowse").value+'"';
}

function QuoteLogPathPath()
{
   position = "optionswizard.js";
   whatfunc = "QuoteLogPathPath()";

   var str;

   if (document.getElementById("LogPath").value != "")
   {
      str = document.getElementById("LogPath").value;
      if (str.substr(0, 1) != '"')
      str = '"'+str+'"';
      document.getElementById("LogPath").value = str;
   }
}

function ToggleAudioControlGadgets()
{
   position = "optionswizard.js";
   whatfunc = "ToggleAudioControlGadgets()";

   var state = false;

   if (AudioGrid.getRowsNum() < 2)
   state = true;

   document.getElementById("Btn_Install_AudioAdd").disabled = false;
   document.getElementById("Btn_Install_AudioDelete").disabled = AudioGrid.getRowsNum() == 0 ? true : false;
   document.getElementById("ShuffleAudio").disabled = false;
   document.getElementById("CopyAudioFolder").disabled = false;

   HandleCopyAudioFolder();
}

function PopulateAudioGrid()
{
   position = "optionswizard.js";
   whatfunc = "PopulateAudioGrid()";

   AudioGrid.clearAll();
   Songs.splice(0, Songs.length);

   if (InstallAudio.length < 1)
   return;

   Songs = InstallAudio.split(",");
   for (var i = 0; i < Songs.length; i ++ )
   AudioGrid.addRow(i, [Songs[i]]);

   AudioGrid.selectRow(0, false, false, true);
}

function HandlePlayInstallAudioSelection()
{
 position="optionswizard.js";
 whatfunc="HandlePlayInstallAudioSelection()";

   if (document.getElementById("PlayAudioInInstaller").checked)
   ToggleAudioControlGadgets();
   else
   {
      document.getElementById("Btn_Install_AudioAdd").disabled = true;
      document.getElementById("Btn_Install_AudioDelete").disabled = true;
      document.getElementById("Install_Volume").disabled = true;
      document.getElementById("ShuffleAudio").disabled = true;
      document.getElementById("CopyAudioFolder").disabled = true;
      document.getElementById("CopyAudioPath").disabled = true;
      document.getElementById("DeleteAudioFolder").disabled = true;
   }
}

function clearInstallAudioBrowse()
{
   position = "optionswizard.js";
   whatfunc = "clearInstallAudioBrowse()";

   document.getElementById("div_Install_AudioBrowse").innerHTML = "";
   document.getElementById("div_Install_AudioBrowse").innerHTML = '<input id="Install_AudioBrowse" type="file" style="display:none;">';
}

function HandleInstallAudioAdd()
{
   position = "optionswizard.js";
   whatfunc = "HandleInstallAudioAdd()";

   if (document.getElementById("Install_AudioBrowse").value != "")
   {
      GetInstallAudioName();
      if (AudioName != "")
      {
         AudioGrid.addRow(AudioGrid.getRowsNum(), [AudioName]);
         ExtractInstallAudioValues();
         AudioGrid.selectRow(AudioGrid.getRowsNum() - 1, false, false, true);
         ToggleAudioControlGadgets();
         OptionsUpdated();
      }
   }
}

function GetInstallAudioName()
{
   position = "optionswizard.js";
   whatfunc = "GetInstallAudioName()";

   var lastSlash;

   tempName = document.getElementById("Install_AudioBrowse").value;
   lastSlash = tempName.lastIndexOf("\\");

   AudioName = tempName.substring(lastSlash + 1, tempName.length);
}

function AudioDelete()
{
 position="optionswizard.js";
 whatfunc="AudioDelete()";

   AudioGrid.deleteRow(AudioGrid.getSelectedRowId());
   ExtractInstallAudioValues();
   Commands.splice(AudioGrid.getRowIndex(AudioGrid.getSelectedRowId()), 1);
   PopulateAudioGrid();
   ToggleAudioControlGadgets();

   OptionsUpdated();
}

function ExtractInstallAudioValues()
{
   position = "optionswizard.js";
   whatfunc = "ExtractInstallAudioValues()";

   Songs.splice(0, Songs.length);

   for (i = 0; i < AudioGrid.getRowsNum(); i ++ )
   Songs.splice(Songs.length, 0, AudioGrid.cells(AudioGrid.getRowId(i), 0).getValue());

   if (Songs.length > 0)
   InstallAudio = Songs.join(",");
   else
   InstallAudio = "";
}

function SetVolumeValue(value, slider)
{
   position = "optionswizard.js";
   whatfunc = "SetVolumeValue()";

   document.getElementById("VolumeValue").innerHTML = value;

   OptionsUpdated();
}

function HandleCopyAudioPath()
{
   position = "optionswizard.js";
   whatfunc = "HandleCopyAudioPath()";

   var txt;

   txt = document.getElementById("CopyAudioPath").value;
   if (txt.indexOf('"') != -1)
   {
      txt = txt.replace(/\"/gi,"");
      document.getElementById("CopyAudioPath").value = txt;
   }
}

function HandleCopyAudioFolder()
{
   position = "optionswizard.js";
   whatfunc = "HandleCopyAudioFolder()";

   if (document.getElementById("CopyAudioFolder").checked)
   {
      document.getElementById("CopyAudioPath").disabled = false;
      document.getElementById("DeleteAudioFolder").disabled = false;
   }
   else
   {
      document.getElementById("CopyAudioPath").disabled = true;
      document.getElementById("DeleteAudioFolder").disabled = true;
   }
}

function HandleAllSoundGadgets()
{
   position = "optionswizard.js";
   whatfunc = "HandleAllSoundGadgets()";

   HandleSndWPIStart();
   HandleSndInstallStart();
   HandleSndInstallSuccess();
   HandleSndInstallWarning();
   HandleSndInstallFail();
   HandleSndInstallFinish();
   HandleSndWPIExit();
}

function HandleSndWPIStart()
{
   position = "optionswizard.js";
   whatfunc = "HandleSndWPIStart()";

   if (document.getElementById("SndWPIStartCB").checked)
   {
      document.getElementById("SndWPIStart").disabled = false;
      document.getElementById("SndWPIStartShow").style.display = 'block';
      document.getElementById("SndWPIStartHide").style.display = 'none';
      document.getElementById("SndWPIStartPlayShow").style.display = 'block';
      document.getElementById("SndWPIStartPlayHide").style.display = 'none';
   }
   else
   {
      document.getElementById("SndWPIStart").disabled = true;
      document.getElementById("SndWPIStartShow").style.display = 'none';
      document.getElementById("SndWPIStartHide").style.display = 'block';
      document.getElementById("SndWPIStartPlayShow").style.display = 'none';
      document.getElementById("SndWPIStartPlayHide").style.display = 'block';
   }
}

function clearSetSndWPIStartPathBrowse()
{
   position = "optionswizard.js";
   whatfunc = "clearSetSndWPIStartPathBrowse()";

   document.getElementById("div_SndWPIStartBrowse").innerHTML = "";
   document.getElementById("div_SndWPIStartBrowse").innerHTML = '<input id="SndWPIStartBrowse" type="file" style="display:none;">';
}

function SetSndWPIStartPath()
{
   position = "optionswizard.js";
   whatfunc = "SetSndWPIStartPath()";

   if (document.getElementById("SndWPIStartBrowse").value != "")
   {
      tempName = document.getElementById("SndWPIStartBrowse").value;

      if (theStart = tempName.indexOf(":") != - 1)
      tempName = trimString(tempName);

      document.getElementById("SndWPIStart").value = tempName;
   }
}

function HandleSndInstallStart()
{
   position = "optionswizard.js";
   whatfunc = "HandleSndInstallStart()";

   if (document.getElementById("SndInstallStartCB").checked)
   {
      document.getElementById("SndInstallStart").disabled = false;
      document.getElementById("SndInstallStartShow").style.display = 'block';
      document.getElementById("SndInstallStartHide").style.display = 'none';
      document.getElementById("SndInstallStartPlayShow").style.display = 'block';
      document.getElementById("SndInstallStartPlayHide").style.display = 'none';
   }
   else
   {
      document.getElementById("SndInstallStart").disabled = true;
      document.getElementById("SndInstallStartShow").style.display = 'none';
      document.getElementById("SndInstallStartHide").style.display = 'block';
      document.getElementById("SndInstallStartPlayShow").style.display = 'none';
      document.getElementById("SndInstallStartPlayHide").style.display = 'block';
   }
}

function clearSetSndInstallStartPathBrowse()
{
   position = "optionswizard.js";
   whatfunc = "clearSetSndInstallStartPathBrowse()";

   document.getElementById("div_SndInstallStartBrowse").innerHTML = "";
   document.getElementById("div_SndInstallStartBrowse").innerHTML = '<input id="SndInstallStartBrowse" type="file" style="display:none;">';
}

function SetSndInstallStartPath()
{
   position = "optionswizard.js";
   whatfunc = "SetSndInstallStartPath()";

   if (document.getElementById("SndInstallStartBrowse").value != "")
   {
      tempName = document.getElementById("SndInstallStartBrowse").value;

      if (theStart = tempName.indexOf(":") != - 1)
      tempName = trimString(tempName);

      document.getElementById("SndInstallStart").value = tempName;
   }
}

function HandleSndInstallSuccess()
{
   position = "optionswizard.js";
   whatfunc = "HandleSndInstallSuccess()";

   if (document.getElementById("SndInstallSuccessCB").checked)
   {
      document.getElementById("SndInstallSuccess").disabled = false;
      document.getElementById("SndInstallSuccessShow").style.display = 'block';
      document.getElementById("SndInstallSuccessHide").style.display = 'none';
      document.getElementById("SndInstallSuccessPlayShow").style.display = 'block';
      document.getElementById("SndInstallSuccessPlayHide").style.display = 'none';
   }
   else
   {
      document.getElementById("SndInstallSuccess").disabled = true;
      document.getElementById("SndInstallSuccessShow").style.display = 'none';
      document.getElementById("SndInstallSuccessHide").style.display = 'block';
      document.getElementById("SndInstallSuccessPlayShow").style.display = 'none';
      document.getElementById("SndInstallSuccessPlayHide").style.display = 'block';
   }
}

function clearSetSndInstallSuccessPathBrowse()
{
   position = "optionswizard.js";
   whatfunc = "clearSetSndInstallSuccessPathBrowse()";

   document.getElementById("div_SndInstallSuccessBrowse").innerHTML = "";
   document.getElementById("div_SndInstallSuccessBrowse").innerHTML = '<input id="SndInstallSuccessBrowse" type="file" style="display:none;">';
}

function SetSndInstallSuccessPath()
{
   position = "optionswizard.js";
   whatfunc = "SetSndInstallSuccessPath()";

   if (document.getElementById("SndInstallSuccessBrowse").value != "")
   {
      tempName = document.getElementById("SndInstallSuccessBrowse").value;

      if (theStart = tempName.indexOf(":") != - 1)
      tempName = trimString(tempName);

      document.getElementById("SndInstallSuccess").value = tempName;
   }
}

function HandleSndInstallWarning()
{
   position = "optionswizard.js";
   whatfunc = "HandleSndInstallWarning()";

   if (document.getElementById("SndInstallWarningCB").checked)
   {
      document.getElementById("SndInstallWarning").disabled = false;
      document.getElementById("SndInstallWarningShow").style.display = 'block';
      document.getElementById("SndInstallWarningHide").style.display = 'none';
      document.getElementById("SndInstallWarningPlayShow").style.display = 'block';
      document.getElementById("SndInstallWarningPlayHide").style.display = 'none';
   }
   else
   {
      document.getElementById("SndInstallWarning").disabled = true;
      document.getElementById("SndInstallWarningShow").style.display = 'none';
      document.getElementById("SndInstallWarningHide").style.display = 'block';
      document.getElementById("SndInstallWarningPlayShow").style.display = 'none';
      document.getElementById("SndInstallWarningPlayHide").style.display = 'block';
   }
}

function clearSetSndInstallWarningPathBrowse()
{
   position = "optionswizard.js";
   whatfunc = "clearSetSndInstallWarningPathBrowse()";

   document.getElementById("div_SndInstallWarningBrowse").innerHTML = "";
   document.getElementById("div_SndInstallWarningBrowse").innerHTML = '<input id="SndInstallWarningBrowse" type="file" style="display:none;">';
}

function SetSndInstallWarningPath()
{
   position = "optionswizard.js";
   whatfunc = "SetSndInstallWarningPath()";

   if (document.getElementById("SndInstallWarningBrowse").value != "")
   {
      tempName = document.getElementById("SndInstallWarningBrowse").value;

      if (theStart = tempName.indexOf(":") != - 1)
      tempName = trimString(tempName);

      document.getElementById("SndInstallWarning").value = tempName;
   }
}

function HandleSndInstallFail()
{
   position = "optionswizard.js";
   whatfunc = "HandleSndInstallFail()";

   if (document.getElementById("SndInstallFailCB").checked)
   {
      document.getElementById("SndInstallFail").disabled = false;
      document.getElementById("SndInstallFailShow").style.display = 'block';
      document.getElementById("SndInstallFailHide").style.display = 'none';
      document.getElementById("SndInstallFailPlayShow").style.display = 'block';
      document.getElementById("SndInstallFailPlayHide").style.display = 'none';
   }
   else
   {
      document.getElementById("SndInstallFail").disabled = true;
      document.getElementById("SndInstallFailShow").style.display = 'none';
      document.getElementById("SndInstallFailHide").style.display = 'block';
      document.getElementById("SndInstallFailPlayShow").style.display = 'none';
      document.getElementById("SndInstallFailPlayHide").style.display = 'block';
   }
}

function clearSetSndInstallFailPathBrowse()
{
   position = "optionswizard.js";
   whatfunc = "clearSetSndInstallFailPathBrowse()";

   document.getElementById("div_SndInstallFailBrowse").innerHTML = "";
   document.getElementById("div_SndInstallFailBrowse").innerHTML = '<input id="SndInstallFailBrowse" type="file" style="display:none;">';
}

function SetSndInstallFailPath()
{
   position = "optionswizard.js";
   whatfunc = "SetSndInstallFailPath()";

   if (document.getElementById("SndInstallFailBrowse").value != "")
   {
      tempName = document.getElementById("SndInstallFailBrowse").value;

      if (theStart = tempName.indexOf(":") != - 1)
      tempName = trimString(tempName);

      document.getElementById("SndInstallFail").value = tempName;
   }
}

function HandleSndInstallFinish()
{
   position = "optionswizard.js";
   whatfunc = "HandleSndInstallFinish()";

   if (document.getElementById("SndInstallFinishCB").checked)
   {
      document.getElementById("SndInstallFinish").disabled = false;
      document.getElementById("SndInstallFinishShow").style.display = 'block';
      document.getElementById("SndInstallFinishHide").style.display = 'none';
      document.getElementById("SndInstallFinishPlayShow").style.display = 'block';
      document.getElementById("SndInstallFinishPlayHide").style.display = 'none';
   }
   else
   {
      document.getElementById("SndInstallFinish").disabled = true;
      document.getElementById("SndInstallFinishShow").style.display = 'none';
      document.getElementById("SndInstallFinishHide").style.display = 'block';
      document.getElementById("SndInstallFinishPlayShow").style.display = 'none';
      document.getElementById("SndInstallFinishPlayHide").style.display = 'block';
   }
}

function clearSetSndInstallFinishPathBrowse()
{
   position = "optionswizard.js";
   whatfunc = "clearSetSndInstallFinishPathBrowse()";

   document.getElementById("div_SndInstallFinishBrowse").innerHTML = "";
   document.getElementById("div_SndInstallFinishBrowse").innerHTML = '<input id="SndInstallFinishBrowse" type="file" style="display:none;">';
}

function SetSndInstallFinishPath()
{
   position = "optionswizard.js";
   whatfunc = "SetSndInstallFinishPath()";

   if (document.getElementById("SndInstallFinishBrowse").value != "")
   {
      tempName = document.getElementById("SndInstallFinishBrowse").value;

      if (theStart = tempName.indexOf(":") != - 1)
      tempName = trimString(tempName);

      document.getElementById("SndInstallFinish").value = tempName;
   }
}

function HandleSndWPIExit()
{
   position = "optionswizard.js";
   whatfunc = "HandleSndWPIExit()";

   if (document.getElementById("SndWPIExitCB").checked)
   {
      document.getElementById("SndWPIExit").disabled = false;
      document.getElementById("SndWPIExitShow").style.display = 'block';
      document.getElementById("SndWPIExitHide").style.display = 'none';
      document.getElementById("SndWPIExitPlayShow").style.display = 'block';
      document.getElementById("SndWPIExitPlayHide").style.display = 'none';
   }
   else
   {
      document.getElementById("SndWPIExit").disabled = true;
      document.getElementById("SndWPIExitShow").style.display = 'none';
      document.getElementById("SndWPIExitHide").style.display = 'block';
      document.getElementById("SndWPIExitPlayShow").style.display = 'none';
      document.getElementById("SndWPIExitPlayHide").style.display = 'block';
   }
}

function clearSetSndWPIExitPathBrowse()
{
   position = "optionswizard.js";
   whatfunc = "clearSetSndWPIExitPathBrowse()";

   document.getElementById("div_SndWPIExitBrowse").innerHTML = "";
   document.getElementById("div_SndWPIExitBrowse").innerHTML = '<input id="SndWPIExitBrowse" type="file" style="display:none;">';
}

function SetSndWPIExitPath()
{
   position = "optionswizard.js";
   whatfunc = "SetSndWPIExitPath()";

   if (document.getElementById("SndWPIExitBrowse").value != "")
   {
      tempName = document.getElementById("SndWPIExitBrowse").value;

      if (theExit = tempName.indexOf(":") != - 1)
      tempName = trimString(tempName);

      document.getElementById("SndWPIExit").value = tempName;
   }
}

function FillInOptionsFile()
{
   position = "optionswizard.js";
   whatfunc = "FillInOptionsFile()";
   StatusBar.setText(optionsFile);
}

function NewOptions()
{
   position = "optionswizard.js";
   whatfunc = "NewOptions()";

   var temp;

   if ( ! isOptionsSaved)
   {

      if ( ! Alert("", getText(txtDiscardChangesContinue), getText(lblOK) + "|" + getText(lblCancel), "", 5, 0, 0, 0))
      return;
   }

   temp = Alert("", getText(txtSaveOptionsAs), getText(lblOK) + "|" + getText(lblCancel), optionsFile, 6, 0, 125, 0);
   if (temp != null)
   {
      if (FileExists(temp))
      {
         if ( ! Alert("", temp + "\n\n" + getText(txtFileExistsReplace), getText(lblOK) + "|" + getText(lblCancel), "", 5, 0, 0, 0))
         return;
      }

      optionsFile = temp;
      SetOptionsPath(true);

      UserOptionsDefaults();
      WindowOptionsDefaults();
      SaveOptions();
   }
}

function optionsClearReadBrowse()
{
   position = "optionswizard.js";
   whatfunc = "optionsClearReadBrowse()";

   document.getElementById("div_optionsReadBrowse").innerHTML = "";
   document.getElementById("div_optionsReadBrowse").innerHTML = '<input id="optionsReadBrowse" type="file" style="display:none;">';
}

function HandleReadOptions()
{
   position = "optionswizard.js";
   whatfunc = "HandleReadOptions()";

   if ( ! isOptionsSaved)
   {
      if ( ! Alert("", getText(txtDiscardChangesContinue), getText(lblOK) + "|" + getText(lblCancel), "", 5, 0, 0, 0))
      return;
   }

   optionsClearReadBrowse();
   document.all.optionsReadBrowse.click();

   if (document.getElementById("optionsReadBrowse").value != "")
   {
      isOptionsSaved = true;
      SetOptionsPath(false);
      ReadOptions();
   }
}

function SetOptionsPath(mode)
{
   position = "optionswizard.js";
   whatfunc = "SetOptionsPath()";

   var i, txt;

   if ( ! mode)
   {
      optionsFile = document.getElementById("optionsReadBrowse").value;

   }
   else
   {

   }

   FillInOptionsFile();
}

function GetOptionsPath()
{
   position = "optionswizard.js";
   whatfunc = "GetOptionsPath()";

   var temp;

   temp = Alert("", getText(txtSaveOptionsAs), getText(lblOK) + "|" + getText(lblCancel), optionsFile, 6, 0, 125, 0);
   if (temp != null)
   {
      optionsFile = temp;
      SetOptionsPath(true);
      SaveOptions();
   }
}

function UserOptionsDefaults()
{
   position = "optionswizard.js";
   whatfunc = "UserOptionsDefaults()";

   //
   // System predefined options
   //
   // Window tab
   Resolution = 0;
   MainWindowWidth = 800;
   MainWindowHeight = 600;
   MainWindowX = - 1;
   MainWindowY = - 1;
   InstallerWindowX = 25;
   InstallerWindowY = 25;

   // General tab
   NumCols = 3;

   Timer = true;
   Seconds = 60;
   StartBeepAtSecs = 10;

   Language = 'zz';

   ShowExtraButtons = true;
   DoNotShowIfCD = true;
   USSFSilentMode = false;
   VerifyInstallHDD = false;
   DoNotShowIfUSB=true;
   AllowCheckForInternet = false;
   LoadDesktopBeforeInstall = false;
   ReOpenAfterInstall = false;
   DisableCatCheckBoxes = false;
   SortWithinCats = false;
   DisableOnDepsNotMet = true;
   AlwaysUseScrollBar = true;
   DontSplitCats = true;
   InstallByCategory = true;
   ReallyForce = false;
   DisableIfDoGray = false;
   InstallFonts = false;
   ShowCommandInInstaller = true;
   ShowInstallerImages = false;
   AlwaysShowOutputWindow = false;
   EjectCDWhenDone = false;
   DisableHotKeys = false;
   ShowDownloadOutput = false;
   DisableInstallCombobox = false;
   MaintainAutoLogonCount = false;

   DefaultInstallPath = ['default'];
   CustomInstallPath = [''];

   AbortInstallIfFailure = false;
   ExecuteCommandIfFailure = [''];
   ContinueWhereFailed = false;

   // Tools tab
   ExecuteBeforeEnabled = false;
   ExecuteBefore = [''];
   ExecuteAfterEnabled = false;
   ExecuteAfter = [''];

   RestartComputer = false;
   RestartType = 0;
   RestartSeconds = 30;
   DoNotLoadDesktop = true;

   LogInstallation = true;
   LogPath = DefaultLogPath;
   TimeStampLogFile = false;

   // Audio Player tab
   PlayAudioInInstaller = false;
   InstallAudio = [];
   Volume = 75;
   Shuffle = false;
   CopyAudioFolder = false;
   CopyAudioPath = ['C:\\Audio'];
   DeleteAudioFolder = false;

   // Sounds tab
   SndWPIStartCB = false;
   SndWPIStart = ['"%wpipath%\\Audio\\SoundsScheme\\Alert.wav"'];
   SndInstallStartCB = false;
   SndInstallStart = ['"%wpipath%\\Audio\\SoundsScheme\\AtBeginning.wav"'];
   SndInstallSuccessCB = false;
   SndInstallSuccess = ['"%wpipath%\\Audio\\SoundsScheme\\Yes.wav"'];
   SndInstallWarningCB = false;
   SndInstallWarning = ['"%wpipath%\\Audio\\SoundsScheme\\Warning.wav"'];
   SndInstallFailCB = false;
   SndInstallFail = ['"%wpipath%\\Audio\\SoundsScheme\\No.wav"'];
   SndInstallFinishCB = false;
   SndInstallFinish = ['"%wpipath%\\Audio\\SoundsScheme\\AtEnd.wav"'];
   SndWPIExitCB = false;
   SndWPIExit = ['"%wpipath%\\Audio\\SoundsScheme\\Exit.wav"'];

   if (document.getElementById("layeroptions").style.display == 'block')
   {
      // Window tab
      document.getElementById("Resolution").value = Resolution;
      document.getElementById("MainWindowWidth").value = MainWindowWidth;
      document.getElementById("MainWindowHeight").value = MainWindowHeight;
      document.getElementById("MainWindowX").value = MainWindowX;
      document.getElementById("MainWindowY").value = MainWindowY;
      document.getElementById("InstallerWindowX").value = InstallerWindowX;
      document.getElementById("InstallerWindowY").value = InstallerWindowY;

      // General tab
      document.getElementById("NumCols").value = NumCols;
      document.getElementById("Timer").checked = Timer;
      document.getElementById("Seconds").value = Seconds;
      document.getElementById("StartBeepAtSecs").value = StartBeepAtSecs;
      LanguageCombo.setComboValue(Language);
      document.getElementById("DefaultInstallPath").value = DefaultInstallPath;
      document.getElementById("CustomInstallPath").value = CustomInstallPath;
      document.getElementById("AbortInstallIfFailure").checked = AbortInstallIfFailure;
      document.getElementById("ExecuteCommandIfFailure").value = ExecuteCommandIfFailure;
      document.getElementById("ContinueWhereFailed").checked = ContinueWhereFailed;

      // Features tab
      document.getElementById("ShowExtraButtons").checked = ShowExtraButtons;
      document.getElementById("DoNotShowIfCD").checked = DoNotShowIfCD;
      document.getElementById("USSFSilentMode").checked = USSFSilentMode;
      document.getElementById("VerifyInstallHDD").checked = VerifyInstallHDD;
      document.getElementById("AllowCheckForInternet").checked = AllowCheckForInternet;
      document.getElementById("LoadDesktopBeforeInstall").checked = LoadDesktopBeforeInstall;
      document.getElementById("ReOpenAfterInstall").checked = ReOpenAfterInstall;
      document.getElementById("DisableCatCheckBoxes").checked = DisableCatCheckBoxes;
      document.getElementById("SortWithinCats").checked = SortWithinCats;
      document.getElementById("DisableOnDepsNotMet").checked = DisableOnDepsNotMet;
      document.getElementById("AlwaysUseScrollBar").checked = AlwaysUseScrollBar;
      document.getElementById("DontSplitCats").checked = DontSplitCats;
      document.getElementById("InstallByCategory").checked = InstallByCategory;
      document.getElementById("ReallyForce").checked = ReallyForce;
      document.getElementById("DisableIfDoGray").checked = DisableIfDoGray;
      document.getElementById("InstallFonts").checked = InstallFonts;
      document.getElementById("ShowCommandInInstaller").checked = ShowCommandInInstaller;
      document.getElementById("ShowInstallerImages").checked = ShowInstallerImages;
      document.getElementById("AlwaysShowOutputWindow").checked = AlwaysShowOutputWindow;
      document.getElementById("EjectCDWhenDone").checked = EjectCDWhenDone;
      document.getElementById("DoNotShowIfUSB").checked = DoNotShowIfUSB;
      document.getElementById("DisableHotKeys").checked = DisableHotKeys;
      document.getElementById("ShowDownloadOutput").checked = ShowDownloadOutput;
      document.getElementById("DisableInstallCombobox").checked = DisableInstallCombobox;
      document.getElementById("MaintainAutoLogonCount").checked = MaintainAutoLogonCount;

      // Tools tab
      document.getElementById("ExecuteBeforeEnabled").checked = ExecuteBeforeEnabled;
      document.getElementById("ExecuteBefore").value = ExecuteBefore;
      document.getElementById("ExecuteAfterEnabled").checked = ExecuteAfterEnabled;
      document.getElementById("ExecuteAfter").value = ExecuteAfter;
      document.getElementById("RestartComputer").checked = RestartComputer;
      if (RestartType == 0)
      {
         document.getElementById("RestartType0").checked = true;
         document.getElementById("RestartType1").checked = false;
      }
      if (RestartType == 1)
      {
         document.getElementById("RestartType0").checked = false;
         document.getElementById("RestartType1").checked = true;
      }
      document.getElementById("RestartSeconds").value = RestartSeconds;
      document.getElementById("DoNotLoadDesktop").value = DoNotLoadDesktop;
      document.getElementById("LogInstallation").checked = LogInstallation;
      document.getElementById("LogPath").value = LogPath;
      document.getElementById("TimeStampLogFile").checked = TimeStampLogFile;

      // Audio tab
      document.getElementById("PlayAudioInInstaller").checked = PlayAudioInInstaller;
      VolumeSlider.setValue(Volume);
      document.getElementById("ShuffleAudio").checked = Shuffle;
      document.getElementById("CopyAudioFolder").checked = CopyAudioFolder;
      document.getElementById("CopyAudioPath").value = CopyAudioPath;
      document.getElementById("DeleteAudioFolder").checked = DeleteAudioFolder;

      // Sounds tab
      document.getElementById("SndWPIStartCB").checked = SndWPIStartCB;
      document.getElementById("SndWPIStart").value = SndWPIStart;
      document.getElementById("SndInstallStartCB").checked = SndInstallStartCB;
      document.getElementById("SndInstallStart").value = SndInstallStart;
      document.getElementById("SndInstallSuccessCB").checked = SndInstallSuccessCB;
      document.getElementById("SndInstallSuccess").value = SndInstallSuccess;
      document.getElementById("SndInstallWarningCB").checked = SndInstallWarningCB;
      document.getElementById("SndInstallWarning").value = SndInstallWarning;
      document.getElementById("SndInstallFailCB").checked = SndInstallFailCB;
      document.getElementById("SndInstallFail").value = SndInstallFail;
      document.getElementById("SndInstallFinishCB").checked = SndInstallFinishCB;
      document.getElementById("SndInstallFinish").value = SndInstallFinish;
      document.getElementById("SndWPIExitCB").checked = SndWPIExitCB;
      document.getElementById("SndWPIExit").value = SndWPIExit;

      HandleWindowResolution();
      HandleTimerSelection();
      HandleStartBeepAt();
      HandleDefaultInstallPath();
      HandleAbortInstallIfFailureSelection();
      HandleExecuteBeforeSelection();
      HandleExecuteAfterSelection();
      HandleRestartComputerSelection();
      HandleLogInstallationSelection();
      PopulateAudioGrid();
      HandlePlayInstallAudioSelection();
      HandleAllSoundGadgets();
      FillInOptionsFile();
   }
}

function WindowOptionsDefaults()
{
   position = "optionswizard.js";
   whatfunc = "WindowOptionsDefaults()";

   //
   // System predefined options
   //
   // Window tab
   WindowShowBorder = false;
   WindowBorderType = 'thick';
   WindowInnerBorder = false;
   WindowBorderStyle = 'normal';
   WindowCaption = false;
   WindowSysMenu = true;
   WindowMinimizeButton = true;
   WindowStartingState = 'normal';
   WindowShowInTaskBar = true;

   if (document.getElementById("layeroptions").style.display == 'block')
   {
      // Window tab
      document.getElementById("ShowWindowBorder").checked = WindowShowBorder;
      document.getElementById("BorderType").value = WindowBorderType;
      document.getElementById("InnerBorder").checked = WindowInnerBorder;
      document.getElementById("BorderStyle").value = WindowBorderStyle;
      document.getElementById("ShowTitleBar").checked = WindowCaption;
      document.getElementById("SysMenuEnabled").checked = WindowSysMenu;
      document.getElementById("MinimizeEnabled").checked = WindowMinimizeButton;
      document.getElementById("ShowInTaskBar").checked = WindowShowInTaskBar;
      HandleShowWindowBorderSelection();
   }
}

function GetOptionsVersion()
{
   position = "optionswizard.js";
   whatfunc = "GetOptionsVersion()";

   var line = new String();
   var num = 1, ver = - 1;

   strFile = optionsFile;
   if (FileExists(strFile))
   {
      try
      {
         tf = fso.OpenTextFile(strFile, 1, 0, - 2);
         while ( ! tf.AtEndOfStream && num < 2)
         {
            line = tf.ReadLine();
            if (line.indexOf("// WPI Options ") != - 1)
            {
               line = line.replace(/[^0-9]/g, '');
               ver = Number(line);
            }
            else
            ver = 0;
            num ++ ;
         }
      }
      catch(ex)
      {
         ;

      }
      finally
      {
         try
         {
            tf.Close();
         }
         catch (ex0)
         {
            ;

         }
      }
   }

   return ver;
}

function ReadOptions()
{
   position = "optionswizard.js";
   whatfunc = "ReadOptions()";

   var line = new String();
   var opt = new String();
   var val = new String();

   WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\OptionsFile", optionsFile, "REG_SZ");

   strFile = optionsFile;
   if (FileExists(strFile))
   {
      try
      {
         tf = fso.OpenTextFile(strFile, 1, 0, - 2);
         while(true)
         {
            line = tf.ReadLine();

            if (line.search("^ *//") == 0)
            continue;

            opt = line.substring(0, line.indexOf("="));
            val = line.substring(line.indexOf("=") + 1, line.length - 1);
            val = val.replace(/^ *\[ */, "").replace(/^ *' */,"");
            val = val.replace(/ *] *$/, "").replace(/ *' *$/,"");
            val = val.replace(/ *]; *$/, "").replace(/ *' *$/,"");
            val = val.replace(/\\\\/g,"\\");
            val = val.replace(/\\'/g,"'");

            // Window tab
            if (opt == "Resolution")
            document.getElementById("Resolution").value = val.replace(/'/gi,"");
            if (opt == "MainWindowWidth")
            document.getElementById("MainWindowWidth").value = val;
            if (opt == "MainWindowHeight")
            document.getElementById("MainWindowHeight").value = val;
            if (opt == "MainWindowX")
            document.getElementById("MainWindowX").value = val;
            if (opt == "MainWindowY")
            document.getElementById("MainWindowY").value = val;
            if (opt == "InstallerWindowX")
            document.getElementById("InstallerWindowX").value = val;
            if (opt == "InstallerWindowY")
            document.getElementById("InstallerWindowY").value = val;

            // General tab
            if (opt == "NumCols")
            document.getElementById("NumCols").value = val;

            if (opt == "Timer")
            document.getElementById("Timer").checked = val == "true" ? true : false;
            if (opt == "Seconds")
            document.getElementById("Seconds").value = val;
            if (opt == "StartBeepAtSecs")
            document.getElementById("StartBeepAtSecs").value = val;

            if (opt == "Language")
            var tempLanguage = val.replace(/'/gi,"");

            if (opt == "DefaultInstallPath")
            document.getElementById("DefaultInstallPath").value = val.replace(/'/gi,"");
            if (opt == "CustomInstallPath")
            document.getElementById("CustomInstallPath").value = val.replace(/[\[\]']/g,"").replace(/\\\\/g,"\\");

            if (opt == "AbortInstallIfFailure")
            document.getElementById("AbortInstallIfFailure").checked = val == "true" ? true : false;
            if (opt == "ExecuteCommandIfFailure")
            document.getElementById("ExecuteCommandIfFailure").value = val.replace(/[\[\]']/g,"").replace(/\\\\/g,"\\");
            if (opt == "ContinueWhereFailed")
            document.getElementById("ContinueWhereFailed").checked = val == "true" ? true : false;

            // Features tab
            if (opt == "ShowExtraButtons")
            document.getElementById("ShowExtraButtons").checked = val == "true" ? true : false;
            if (opt == "DoNotShowIfCD")
            document.getElementById("DoNotShowIfCD").checked = val == "true" ? true : false;
            if (opt == "USSFSilentMode")
            document.getElementById("USSFSilentMode").checked = val == "true" ? true : false;
            if (opt == "VerifyInstallHDD")
            document.getElementById("VerifyInstallHDD").checked = val == "true" ? true : false;
            if (opt == "AllowCheckForInternet")
            document.getElementById("AllowCheckForInternet").checked = val == "true" ? true : false;
            if (opt == "LoadDesktopBeforeInstall")
            document.getElementById("LoadDesktopBeforeInstall").checked = val == "true" ? true : false;
            if (opt == "ReOpenAfterInstall")
            document.getElementById("ReOpenAfterInstall").checked = val == "true" ? true : false;
            if (opt == "DisableCatCheckBoxes")
            document.getElementById("DisableCatCheckBoxes").checked = val == "true" ? true : false;
            if (opt == "SortWithinCats")
            document.getElementById("SortWithinCats").checked = val == "true" ? true : false;
            if (opt == "DisableOnDepsNotMet")
            document.getElementById("DisableOnDepsNotMet").checked = val == "true" ? true : false;
            if (opt == "AlwaysUseScrollBar")
            document.getElementById("AlwaysUseScrollBar").checked = val == "true" ? true : false;
            if (opt == "DontSplitCats")
            document.getElementById("DontSplitCats").checked = val == "true" ? true : false;
            if (opt == "InstallByCategory")
            document.getElementById("InstallByCategory").checked = val == "true" ? true : false;
            if (opt == "ReallyForce")
            document.getElementById("ReallyForce").checked = val == "true" ? true : false;
            if (opt == "DisableIfDoGray")
            document.getElementById("DisableIfDoGray").checked = val == "true" ? true : false;
            if (opt == "InstallFonts")
            document.getElementById("InstallFonts").checked = val == "true" ? true : false;
            if (opt == "ShowCommandInInstaller")
            document.getElementById("ShowCommandInInstaller").checked = val == "true" ? true : false;
            if (opt == "ShowInstallerImages")
            document.getElementById("ShowInstallerImages").checked = val == "true" ? true : false;
            if (opt == "AlwaysShowOutputWindow")
            document.getElementById("AlwaysShowOutputWindow").checked = val == "true" ? true : false;
            if (opt == "EjectCDWhenDone")
            document.getElementById("EjectCDWhenDone").checked = val == "true" ? true : false;
            if (opt == "DoNotShowIfUSB")
            document.getElementById("DoNotShowIfUSB").checked = val == "true" ? true : false;
            if (opt == "DisableHotKeys")
            document.getElementById("DisableHotKeys").checked = val == "true" ? true : false;
            if (opt == "ShowDownloadOutput")
            document.getElementById("ShowDownloadOutput").checked = val == "true" ? true : false;
            if (opt == "DisableInstallCombobox")
            document.getElementById("DisableInstallCombobox").checked = val == "true" ? true : false;
            if (opt == "MaintainAutoLogonCount")
            document.getElementById("MaintainAutoLogonCount").checked = val == "true" ? true : false;

            // Tools tab
            if (opt == "ExecuteBeforeEnabled")
            document.getElementById("ExecuteBeforeEnabled").checked = val == "true" ? true : false;
            if (opt == "ExecuteBefore")
            document.getElementById("ExecuteBefore").value = val.replace(/[\[\]']/g,"").replace(/\\\\/g,"\\");
            if (opt == "ExecuteAfterEnabled")
            document.getElementById("ExecuteAfterEnabled").checked = val == "true" ? true : false;
            if (opt == "ExecuteAfter")
            document.getElementById("ExecuteAfter").value = val.replace(/[\[\]']/g,"").replace(/\\\\/g,"\\");
            if (opt == "RestartComputer")
            document.getElementById("RestartComputer").checked = val == "true" ? true : false;
            if (opt == "RestartType")
            {
               if (val == 0)
               {
                  document.getElementById("RestartType0").checked = true;
                  document.getElementById("RestartType1").checked = false;
               }
               if (val == 1)
               {
                  document.getElementById("RestartType0").checked = false;
                  document.getElementById("RestartType1").checked = true;
               }
            }
            if (opt == "RestartSeconds")
            document.getElementById("RestartSeconds").value = val;
            if (opt == "DoNotLoadDesktop")
            document.getElementById("DoNotLoadDesktop").checked = val == "true" ? true : false;

            if (opt == "LogInstallation")
            document.getElementById("LogInstallation").checked = val == "true" ? true : false;
            if (opt == "LogPath")
            document.getElementById("LogPath").value = val.replace(/[\[\]']/g,"").replace(/\\\\/g,"\\");
            if (document.getElementById("LogInstallation").checked && document.getElementById("LogPath").value == "")
            {
               LogPath = DefaultLogPath;
               document.getElementById("LogPath").value = LogPath;
            }
            if (opt == "TimeStampLogFile")
            document.getElementById("TimeStampLogFile").checked = val == "true" ? true : false;

            // Audio tab
            if (opt == "PlayAudioInInstaller")
            document.getElementById("PlayAudioInInstaller").checked = val == "true" ? true : false;
            if (opt == "InstallAudio")
            InstallAudio = val.replace(/[\[\]'"]/g,"");
            if (opt == "Volume")
            VolumeSlider.setValue(val);
            if (opt == "Shuffle")
            document.getElementById("ShuffleAudio").checked = val == "true" ? true : false;
            if (opt == "CopyAudioFolder")
            document.getElementById("CopyAudioFolder").checked = val == "true" ? true : false;
            if (opt == "CopyAudioPath")
            document.getElementById("CopyAudioPath").value = val.replace(/[\[\]']/g,"").replace(/\\\\/g,"\\");
            if (opt == "DeleteAudioFolder")
            document.getElementById("DeleteAudioFolder").checked = val == "true" ? true : false;

            // Sounds tab
            if (opt == "SndWPIStartCB")
            document.getElementById("SndWPIStartCB").checked = val == "true" ? true : false;
            if (opt == "SndWPIStart")
            document.getElementById("SndWPIStart").value = val.replace(/[\[\]']/g,"").replace(/\\\\/g,"\\");
            if (opt == "SndInstallStartCB")
            document.getElementById("SndInstallStartCB").checked = val == "true" ? true : false;
            if (opt == "SndInstallStart")
            document.getElementById("SndInstallStart").value = val.replace(/[\[\]']/g,"").replace(/\\\\/g,"\\");
            if (opt == "SndInstallSuccessCB")
            document.getElementById("SndInstallSuccessCB").checked = val == "true" ? true : false;
            if (opt == "SndInstallSuccess")
            document.getElementById("SndInstallSuccess").value = val.replace(/[\[\]']/g,"").replace(/\\\\/g,"\\");
            if (opt == "SndInstallWarningCB")
            document.getElementById("SndInstallWarningCB").checked = val == "true" ? true : false;
            if (opt == "SndInstallWarning")
            document.getElementById("SndInstallWarning").value = val.replace(/[\[\]']/g,"").replace(/\\\\/g,"\\");
            if (opt == "SndInstallFailCB")
            document.getElementById("SndInstallFailCB").checked = val == "true" ? true : false;
            if (opt == "SndInstallFail")
            document.getElementById("SndInstallFail").value = val.replace(/[\[\]']/g,"").replace(/\\\\/g,"\\");
            if (opt == "SndInstallFinishCB")
            document.getElementById("SndInstallFinishCB").checked = val == "true" ? true : false;
            if (opt == "SndInstallFinish")
            document.getElementById("SndInstallFinish").value = val.replace(/[\[\]']/g,"").replace(/\\\\/g,"\\");
            if (opt == "SndWPIExitCB")
            document.getElementById("SndWPIExitCB").checked = val == "true" ? true : false;
            if (opt == "SndWPIExit")
            document.getElementById("SndWPIExit").value = val.replace(/[\[\]']/g,"").replace(/\\\\/g,"\\");
         }
      }
      catch(ex)
      {
         ;

      }
      finally
      {
         try
         {
            tf.Close();
         }
         catch (ex0)
         {
            ;

         }
      }
   }
   else
   {
      alert(getText(errCouldNotOpenFile) + " '"+strFile+"'.\n\n" + getText(errUsingDefaultSet));
      UserOptionsDefaults();
      SaveDefaultUserOptions();
   }

   strFile = windowFile;
   if (FileExists(strFile))
   {
      try
      {
         tf = fso.OpenTextFile(strFile, 1, 0, - 2);
         while(true)
         {
            line = tf.ReadLine();

            if (line.search("^ *//") == 0)
            continue;

            opt = line.substring(0, line.indexOf("="));
            val = line.substring(line.indexOf("=") + 1, line.length - 1);

            // Window tab
            if (opt == "WindowShowBorder")
            document.getElementById("ShowWindowBorder").checked = val == "true" ? true : false;
            if (opt == "WindowBorderType")
            document.getElementById("BorderType").value = val.replace(/'/gi,"");
            if (opt == "WindowInnerBorder")
            document.getElementById("InnerBorder").checked = val == "true" ? true : false;
            if (opt == "WindowBorderStyle")
            document.getElementById("BorderStyle").value = val.replace(/'/gi,"");
            if (opt == "WindowCaption")
            document.getElementById("ShowTitleBar").checked = val == "true" ? true : false;
            if (opt == "WindowSysMenu")
            document.getElementById("SysMenuEnabled").checked = val == "true" ? true : false;
            if (opt == "WindowMinimizeButton")
            document.getElementById("MinimizeEnabled").checked = val == "true" ? true : false;
            if (opt == "WindowStartingState")
            document.getElementById("StartingWindowState").value = val.replace(/'/gi,"");
            if (opt == "WindowShowInTaskBar")
            document.getElementById("ShowInTaskBar").checked = val == "true" ? true : false;
         }
      }
      catch(ex)
      {
         ;

      }
      finally
      {
         try
         {
            tf.Close();
         }
         catch (ex0)
         {
            ;

         }
      }
   }
   else
   {
      alert(getText(errCouldNotOpenFile) + " '"+strFile+"'.\n\n" + getText(errUsingDefaultSet));
      WindowOptionsDefaults();
      SaveDefaultWindowOptions();
      SaveDefaultSkinsOptions();
   }

   LanguageCombo.setComboValue(tempLanguage);
   isOptionsSaved = true;
   // Because setting combo box event triggers it

   HandleWindowResolution();
   HandleShowWindowBorderSelection();
   HandleTimerSelection();
   HandleStartBeepAt();
   HandleDefaultInstallPath();
   HandleAbortInstallIfFailureSelection();
   HandleExecuteBeforeSelection();
   HandleExecuteAfterSelection();
   HandleRestartComputerSelection();
   HandleLogInstallationSelection();
   PopulateAudioGrid();
   HandlePlayInstallAudioSelection();
   HandleAllSoundGadgets();
   FillInOptionsFile();
}

function SaveDefaultUserOptions()
{
   position = "optionswizard.js";
   whatfunc = "SaveDefaultUserOptions()";

   var txt = new String();

   strFile = optionsFile;
   try
   {
      tf = fso.CreateTextFile(strFile, true, true);

      tf.WriteLine("// WPI Options 8.0.0");
      tf.WriteLine("//");
      tf.WriteLine("// User defined options");
      tf.WriteLine("//");

      // Window tab
      tf.WriteLine("");
      tf.WriteLine("");
      tf.WriteLine("// Window tab");
      tf.WriteLine("Resolution=" + Resolution + ";");
      tf.WriteLine("MainWindowWidth=" + MainWindowWidth + ";");
      tf.WriteLine("MainWindowHeight=" + MainWindowHeight + ";");
      tf.WriteLine("MainWindowX=" + MainWindowX + ";");
      tf.WriteLine("MainWindowY=" + MainWindowY + ";");
      tf.WriteLine("InstallerWindowX=" + InstallerWindowX + ";");
      tf.WriteLine("InstallerWindowY=" + InstallerWindowY + ";");

      // General tab
      tf.WriteLine("");
      tf.WriteLine("");
      tf.WriteLine("// General tab");
      tf.WriteLine("NumCols=" + NumCols + ";");
      tf.WriteLine("// ---");
      tf.WriteLine("Timer=" + Timer + ";");
      tf.WriteLine("Seconds=" + Seconds + ";");
      tf.WriteLine("StartBeepAtSecs=" + StartBeepAtSecs + ";");
      tf.WriteLine("// ---");
      tf.WriteLine("Language='"+Language+"';");
      tf.WriteLine("// ---");
      tf.WriteLine("DefaultInstallPath='"+DefaultInstallPath+"';");
      tf.WriteLine("CustomInstallPath=[''];");
      tf.WriteLine("// ---");
      tf.WriteLine("AbortInstallIfFailure=" + AbortInstallIfFailure + ";");
      tf.WriteLine("ExecuteCommandIfFailure=[''];");
      tf.WriteLine("ContinueWhereFailed=" + ContinueWhereFailed + ";");

      // Features tab
      tf.WriteLine("");
      tf.WriteLine("");
      tf.WriteLine("// Features tab");
      tf.WriteLine("ShowExtraButtons=" + ShowExtraButtons + ";");
      tf.WriteLine("DoNotShowIfCD=" + DoNotShowIfCD + ";");
      tf.WriteLine("USSFSilentMode=" + USSFSilentMode + ";");
      tf.WriteLine("VerifyInstallHDD=" + VerifyInstallHDD + ";");
      tf.WriteLine("AllowCheckForInternet=" + AllowCheckForInternet + ";");
      tf.WriteLine("LoadDesktopBeforeInstall=" + LoadDesktopBeforeInstall + ";");
      tf.WriteLine("ReOpenAfterInstall=" + ReOpenAfterInstall + ";");
      tf.WriteLine("DisableCatCheckBoxes=" + DisableCatCheckBoxes + ";");
      tf.WriteLine("SortWithinCats=" + SortWithinCats + ";");
      tf.WriteLine("DisableOnDepsNotMet=" + DisableOnDepsNotMet + ";");
      tf.WriteLine("AlwaysUseScrollBar=" + AlwaysUseScrollBar + ";");
      tf.WriteLine("DontSplitCats=" + DontSplitCats + ";");
      tf.WriteLine("InstallByCategory=" + InstallByCategory + ";");
      tf.WriteLine("ReallyForce=" + ReallyForce + ";");
      tf.WriteLine("DisableIfDoGray=" + DisableIfDoGray + ";");
      tf.WriteLine("InstallFonts=" + InstallFonts + ";");
      tf.WriteLine("ShowCommandInInstaller=" + ShowCommandInInstaller + ";");
      tf.WriteLine("ShowInstallerImages=" + ShowInstallerImages + ";");
      tf.WriteLine("AlwaysShowOutputWindow=" + AlwaysShowOutputWindow + ";");
      tf.WriteLine("EjectCDWhenDone=" + EjectCDWhenDone + ";");
      tf.WriteLine("DisableHotKeys=" + DisableHotKeys + ";");
      tf.WriteLine("ShowDownloadOutput=" + ShowDownloadOutput + ";");
      tf.WriteLine("DisableInstallCombobox=" + DisableInstallCombobox + ";");
      tf.WriteLine("MaintainAutoLogonCount=" + MaintainAutoLogonCount + ";");
      tf.WriteLine("DoNotShowIfUSB=" + DoNotShowIfUSB + ";");

      // Tools tab
      tf.WriteLine("");
      tf.WriteLine("");
      tf.WriteLine("// ---");
      tf.WriteLine("ExecuteBeforeEnabled=" + ExecuteBeforeEnabled + ";");
      tf.WriteLine("ExecuteBefore=[''];");
      tf.WriteLine("ExecuteAfterEnabled=" + ExecuteAfterEnabled + ";");
      tf.WriteLine("ExecuteAfter=[''];");
      tf.WriteLine("// ---");
      tf.WriteLine("RestartComputer=" + RestartComputer + ";");
      tf.WriteLine("RestartType=" + RestartType + ";");
      tf.WriteLine("RestartSeconds=" + RestartSeconds + ";");
      tf.WriteLine("DoNotLoadDesktop=" + DoNotLoadDesktop + ";");
      tf.WriteLine("// ---");
      tf.WriteLine("LogInstallation=" + LogInstallation + ";");
      tf.WriteLine("LogPath=['"+LogPath+"'];");
      tf.WriteLine("TimeStampLogFile=" + TimeStampLogFile + ";");

      // Audio tab
      tf.WriteLine("");
      tf.WriteLine("");
      tf.WriteLine("// Audio tab");
      tf.WriteLine("PlayAudioInInstaller=" + PlayAudioInInstaller + ";");
      tf.WriteLine("InstallAudio=[''];");
      tf.WriteLine("Volume=" + Volume + ";");
      tf.WriteLine("Shuffle=" + Shuffle + ";");
      tf.WriteLine("CopyAudioFolder=" + CopyAudioFolder + ";");
      tf.WriteLine("CopyAudioPath=['"+CopyAudioPath+"'];");
      tf.WriteLine("DeleteAudioFlder=" + DeleteAudioFolder + ";");

      // Sounds tab
      tf.WriteLine("");
      tf.WriteLine("");
      tf.WriteLine("// Sounds tab");
      tf.WriteLine("SndWPIStartCB=" + SndWPIStartCB + ";");
      tf.WriteLine("SndWPIStart=['"+SndWPIStart+"'];");
      tf.WriteLine("SndInstallStartCB=" + SndInstallStartCB + ";");
      tf.WriteLine("SndInstallStart=['"+SndInstallStart+"'];");
      tf.WriteLine("SndInstallSuccessCB=" + SndInstallSuccessCB + ";");
      tf.WriteLine("SndInstallSuccess=['"+SndInstallSuccess+"'];");
      tf.WriteLine("SndInstallWarningCB=" + SndInstallWarningCB + ";");
      tf.WriteLine("SndInstallWarning=['"+SndInstallWarning+"'];");
      tf.WriteLine("SndInstallFailCB=" + SndInstallFailCB + ";");
      tf.WriteLine("SndInstallFail=['"+SndInstallFail+"'];");
      tf.WriteLine("SndInstallFinishCB=" + SndInstallFinishCB + ";");
      tf.WriteLine("SndInstallFinish=['"+SndInstallFinish+"'];");
      tf.WriteLine("SndWPIExitCB=" + SndWPIExitCB + ";");
      tf.WriteLine("SndWPIExit=['"+SndWPIExit+"'];");
   }
   catch(ex)
   {
      alert(getText(errCouldNotSaveFile) + "\n\n" + getText(lblFile) + ": " + strFile + "\n" + getText(lblErrorNumber) + ": " + (ex.number & 0xffff) + "\n" + getText(lblErrorDescription) + ": " + ex.description);

   }
   finally
   {
      try
      {
         tf.Close();
      }
      catch (ex0)
      {
         ;

      }
   }
}

function SaveDefaultWindowOptions()
{
   position = "optionswizard.js";
   whatfunc = "SaveDefaultWindowOptions()";

   strFile = windowFile;
   try
   {
      tf = fso.CreateTextFile(strFile, true, true);

      tf.WriteLine("// WPI Options 8.0.0");
      tf.WriteLine("//");
      tf.WriteLine("// User defined options");
      tf.WriteLine("//");

      // Window tab
      tf.WriteLine("");
      tf.WriteLine("");
      tf.WriteLine("// Window tab");
      tf.WriteLine("WindowShowBorder=" + WindowShowBorder + ";");
      tf.WriteLine("WindowBorderType='"+WindowBorderType +"';");
      tf.WriteLine("WindowInnerBorder=" + WindowInnerBorder + ";");
      tf.WriteLine("WindowBorderStyle='"+WindowBorderStyle +"';");
      tf.WriteLine("WindowCaption=" + WindowCaption + ";");
      tf.WriteLine("WindowSysMenu=" + WindowSysMenu + ";");
      tf.WriteLine("WindowMinimizeButton=" + WindowMinimizeButton + ";");
      tf.WriteLine("WindowStartingState='"+WindowStartingState +"';");
      tf.WriteLine("WindowShowInTaskBar=" + WindowShowInTaskBar + ";");
   }
   catch(ex)
   {
      alert(getText(errCouldNotSaveFile) + "\n\n" + getText(lblFile) + ": " + strFile + "\n" + getText(lblErrorNumber) + ": " + (ex.number & 0xffff) + "\n" + getText(lblErrorDescription) + ": " + ex.description);
   }
   finally
   {
      try
      {
         tf.Close();
      }
      catch (ex0)
      {
         ;

      }
   }
}

function SaveOptions()
{
   position = "optionswizard.js";
   whatfunc = "SaveOptions()";

   var txt = new String();

   if (fromCDDrive)
   {
      Alert("", getText(txtCanNotSaveToCD), getText(lblOK), "", 2, 0, 0, 0);

      return;
   }

   strFile = optionsFile;
   Language = lang;
   // For manual, switch to new language immediately on save t4user add
   try
   {
      Alert("", "<center>" + getText(txtSavingOptionsFile), "---none---", "", 1, - 1, 0, - 80);

      tf = fso.CreateTextFile(strFile, true, true);
      tf.WriteLine("// WPI Options 8.0.0");
      tf.WriteLine("//");
      tf.WriteLine("// User defined options");
      tf.WriteLine("//");

      // Window tab
      tf.WriteLine("");
      tf.WriteLine("");
      tf.WriteLine("// Window tab");
      tf.WriteLine("Resolution=" + document.getElementById("Resolution").value + ";");
      tf.WriteLine("MainWindowWidth=" + document.getElementById("MainWindowWidth").value + ";");
      tf.WriteLine("MainWindowHeight=" + document.getElementById("MainWindowHeight").value + ";");
      tf.WriteLine("MainWindowX=" + document.getElementById("MainWindowX").value + ";");
      tf.WriteLine("MainWindowY=" + document.getElementById("MainWindowY").value + ";");
      tf.WriteLine("InstallerWindowX=" + document.getElementById("InstallerWindowX").value + ";");
      tf.WriteLine("InstallerWindowY=" + document.getElementById("InstallerWindowY").value + ";");

      // General tab
      tf.WriteLine("");
      tf.WriteLine("");
      tf.WriteLine("// General tab");
      tf.WriteLine("NumCols=" + document.getElementById("NumCols").value + ";");
      tf.WriteLine("// ---");
      tf.WriteLine("Timer=" + document.getElementById("Timer").checked + ";");
      tf.WriteLine("Seconds=" + document.getElementById("Seconds").value + ";");
      tf.WriteLine("StartBeepAtSecs=" + document.getElementById("StartBeepAtSecs").value + ";");
      tf.WriteLine("// ---");
      tf.WriteLine("Language='"+LanguageCombo.getSelectedValue() +"';");
      tf.WriteLine("// ---");
      tf.WriteLine("DefaultInstallPath='"+document.getElementById("DefaultInstallPath").value +"';");
      txt = document.getElementById("CustomInstallPath").value;
      txt = txt.replace(/\\/g,"\\\\");
      tf.WriteLine("CustomInstallPath=['"+txt+"'];");
      tf.WriteLine("// ---");
      tf.WriteLine("AbortInstallIfFailure=" + document.getElementById("AbortInstallIfFailure").checked + ";");
      txt = document.getElementById("ExecuteCommandIfFailure").value;
      txt = txt.replace(/\\\\/g,"\\").replace(/\\/g,"\\\\");
      tf.WriteLine("ExecuteCommandIfFailure=['"+txt+"'];");
      tf.WriteLine("ContinueWhereFailed=" + document.getElementById("ContinueWhereFailed").checked + ";");

      // Features tab
      tf.WriteLine("");
      tf.WriteLine("");
      tf.WriteLine("// Features tab");
      tf.WriteLine("ShowExtraButtons=" + document.getElementById("ShowExtraButtons").checked + ";");
      tf.WriteLine("DoNotShowIfCD=" + document.getElementById("DoNotShowIfCD").checked + ";");
      tf.WriteLine("USSFSilentMode=" + document.getElementById("USSFSilentMode").checked + ";");
      tf.WriteLine("VerifyInstallHDD=" + document.getElementById("VerifyInstallHDD").checked + ";");
      tf.WriteLine("AllowCheckForInternet=" + document.getElementById("AllowCheckForInternet").checked + ";");
      tf.WriteLine("LoadDesktopBeforeInstall=" + document.getElementById("LoadDesktopBeforeInstall").checked + ";");
      tf.WriteLine("ReOpenAfterInstall=" + document.getElementById("ReOpenAfterInstall").checked + ";");
      tf.WriteLine("DisableCatCheckBoxes=" + document.getElementById("DisableCatCheckBoxes").checked + ";");
      tf.WriteLine("SortWithinCats=" + document.getElementById("SortWithinCats").checked + ";");
      tf.WriteLine("DisableOnDepsNotMet=" + document.getElementById("DisableOnDepsNotMet").checked + ";");
      tf.WriteLine("AlwaysUseScrollBar=" + document.getElementById("AlwaysUseScrollBar").checked + ";");
      tf.WriteLine("DontSplitCats=" + document.getElementById("DontSplitCats").checked + ";");
      tf.WriteLine("InstallByCategory=" + document.getElementById("InstallByCategory").checked + ";");
      tf.WriteLine("ReallyForce=" + document.getElementById("ReallyForce").checked + ";");
      tf.WriteLine("DisableIfDoGray=" + document.getElementById("DisableIfDoGray").checked + ";");
      tf.WriteLine("InstallFonts=" + document.getElementById("InstallFonts").checked + ";");
      tf.WriteLine("ShowCommandInInstaller=" + document.getElementById("ShowCommandInInstaller").checked + ";");
      tf.WriteLine("ShowInstallerImages=" + document.getElementById("ShowInstallerImages").checked + ";");
      tf.WriteLine("AlwaysShowOutputWindow=" + document.getElementById("AlwaysShowOutputWindow").checked + ";");
      tf.WriteLine("EjectCDWhenDone=" + document.getElementById("EjectCDWhenDone").checked + ";");
      tf.WriteLine("DoNotShowIfUSB=" + document.getElementById("DoNotShowIfUSB").checked + ";");
      tf.WriteLine("DisableHotKeys=" + document.getElementById("DisableHotKeys").checked + ";");
      tf.WriteLine("ShowDownloadOutput=" + document.getElementById("ShowDownloadOutput").checked + ";");
      tf.WriteLine("DisableInstallCombobox=" + document.getElementById("DisableInstallCombobox").checked + ";");
      tf.WriteLine("MaintainAutoLogonCount=" + document.getElementById("MaintainAutoLogonCount").checked + ";");

      // Tools tab
      tf.WriteLine("");
      tf.WriteLine("");
      tf.WriteLine("// Tools tab");
      tf.WriteLine("ExecuteBeforeEnabled=" + document.getElementById("ExecuteBeforeEnabled").checked + ";");
      txt = document.getElementById("ExecuteBefore").value;
      txt = txt.replace(/\\\\/g,"\\").replace(/\\/g,"\\\\");
      tf.WriteLine("ExecuteBefore=['"+txt+"'];");
      tf.WriteLine("ExecuteAfterEnabled=" + document.getElementById("ExecuteAfterEnabled").checked + ";");
      txt = document.getElementById("ExecuteAfter").value;
      txt = txt.replace(/\\\\/g,"\\").replace(/\\/g,"\\\\");
      tf.WriteLine("ExecuteAfter=['"+txt+"'];");
      tf.WriteLine("// ---");
      tf.WriteLine("RestartComputer=" + document.getElementById("RestartComputer").checked + ";");
      if (document.all.RestartType[0].checked)
      tf.WriteLine("RestartType=0;");
      if (document.all.RestartType[1].checked)
      tf.WriteLine("RestartType=1;");
      tf.WriteLine("RestartSeconds=" + document.getElementById("RestartSeconds").value + ";");
      tf.WriteLine("DoNotLoadDesktop=" + document.getElementById("DoNotLoadDesktop").checked + ";");
      tf.WriteLine("// ---");
      tf.WriteLine("LogInstallation=" + document.getElementById("LogInstallation").checked + ";");
      txt = document.getElementById("LogPath").value;
      txt = txt.replace(/\\\\/g,"\\").replace(/\\/g,"\\\\");
      tf.WriteLine("LogPath=['"+txt+"'];");
      tf.WriteLine("TimeStampLogFile=" + document.getElementById("TimeStampLogFile").checked + ";");

      // Audio tab
      tf.WriteLine("");
      tf.WriteLine("");
      tf.WriteLine("// Audio tab");
      tf.WriteLine("PlayAudioInInstaller=" + document.getElementById("PlayAudioInInstaller").checked + ";");
      ExtractInstallAudioValues();
      if (InstallAudio.length > 0)
      {
         Songs.splice(0, Songs.length);
         Songs = InstallAudio.split(",");
         for (var j = 0; j < Songs.length; j ++ )										// For apostrophes
         Songs[j] = Songs[j].replace(/\\/g,"\\\\").replace(/'/g,"\\'");
         tf.WriteLine("InstallAudio=['"+Songs.join("','")+"'];");
      }
      else
      tf.WriteLine("InstallAudio=[];");
      tf.WriteLine("Volume=" + VolumeSlider.getValue() + ";");
      tf.WriteLine("Shuffle=" + document.getElementById("ShuffleAudio").checked + ";");
      tf.WriteLine("CopyAudioFolder=" + document.getElementById("CopyAudioFolder").checked + ";");
      txt = document.getElementById("CopyAudioPath").value;
      txt = txt.replace(/\\\\/g,"\\").replace(/\\/g,"\\\\");
      tf.WriteLine("CopyAudioPath=['"+txt+"'];");
      tf.WriteLine("DeleteAudioFolder=" + document.getElementById("DeleteAudioFolder").checked + ";");

      // Sounds tab
      tf.WriteLine("");
      tf.WriteLine("");
      tf.WriteLine("// Sounds tab");
      tf.WriteLine("SndWPIStartCB=" + document.getElementById("SndWPIStartCB").checked + ";");
      txt = document.getElementById("SndWPIStart").value;
      txt = txt.replace(/\\\\/g,"\\").replace(/\\/g,"\\\\");
      tf.WriteLine("SndWPIStart=['"+txt+"'];");
      tf.WriteLine("SndInstallStartCB=" + document.getElementById("SndInstallStartCB").checked + ";");
      txt = document.getElementById("SndInstallStart").value;
      txt = txt.replace(/\\\\/g,"\\").replace(/\\/g,"\\\\");
      tf.WriteLine("SndInstallStart=['"+txt+"'];");
      tf.WriteLine("SndInstallSuccessCB=" + document.getElementById("SndInstallSuccessCB").checked + ";");
      txt = document.getElementById("SndInstallSuccess").value;
      txt = txt.replace(/\\\\/g,"\\").replace(/\\/g,"\\\\");
      tf.WriteLine("SndInstallSuccess=['"+txt+"'];");
      tf.WriteLine("SndInstallWarningCB=" + document.getElementById("SndInstallWarningCB").checked + ";");
      txt = document.getElementById("SndInstallWarning").value;
      txt = txt.replace(/\\\\/g,"\\").replace(/\\/g,"\\\\");
      tf.WriteLine("SndInstallWarning=['"+txt+"'];");
      tf.WriteLine("SndInstallFailCB=" + document.getElementById("SndInstallFailCB").checked + ";");
      txt = document.getElementById("SndInstallFail").value;
      txt = txt.replace(/\\\\/g,"\\").replace(/\\/g,"\\\\");
      tf.WriteLine("SndInstallFail=['"+txt+"'];");
      tf.WriteLine("SndInstallFinishCB=" + document.getElementById("SndInstallFinishCB").checked + ";");
      txt = document.getElementById("SndInstallFinish").value;
      txt = txt.replace(/\\\\/g,"\\").replace(/\\/g,"\\\\");
      tf.WriteLine("SndInstallFinish=['"+txt+"'];");
      tf.WriteLine("SndWPIExitCB=" + document.getElementById("SndWPIExitCB").checked + ";");
      txt = document.getElementById("SndWPIExit").value;
      txt = txt.replace(/\\\\/g,"\\").replace(/\\/g,"\\\\");
      tf.WriteLine("SndWPIExit=['"+txt+"'];");

      isOptionsSaved = true;
   }
   catch(ex)
   {
      alert(getText(errCouldNotSaveFile) + "\n\n" + getText(lblFile) + ": " + strFile + "\n" + getText(lblErrorNumber) + ": " + (ex.number & 0xffff) + "\n" + getText(lblErrorDescription) + ": " + ex.description);
   }
   finally
   {
      try
      {
         tf.Close();
      }
      catch (ex0)
      {
         ;

      }
   }

   strFile = windowFile;
   try
   {
      tf = fso.CreateTextFile(strFile, true, true);
      tf.WriteLine("// WPI Options 8.0.0");
      tf.WriteLine("//");
      tf.WriteLine("// User defined options");
      tf.WriteLine("//");

      // Window tab
      tf.WriteLine("");
      tf.WriteLine("");
      tf.WriteLine("// Window tab");
      tf.WriteLine("WindowShowBorder=" + document.getElementById("ShowWindowBorder").checked + ";");
      tf.WriteLine("WindowBorderType='"+document.getElementById("BorderType").value +"';");
      tf.WriteLine("WindowInnerBorder=" + document.getElementById("InnerBorder").checked + ";");
      tf.WriteLine("WindowBorderStyle='"+document.getElementById("BorderStyle").value +"';");
      tf.WriteLine("WindowCaption=" + document.getElementById("ShowTitleBar").checked + ";");
      tf.WriteLine("WindowSysMenu=" + document.getElementById("SysMenuEnabled").checked + ";");
      tf.WriteLine("WindowMinimizeButton=" + document.getElementById("MinimizeEnabled").checked + ";");
      tf.WriteLine("WindowStartingState='"+document.getElementById("StartingWindowState").value +"';");
      tf.WriteLine("WindowShowInTaskBar=" + document.getElementById("ShowInTaskBar").checked + ";");
   }
   catch(ex)
   {
      alert(getText(errCouldNotSaveFile) + "\n\n" + getText(lblFile) + ": " + strFile + "\n" + getText(lblErrorNumber) + ": " + (ex.number & 0xffff) + "\n" + getText(lblErrorDescription) + ": " + ex.description);
   }
   finally
   {
      try
      {
         tf.Close();
      }
      catch (ex0)
      {
         ;

      }
   }

   strFile = wpipath + "\\Audio\\Install.m3u";
   try
   {
      tf = fso.CreateTextFile(strFile, true);
      // Can't use Unicode here.  Plain text only.

      ExtractInstallAudioValues();
      if (InstallAudio.length > 0)
      {
         Songs.splice(0, Songs.length);
         Songs = InstallAudio.split(",");
         for (var i = 0; i < Songs.length; i ++ )
         {
            if (document.getElementById("CopyAudioFolder").checked)
            tf.WriteLine(ReplacePath(document.getElementById("CopyAudioPath").value) + "\\" + Songs[i]);
            else
            tf.WriteLine(Songs[i]);
         }
      }
      else
      tf.Write("");
   }
   catch(ex)
   {
      alert(getText(errCouldNotSaveFile) + "\n\n" + getText(lblFile) + ": " + strFile + "\n" + getText(lblErrorNumber) + ": " + (ex.number & 0xffff) + "\n" + getText(lblErrorDescription) + ": " + ex.description);
   }
   finally
   {
      try
      {
         tf.Close();
      }
      catch (ex0)
      {
         ;

      }

      Pause(1, 0);
      CloseAlert(0);
   }
}

function ShowOptions()
{
   position = "optionswizard.js";
   whatfunc = "ShowOptions()";

   stopInterval();

   ManualSection = "Options";

   CreateOptionsPage();
   OptionsWizardOpen = true;

   AtStartUp = false;

   UserOptionsDefaults();
   WindowOptionsDefaults();
   ReadOptions();

   SetNOSSAState(false);
}

function HideOptions(reload)
{
   position = "optionswizard.js";
   whatfunc = "HideOptions()";

   WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\OptionsFile", optionsFile, "REG_SZ");

   if (dhxWins.isWindow("OptionsWindow"))
   {
      OptionsWindow.close();
      OptionsWindow = null;

      OptionsWizardOpen = false;
   }

   if (reload)
   RefreshWPI();
}

function ToggleOptions()
{
   position = "optionswizard.js";
   whatfunc = "ToggleOptions()";

   if (ReadMeWindow != null || AboutWindow != null)
   return;
   if (ConfigWizardOpen || NetworkWizardOpen || ThemeWizardOpen)
   {
      Alert("", getText(txtCanNotSwitchWizards), getText(lblOK), "", 3, 0, 0, 0);
      return;
   }

   if ( ! dhxWins.isWindow("OptionsWindow"))
   {
      isOptionsSaved = true;
      ShowOptions();
   }
   else
   {
      if (isOptionsSaved)
      HideOptions(true);
      else
      {
         if (Alert("", getText(txtDiscardChanges), getText(lblOK) + "|" + getText(lblCancel), "", 5, 0, 0, 0))
         {
            isOptionsSaved = true;
            HideOptions(true);
         }
      }
   }
}
