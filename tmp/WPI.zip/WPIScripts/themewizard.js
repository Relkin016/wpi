//************************************************
// Windows Post-Install Wizard
// themewizard.js
//************************************************

	// Temporary solution
	var FoundOldStyle=false;

function ThemeUpdated()
{
	position="themewizard.js";
	whatfunc="ThemeUpdated()";

	isThemeSaved=false;
}

function CreateThemePage()
{
	position="themewizard.js";
	whatfunc="CreateThemePage()";

	var zone=0;

	ThemeWindow=dhxWins.createWindow("ThemeWindow", 50, 50, 750, 580);
	ThemeWindow.setText(getText(lblThemeWizard));
	ThemeWindow.setModal(true);
	ThemeWindow.button("park").hide();
	ThemeWindow.button("minmax1").hide();
	ThemeWindow.button("close").hide();
	ThemeWindow.keepInViewport(true);
	ThemeWindow.denyResize();
	ThemeWindow.center();
	ActiveWindow=ThemeWindow.getText();
	BlockWindow="ThemeWindow";

	StatusBar=ThemeWindow.attachStatusBar();

	var newDiv=document.createElement("div");
	var objDiv=document.getElementById("layergroup");

	newDiv.id="layertheme";
	newDiv.style.display="none";
	newDiv.style.overflow="auto";
	newDiv.style.width="100%";
	newDiv.style.height="100%";
	newDiv.style.padding="10px";

	objDiv.appendChild(newDiv);

	ThemeWindow.attachObject("layertheme");
	document.getElementById("layertheme").style.visibility='hidden';

	CreateTab("\\Common\\themewizardtemplate.htm","layertheme");
	CreateTab("\\Common\\themewizardtemplate_style.htm","tabtabStyle");
	CreateTab("\\Common\\themewizardtemplate_tooltips.htm","tabtabToolTips");

	themeTabs=new dhtmlXTabBar("ThemeTabs","top");
	themeTabs.setImagePath("../common/codebase/imgs/");
	themeTabs.setStyle(dhxSkin);
	themeTabs.enableForceHiding(true);
	var tablist=new Array('tabStyle','tabToolTips');
	for (var i=0; i<tablist.length; i++)
	{
		themeTabs.addTab("Tab"+(i+1).toString(),getText(eval(tablist[i])),""+Math.round((parseInt(document.getElementById("ThemeTabs").offsetWidth)-16)/tablist.length)+"px");
	}

	LocalizeThemeTexts();

	InstallBgsSkinCombo=new dhtmlXCombo("InstallBgsSkinZone","zone"+(zone++),460,"image");
	InstallBgsSkinCombo.enableOptionAutoPositioning(true);
	InstallBgsSkinCombo.setOptionHeight(200);
	InstallBgsSkinCombo.attachEvent("onSelectionChange",ThemeUpdated);
	InstallBgsSkinCombo._addOption({value:"none", text:getText(optNone), img_src:"../Common/imgs/spacer.gif"});
	
	GetInstallBgs(InstallBgsSkinCombo);

	ProgBarsSkinCombo=new dhtmlXCombo("ProgBarsSkinZone","zone"+(zone++),430,"image");
	ProgBarsSkinCombo.enableOptionAutoPositioning(true);
	ProgBarsSkinCombo.setOptionHeight(200);
	ProgBarsSkinCombo.attachEvent("onSelectionChange",ThemeUpdated);
	GetProgressBars(ProgBarsSkinCombo);

    ColorPicker = new dhtmlXColorPicker("ColorPickerZone",false,true,true,false);
    ColorPicker.setImagePath("../common/codebase/imgs/");
	ColorPicker.loadUserLanguage("custom");
    ColorPicker.init();
	ColorPicker.setOnSelectHandler(SetColorPickerStringValue);
	ColorPicker.hideOnSelect(true);

	GetFonts("TitleFontFace");

	TitleFontSizeSlider=new dhtmlxSlider("TitleFontSize",150,dhxSkin,false,8,36,10,1);
	TitleFontSizeSlider.setImagePath("../common/codebase/imgs/");
	TitleFontSizeSlider.attachEvent("onChange",SetTitleFontSizeValue);
	TitleFontSizeSlider.init();

	GetFonts("BodyFontFace");

	BodyFontSizeSlider=new dhtmlxSlider("BodyFontSize",150,dhxSkin,false,8,36,8,1);
	BodyFontSizeSlider.setImagePath("../common/codebase/imgs/");
	BodyFontSizeSlider.attachEvent("onChange",SetBodyFontSizeValue);
	BodyFontSizeSlider.init();
	BorderSizeSlider=new dhtmlxSlider("BorderSize",150,dhxSkin,false,0,10,2,1);
	BorderSizeSlider.setImagePath("../common/codebase/imgs/");
	BorderSizeSlider.attachEvent("onChange",SetBorderSizeValue);
	BorderSizeSlider.init();

	TextPaddingSlider=new dhtmlxSlider("TextPadding",150,dhxSkin,false,0,25,0,1);
	TextPaddingSlider.setImagePath("../common/codebase/imgs/");
	TextPaddingSlider.attachEvent("onChange",SetTextPaddingValue);
	TextPaddingSlider.init();

	TransitionDurationSlider=new dhtmlxSlider("TransitionDuration",150,dhxSkin,false,0,2,0.4,0.1);
	TransitionDurationSlider.setImagePath("../common/codebase/imgs/");
	TransitionDurationSlider.attachEvent("onChange",SetTransitionDurationValue);
	TransitionDurationSlider.init();

	TransparencySlider=new dhtmlxSlider("Transparency",150,dhxSkin,false,0,99,0,1);
	TransparencySlider.setImagePath("../common/codebase/imgs/");
	TransparencySlider.attachEvent("onChange",SetTransparencyValue);
	TransparencySlider.init();

	ShadowStrengthSlider=new dhtmlxSlider("ShadowStrength",150,dhxSkin,false,0,25,3,1);
	ShadowStrengthSlider.setImagePath("../common/codebase/imgs/");
	ShadowStrengthSlider.attachEvent("onChange",SetShadowStrengthValue);
	ShadowStrengthSlider.init();

	for (var i=0; i<tablist.length; i++)
	{
		themeTabs.setContent("Tab"+(i+1).toString(),"tab"+tablist[i]);
	}

	themeTabs.setTabActive('Tab1');

	document.getElementById("layertheme").style.visibility='visible';
	document.getElementById("layertheme").style.display='block';
}

function LocalizeThemeTexts()
{
	position="themewizard.js";
	whatfunc="LocalizeThemeTexts()";

	with (document)
	{
		getElementById("legSelectedTheme").innerHTML=getText(lblSelectedTheme);
		getElementById("legSelectedSkin").innerHTML=getText(lblSelectedSkin);
		getElementById("legCustomBgPicture").innerHTML=getText(lblCustomBgPicture);
		getElementById("legSkins").innerHTML=getText(legSkins);
		getElementById("lblInstallBgsSkin").innerHTML=getText(lblInstallBgsSkin);
		getElementById("lblProgBarsSkin").innerHTML=getText(lblProgBarsSkin);
		getElementById("legLayoutStyle").innerHTML=getText(legLayoutStyle);
		getElementById("optLayoutStyle1").innerHTML=getText(optLayoutStyle1);
		getElementById("optLayoutStyle2").innerHTML=getText(optLayoutStyle2);
		getElementById("optLayoutStyle3").innerHTML=getText(optLayoutStyle3);
		getElementById("optLayoutStyle4").innerHTML=getText(optLayoutStyle4);
		getElementById("legGlobalOptions").innerHTML=getText(legGlobalOptions);
		getElementById("lblShowToolTips").innerHTML=getText(lblShowToolTips);
		getElementById("legTitleText").innerHTML=getText(legTitleText);
		getElementById("lblTitleTextColor").innerHTML=getText(lblTitleTextColor);
		getElementById("lblTitleBgColor").innerHTML=getText(lblTitleBgColor);
		getElementById("lblTitleBgImage").innerHTML=getText(lblTitleBgImage);
		getElementById("lblTitleTextAlign").innerHTML=getText(lblTitleTextAlign);
		getElementById("lblTitleFontFace").innerHTML=getText(lblTitleFontFace);
		getElementById("lblTitleFontSize").innerHTML=getText(lblTitleFontSize);
		getElementById("legBodyText").innerHTML=getText(legBodyText);
		getElementById("lblBodyTextColor").innerHTML=getText(lblBodyTextColor);
		getElementById("lblBodyBgColor").innerHTML=getText(lblBodyBgColor);
		getElementById("lblBodyBgImage").innerHTML=getText(lblBodyBgImage);
		getElementById("lblBodyTextAlign").innerHTML=getText(lblBodyTextAlign);
		getElementById("lblBodyFontFace").innerHTML=getText(lblBodyFontFace);
		getElementById("lblBodyFontSize").innerHTML=getText(lblBodyFontSize);
		getElementById("legDimensions").innerHTML=getText(legDimensions);
		getElementById("lblTipWidth").innerHTML=getText(lblTipWidth);
		getElementById("lblTipHeight").innerHTML=getText(lblTipHeight);
		getElementById("legBorder").innerHTML=getText(legBorder);
		getElementById("lblBorderSize").innerHTML=getText(lblBorderSize);
		getElementById("lblBorderColor").innerHTML=getText(lblBorderColor);
		getElementById("legTextPadding").innerHTML=getText(legTextPadding);
		getElementById("legTransitions").innerHTML=getText(legTransitions);
		getElementById("lblTransition").innerHTML=getText(lblTransition);
		getElementById("lblDuration").innerHTML=getText(lblDuration);
		getElementById("legTransparency").innerHTML=getText(legTransparency);
		getElementById("legShadow").innerHTML=getText(legShadow);
		getElementById("lblShadowType").innerHTML=getText(lblShadowType);
		getElementById("lblShadowColor").innerHTML=getText(lblShadowColor);
		getElementById("lblShadowStrength").innerHTML=getText(lblShadowStrength);
		getElementById("legAppearance").innerHTML=getText(legAppearance);
		getElementById("lblAppearanceBehavior").innerHTML=getText(lblAppearanceBehavior);
		getElementById("lblTipPositionType").innerHTML=getText(lblTipPositionType);
		getElementById("legLocation").innerHTML=getText(legLocation);
		getElementById("lblTipXpos").innerHTML=getText(lblTipXpos);
		getElementById("lblTipYpos").innerHTML=getText(lblTipYpos);
		getElementById("themeRead").innerHTML=getText(btnRead);
		getElementById("themeSave").innerHTML=getText(btnSave);
		getElementById("themeExit").innerHTML=getText(btnExit);

		with (getElementById("TitleTextAlign"))
		{
			options[0].text=getText(optLeft);
			options[1].text=getText(optCenter);
			options[2].text=getText(optRight);
		}
		with (getElementById("BodyTextAlign"))
		{
			options[0].text=getText(optLeft);
			options[1].text=getText(optCenter);
			options[2].text=getText(optRight);
		}
with (getElementById("Transition"))
  {
   options[0].text=getText(tranBoxIn);
   options[1].text=getText(tranBoxOut);
   options[2].text=getText(tranCircleIn);
   options[3].text=getText(tranCircleOut);
   options[4].text=getText(tranWipeUp);
   options[5].text=getText(tranWipeDown);
   options[6].text=getText(tranWipeRight);
   options[7].text=getText(tranWipeLeft);
   options[8].text=getText(tranVerticalBlinds);
   options[9].text=getText(tranHorizontalBlinds);
   options[10].text=getText(tranCheckerboardAcross);
   options[11].text=getText(tranCheckerboardDown);
   options[12].text=getText(tranRandomDissolve);
   options[13].text=getText(tranSplitVerticalIn);
   options[14].text=getText(tranSplitVerticalOut);
   options[15].text=getText(tranSplitHorizontalIn);
   options[16].text=getText(tranSplitHorizontalOut);
   options[17].text=getText(tranStripsLeftDown);
   options[18].text=getText(tranStripsLeftUp);
   options[19].text=getText(tranStripsRightDown);
   options[20].text=getText(tranStripsRightUp);
   options[21].text=getText(tranRandomBarsHorizontal);
   options[22].text=getText(tranRandomBarsVertical);
   options[23].text=getText(tranRandom);
   options[24].text=getText(tranFade);
   options[25].text=getText(tranGradientWipeDown);
   options[26].text=getText(tranGradientWipeLeft);
   options[27].text=getText(tranGradientWipeRight);
   options[28].text=getText(tranGradientWipeUp);
   options[29].text=getText(tranInset);
   options[30].text=getText(tranIrisCrossIn);
   options[31].text=getText(tranIrisCrossOut);
   options[32].text=getText(tranIrisDiamondIn);
   options[33].text=getText(tranIrisDiamondOut);
   options[34].text=getText(tranIrisPlusIn);
   options[35].text=getText(tranIrisPlusOut);
   options[36].text=getText(tranIrisStarIn);
   options[37].text=getText(tranIrisStarOut);
   options[38].text=getText(tranPixelate);
   options[39].text=getText(tranRadialWipeClock);
   options[40].text=getText(tranRadialWipeRadial);
   options[41].text=getText(tranRadialWipeWedge);
   options[42].text=getText(tranSlide);
   options[43].text=getText(tranSlidePush);
   options[44].text=getText(tranSlideSwap);
   options[45].text=getText(tranSpiral);
   options[46].text=getText(tranStretch);
   options[47].text=getText(tranStretchPush);
   options[48].text=getText(tranStretchSpin);
   options[49].text=getText(tranWheel);
   options[50].text=getText(tranZigZag);
   options[51].text=getText(optNone); 
  }
		with (getElementById("ShadowType"))
		{
			options[0].text=getText(optNone);
			options[1].text=getText(optSimple);
			options[2].text=getText(optComplex);
		}
		with (getElementById("AppearanceBehavior"))
		{
			options[0].text=getText(optNormal);
			options[1].text=getText(optStatic);
			options[2].text=getText(optVisible);
			options[3].text=getText(optSticky);
			options[4].text=getText(optFloat);
		}
		with (getElementById("TipPositionType"))
		{
			options[0].text=getText(optRight);
			options[1].text=getText(optLeft);
			options[2].text=getText(optCenter);
			options[3].text=getText(optFixed);
		}
	}
}

function HandleThemeSelection()
{
	position="themewizard.js";
	whatfunc="HandleThemeSelection()";

	Theme=document.getElementById("Theme").value;
	if (!CheckThemeVersion())
	{
		document.getElementById("Theme").value=DefaultTheme;
		Theme=document.getElementById("Theme").value;
	}

	LoadThemeStyle();
}

function HandleSkinSelection()
{
	position="themewizard.js";
	whatfunc="HandleSkinSelection()";
	return true;
}

function CopySkinFiles()
{
	position="themewizard.js";
	whatfunc="CopySkinFiles()";

	try
	{
		RunCmd('CMD /C xcopy "'+wpipath+'\\Common\\Skins\\'+document.getElementById("ThemeSkin").value+'" "'+wpipath+'\\Common\\Codebase" /C /I /E /Y /H /R',false,true);
	}
	catch (ex)
	{
		Alert("",getText(txtCouldNotCopySkin),getText(lblOK),"",2,0,0,0);
	}
}

function GetBgPictureName()
{
	position="themewizard.js";
	whatfunc="GetBgPictureName()";

	var lastSlash;

	tempName=document.getElementById("BgPictureBrowse").value;
	lastSlash=tempName.lastIndexOf("\\");

	BrowseName=tempName.substring(lastSlash+1,tempName.length);
}

function clearSetBgPicturePathBrowse()
{
	position="themewizard.js";
	whatfunc="clearSetBgPicturePathBrowse()";

	document.getElementById("div_BgPictureBrowse").innerHTML="";
	document.getElementById("div_BgPictureBrowse").innerHTML='<input id="BgPictureBrowse" type="file" style="display:none;">';
}

function SetBgPicturePath()
{
	position="themewizard.js";
	whatfunc="SetBgPicturePath()";

	if (document.getElementById("BgPictureBrowse").value != "")
	{
		GetBgPictureName();
		document.getElementById("BgPicture").value=BrowseName;
	}
}

function FillInToolTips()
{
	position="themewizard.js";
	whatfunc="FillInToolTips()";
	document.getElementById("TitleTextColor").value=Style[0][0];
	document.getElementById("TitleBgColor").value=Style[0][1];
	document.getElementById("TitleBgImage").value=Style[0][2];
	document.getElementById("TitleTextAlign").value=Style[0][3];
	document.getElementById("TitleFontFace").value=Style[0][4];
	TitleFontSizeSlider.setValue(Style[0][5]);
	SetTitleFontSizeValue(Style[0][5],TitleFontSizeSlider);
	document.getElementById("BodyTextColor").value=Style[0][6];
	document.getElementById("BodyBgColor").value=Style[0][7];
	document.getElementById("BodyBgImage").value=Style[0][8];
	document.getElementById("BodyTextAlign").value=Style[0][9];
	document.getElementById("BodyFontFace").value=Style[0][10];
	BodyFontSizeSlider.setValue(Style[0][11]);
	SetBodyFontSizeValue(Style[0][11],BodyFontSizeSlider);
	document.getElementById("TipWidth").value=Style[0][12];
	document.getElementById("TipHeight").value=Style[0][13];
	BorderSizeSlider.setValue(Style[0][14]);
	SetBorderSizeValue(Style[0][14],BorderSizeSlider);
	document.getElementById("BorderColor").value=Style[0][15];
	TextPaddingSlider.setValue(Style[0][16]);
	SetTextPaddingValue(Style[0][16],TextPaddingSlider);
	document.getElementById("Transition").value=Style[0][17];
	TransitionDurationSlider.setValue(Style[0][18]);
	SetTransitionDurationValue(Style[0][18],TransitionDurationSlider);
	TransparencySlider.setValue(Style[0][19]);
	SetTransparencyValue(Style[0][19],TransparencySlider);
	document.getElementById("ShadowType").value=Style[0][20];
	document.getElementById("ShadowColor").value=Style[0][21];
	ShadowStrengthSlider.setValue(TipShadowStrength);
	SetShadowStrengthValue(TipShadowStrength,ShadowStrengthSlider);
	document.getElementById("AppearanceBehavior").value=Style[0][22];
	document.getElementById("TipPositionType").value=Style[0][23];
	document.getElementById("Xpos").value=Style[0][24];
	document.getElementById("Ypos").value=Style[0][25];
}

function HandleShowToolTipsSelection()
{
	position="themewizard.js";
	whatfunc="HandleShowToolTipsSelection()";

	if (document.getElementById("ShowToolTips").checked)
	{
	}
	else
	{
	}
}

function SetWhichColorPicker(which)
{
	position="themewizard.js";
	whatfunc="SetWhichColorPicker()";

	if (which==null || which=="")
		return;

	WhichColorPicker=which;

	if (document.getElementById(which).value !="")
		ColorPicker.setColor(document.getElementById(which).value);
}

function SetColorPickerStringValue(color)
{
	position="themewizard.js";
	whatfunc="SetColorPickerStringValue()";

	if (WhichColorPicker=="")
		return;

	document.getElementById(WhichColorPicker).value=color;
	WhichColorPicker="";

	ThemeUpdated();
}

function GetTitleBgImageName()
{
	position="themewizard.js";
	whatfunc="GetTitleBgImageName()";

	var lastSlash;

	tempName=document.getElementById("TitleBgImageBrowse").value;
	lastSlash=tempName.lastIndexOf("\\");

	BrowseName=tempName.substring(lastSlash+1,tempName.length);
}

function clearSetTitleBgImagePathBrowse()
{
	position="themewizard.js";
	whatfunc="clearSetTitleBgImagePathBrowse()";

	document.getElementById("div_TitleBgImageBrowse").innerHTML="";
	document.getElementById("div_TitleBgImageBrowse").innerHTML='<input id="TitleBgImageBrowse" type="file" style="display:none;">';
}

function SetTitleBgImagePath()
{
	position="themewizard.js";
	whatfunc="SetTitleBgImagePath()";

	if (document.getElementById("TitleBgImageBrowse").value != "")
	{
		GetTitleBgImageName();
		document.getElementById("TitleBgImage").value=BrowseName;
	}
}

function SetTitleFontSizeValue(value,slider)
{
	position="themewizard.js";
	whatfunc="SetTitleFontSizeValue()";

	document.getElementById("TitleFontSizeValue").innerHTML=(value ? value : "8")+getText(lblPt);

	ThemeUpdated();
}

function GetBodyBgImageName()
{
	position="themewizard.js";
	whatfunc="GetBodyBgImageName()";

	var lastSlash;

	tempName=document.getElementById("BodyBgImageBrowse").value;
	lastSlash=tempName.lastIndexOf("\\");

	BrowseName=tempName.substring(lastSlash+1,tempName.length);
}

function clearSetBodyBgImagePathBrowse()
{
	position="themewizard.js";
	whatfunc="clearSetBodyBgImagePathBrowse()";

	document.getElementById("div_BodyBgImageBrowse").innerHTML="";
	document.getElementById("div_BodyBgImageBrowse").innerHTML='<input id="BodyBgImageBrowse" type="file" style="display:none;">';
}

function SetBodyBgImagePath()
{
	position="themewizard.js";
	whatfunc="SetBodyBgImagePath()";

	if (document.getElementById("BodyBgImageBrowse").value != "")
	{
		GetBodyBgImageName();
		document.getElementById("BodyBgImage").value=BrowseName;
	}
}

function SetBodyFontSizeValue(value,slider)
{
	position="themewizard.js";
	whatfunc="SetBodyFontSizeValue()";

	document.getElementById("BodyFontSizeValue").innerHTML=(value ? value : "8")+getText(lblPt);

	ThemeUpdated();
}

function SetBorderSizeValue(value,slider)
{
	position="themewizard.js";
	whatfunc="SetBorderSizeValue()";

	document.getElementById("BorderSizeValue").innerHTML=(value ? value : "0")+getText(lblPx);

	ThemeUpdated();
}

function SetTextPaddingValue(value,slider)
{
	position="themewizard.js";
	whatfunc="SetTextPaddingValue()";

	document.getElementById("TextPaddingValue").innerHTML=(value ? value : "0")+getText(lblPx);

	ThemeUpdated();
}

function SetTransitionDurationValue(value,slider)
{
	position="themewizard.js";
	whatfunc="SetTransitionDurationValue()";

	document.getElementById("TransitionDurationValue").innerHTML=(value ? value : "0")+getText(lblSec);

	ThemeUpdated();
}

function SetTransparencyValue(value,slider)
{
	position="themewizard.js";
	whatfunc="SetTransparencyValue()";

	document.getElementById("TransparencyValue").innerHTML=(value ? value : "0")+"%";

	ThemeUpdated();
}

function SetShadowStrengthValue(value,slider)
{
	position="themewizard.js";
	whatfunc="SetShadowStrengthValue()";

	document.getElementById("ShadowStrengthValue").innerHTML=(value ? value : "3")+"px";

	ThemeUpdated();
}

function FillInThemeFile()
{
	position="themewizard.js";
	whatfunc="FillInThemeFile()";
	StatusBar.setText(themeFile);
}

function NewTheme()
{
	position="themewizard.js";
	whatfunc="NewTheme()";
	var temp;

	if (!isThemeSaved)
	{
		if (!Alert("",getText(txtDiscardChangesContinue),getText(lblOK)+"|"+getText(lblCancel),"",5,0,0,0))
			return;
	}
	temp=Alert("",getText(txtSaveThemeAs),getText(lblOK)+"|"+getText(lblCancel),themeFile,6,0,125,0);
	if (temp != null)
	{
		if (FileExists(temp))
		{
			if (!Alert("",temp+"\n\n"+getText(txtFileExistsReplace),getText(lblOK)+"|"+getText(lblCancel),"",5,0,0,0))
				return;
		}

		themeFile=temp;
		SetThemePath(true);

		UserThemeDefaults();
		SaveTheme();
	}
}

function themeClearReadBrowse()
{
	position="themewizard.js";
	whatfunc="themeClearReadBrowse()";

	document.getElementById("div_themeReadBrowse").innerHTML="";
	document.getElementById("div_themeReadBrowse").innerHTML='<input id="themeReadBrowse" type="file" style="display:none;">';
}

function HandleReadTheme()
{
	position="themewizard.js";
	whatfunc="HandleReadTheme()";

	if (!isThemeSaved)
	{
		if (!Alert("",getText(txtDiscardChangesContinue),getText(lblOK)+"|"+getText(lblCancel),"",5,0,0,0))
			return;
	}
	{
		isThemeSaved=true;
		SetThemePath(false);
		ReadTheme();
	}
}

function SetThemePath(mode)
{
	position="themewizard.js";
	whatfunc="SetThemePath()";

	var i, txt;

	if (!mode)
	{
	}
	else
	{
	}

	FillInThemeFile();
}

function GetThemePath()
{
	position="themewizard.js";
	whatfunc="GetThemePath()";

	var temp;

	temp=Alert("",getText(txtSaveThemeAs),getText(lblOK)+"|"+getText(lblCancel),themeFile,6,0,125,0);
	if (temp != null)
	{
		themeFile=temp;
		SetThemePath(true);
		SaveTheme();
	}
}

function UserThemeDefaults()
{
	position="themewizard.js";
	whatfunc="UserThemeDefaults()";
	SkinPreset='Win7';
	ThemeSkin='SkyBlue';
	BgPicture='';

	InstallBgsSkin='Blue_04';
	ProgBarsSkin='SkyBlue';

	LayoutStyle=1;

	ShowToolTips=true;
	Style[0]=["#ffffff","#000099","","left","Arial",10,"#000000","#e8e8ff","","left","Arial",8,,,2,"#000099",0,51,0.4,0,2,"#738da2",0,0,,];
	TipShadowStrength=3;

	if (document.getElementById("layertheme").style.display=='block')
	{
// Style tab
		document.getElementById("Theme").value=Theme;
		document.getElementById("ThemeSkin").value=ThemeSkin;
		document.getElementById("BgPicture").value=BgPicture;

		InstallBgsSkinCombo.setComboValue(InstallBgsSkin);
		ProgBarsSkinCombo.setComboValue(ProgBarsSkin);

		document.getElementById("LayoutStyle1").checked=true;

// Tool Tips tab
		document.getElementById("ShowToolTips").checked=ShowToolTips;

//		HandleShowToolTipsSelection();
		FillInToolTips();
		isThemeSaved=true;		// because of setting all the sliders
		FillInThemeFile();
	}
}

function GetThemeVersion()
{
	position="themewizard.js";
	whatfunc="GetThemeVersion()";

	var line=new String();
	var num=1, ver=-1;

	strFile=themeFile;
	if (FileExists(strFile))
	{
		try
		{
			tf=fso.OpenTextFile(strFile,1,0,-2);
			while (!tf.AtEndOfStream && num<2)
			{
				line=tf.ReadLine();
				if (line.indexOf("// WPI Options ") != -1)
				{
					line=line.replace(/[^0-9]/g,'');
					ver=Number(line);
				}
				else
					ver=0;
				num++;
			}
		}
		catch(ex)
		{ ; }
		finally
		{
			try
			{
				tf.Close();
			}
			catch (ex0)
			{ ; }
		}
	}

	return ver;
}

function ReadTheme()
{
	position="themewizard.js";
	whatfunc="ReadTheme()";

	var line=new String();
	var opt=new String();
	var val=new String();

	WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\ThemeFile",themeFile,"REG_SZ");

	strFile=themeFile;
	if (FileExists(strFile))
	{
		try
		{
			tf=fso.OpenTextFile(strFile,1,0,-2);
			while(true)
			{
				line=tf.ReadLine();

				if (line.search("^ *//")==0)
					continue;

				opt=line.substring(0,line.indexOf("="));
				val=line.substring(line.indexOf("=")+1,line.length-1);
				val=val.replace(/^ *\[ */,"").replace(/^ *' */,"");
				val=val.replace(/ *] *$/,"").replace(/ *' *$/,"");
				val=val.replace(/ *]; *$/,"").replace(/ *' *$/,"");
				val=val.replace(/\\\\/g,"\\");
				val=val.replace(/\\'/g,"'");

// Style tab
				if (opt=="Theme")
					document.getElementById("Theme").value=val.replace(/'/gi,"");
				if (opt=="ThemeSkin")
					document.getElementById("ThemeSkin").value=val.replace(/'/gi,"");
				if (opt=="BgPicture")
					document.getElementById("BgPicture").value=val.replace(/[\[\]'"]/g,"").replace(/\\\\/g,"\\");

				if (opt=="LayoutStyle")
				{
					if (val==4)
						document.getElementById("LayoutStyle4").checked=true;
					else if (val==3)
						document.getElementById("LayoutStyle3").checked=true;
					else if (val==2)
						document.getElementById("LayoutStyle2").checked=true;
					else
						document.getElementById("LayoutStyle1").checked=true;
				}

// Tool Tips tab
				if (opt=="ShowToolTips")
					document.getElementById("ShowToolTips").checked=val=="true" ? true : false;
			}
		}
		catch(ex)
		{ ; }
		finally
		{
			try
			{
				tf.Close();
			}
			catch (ex0)
			{ ; }
		}
	}
	else
	{
		alert(getText(errCouldNotOpenFile)+" '"+strFile+"'.\n\n"+getText(errUsingDefaultSet));
		UserThemeDefaults();
		SaveDefaultThemeOptions();
	}

	LoadThemeStyle();
}

function LoadThemeStyle()
{
	position="themewizard.js";
	whatfunc="LoadThemeStyle()";

	strFile=wpipath+"\\Themes\\"+Theme+"\\wpi_style.js";
	if (FileExists(strFile))
	{
		try
		{
			tf=fso.OpenTextFile(strFile,1,0,-2);
			while(true)
			{
				line=tf.ReadLine();

				if (line.search("^ *//")==0)
					continue;

				opt=line.substring(0,line.indexOf("="));
				val=line.substring(line.indexOf("=")+1,line.length-1);

// Style tab
				if (opt=="InstallBgsSkin")
					InstallBgsSkinCombo.setComboValue(val.replace(/'/gi,""));
				if (opt=="ProgBarsSkin")
					ProgBarsSkinCombo.setComboValue(val.replace(/'/gi,""));

				if (opt=="Style[0]")
					Style[0]=val.replace(/[\[\]]/g,"").replace(/\"/g,'').split(',');
				if (opt=="TipShadowStrength")
					TipShadowStrength=val;
			}
		}
		catch(ex)
		{ ; }
		finally
		{
			try
			{
				tf.Close();
			}
			catch (ex0)
			{ ; }
		}
	}
	else
	{
		alert(getText(errCouldNotOpenFile)+" '"+strFile+"'.\n\n"+getText(errUsingDefaultSet));
		SaveTheme();
		ReadTheme();
	}

//	HandleShowToolTipsSelection();
	FillInThemeFile();
	FillInToolTips();
	isThemeSaved=true;	// Because setting combo box event triggers it
}

function SaveDefaultThemeOptions()
{
	position="themewizard.js";
	whatfunc="SaveDefaultThemeOptions()";

	var txt=new String();

	strFile=themeFile;
	try
	{
		tf=fso.CreateTextFile(strFile,true,true);
		tf.WriteLine("// WPI Theme Options 8.0.0");
		tf.WriteLine("//");
		tf.WriteLine("// User defined options");
		tf.WriteLine("//");

// Style tab
		tf.WriteLine("");
		tf.WriteLine("");
		tf.WriteLine("// Style tab");
		tf.WriteLine("Theme='"+DefaultTheme+"';");
		tf.WriteLine("ThemeSkin='"+DefaultSkin+"';");
		tf.WriteLine("BgPicture='" +BgPicture+"';");
		tf.WriteLine("// ---");
		tf.WriteLine("LayoutStyle="+LayoutStyle+";");
		tf.WriteLine("");
		tf.WriteLine("");
		tf.WriteLine("// Tool Tips tab");
		tf.WriteLine("ShowToolTips="+ShowToolTips+";");
	}
	catch(ex)
	{
		alert(getText(errCouldNotSaveFile)+"\n\n"+getText(lblFile)+": "+strFile+"\n"+getText(lblErrorNumber)+": "+(ex.number & 0xffff)+"\n"+getText(lblErrorDescription)+": "+ex.description);

//		return;
	}
	finally
	{
		try
		{
			tf.Close();
		}
		catch (ex0)
		{ ; }
	}
}

function SaveTheme()
{
	position="themewizard.js";
	whatfunc="SaveTheme()";

	var txt=new String();

	if (fromCDDrive)
	{
		Alert("",getText(txtCanNotSaveToCD),getText(lblOK),"",2,0,0,0);

		return;
	}

	strFile=themeFile;
	try
	{
		Alert("","<center>"+getText(txtSavingThemeFile),"---none---","",1,-1,0,-80);

		tf=fso.CreateTextFile(strFile,true,true);

		tf.WriteLine("// WPI Theme Options 8.0.0");
		tf.WriteLine("//");
		tf.WriteLine("// User defined options");
		tf.WriteLine("//");

// Style tab
		tf.WriteLine("");
		tf.WriteLine("");
		tf.WriteLine("// Style tab");
		tf.WriteLine("Theme='"+document.getElementById("Theme").value +"';");
		tf.WriteLine("ThemeSkin='"+document.getElementById("ThemeSkin").value +"';");
		txt=document.getElementById("BgPicture").value;
		txt=txt.replace(/\\\\/g,"\\").replace(/\\/g,"\\\\");
		tf.WriteLine("BgPicture='"+txt+"';");
		tf.WriteLine("// ---");
		tf.WriteLine("InstallBgsSkin='" + InstallBgsSkinCombo.getSelectedValue() +"';");
		tf.WriteLine("ProgBarsSkin='" + ProgBarsSkinCombo.getSelectedValue() +"';");
		tf.WriteLine("// ---");
		if (document.getElementById("LayoutStyle4").checked)
			tf.WriteLine("LayoutStyle=4;");
		else if (document.getElementById("LayoutStyle3").checked)
			tf.WriteLine("LayoutStyle=3;");
		else if (document.getElementById("LayoutStyle2").checked)
			tf.WriteLine("LayoutStyle=2;");
		else
			tf.WriteLine("LayoutStyle=1;");
		tf.WriteLine("");
		tf.WriteLine("");
		tf.WriteLine("// Tool Tips tab");
		tf.WriteLine("ShowToolTips="+document.getElementById("ShowToolTips").checked+";");

		isThemeSaved=true;
	}
	catch(ex)
	{
		alert(getText(errCouldNotSaveFile)+"\n\n"+getText(lblFile)+": "+strFile+"\n"+getText(lblErrorNumber)+": "+(ex.number & 0xffff)+"\n"+getText(lblErrorDescription)+": "+ex.description);
	}
	finally
	{
		try
		{
			tf.Close();
		}
		catch (ex0)
		{ ; }
	}

	CopySkinFiles();

	strFile=wpipath+"\\Themes\\"+document.getElementById("Theme").value+"\\wpi_style.js";
	try
	{
		tf=fso.CreateTextFile(strFile,true,true);

		tf.WriteLine("// WPI Theme Options 8.0.0");
		tf.WriteLine("//");
		tf.WriteLine("// User defined options");
		tf.WriteLine("//");

// Style tab
		tf.WriteLine("");
		tf.WriteLine("");
		tf.WriteLine("// Style tab");
		tf.WriteLine("InstallBgsSkin='" + InstallBgsSkinCombo.getSelectedValue() +"';");
		tf.WriteLine("ProgBarsSkin='" + ProgBarsSkinCombo.getSelectedValue() +"';");
		tf.WriteLine("");
		tf.WriteLine("");
		tf.WriteLine("// Tool Tips tab");
		tf.Write("Style[0]=[");
		tf.Write('"'+document.getElementById("TitleTextColor").value+'",');
		tf.Write('"'+document.getElementById("TitleBgColor").value+'",');
		tf.Write('"'+document.getElementById("TitleBgImage").value+'",');
		tf.Write('"'+document.getElementById("TitleTextAlign").value+'",');
		tf.Write('"'+document.getElementById("TitleFontFace").value+'",');
		tf.Write(TitleFontSizeSlider.getValue()+',');
		tf.Write('"'+document.getElementById("BodyTextColor").value+'",');
		tf.Write('"'+document.getElementById("BodyBgColor").value+'",');
		tf.Write('"'+document.getElementById("BodyBgImage").value+'",');
		tf.Write('"'+document.getElementById("BodyTextAlign").value+'",');
		tf.Write('"'+document.getElementById("BodyFontFace").value+'",');
		tf.Write(BodyFontSizeSlider.getValue()+',');
		tf.Write(document.getElementById("TipWidth").value+',');
		tf.Write(document.getElementById("TipHeight").value+',');
		tf.Write(BorderSizeSlider.getValue()+',');
		tf.Write('"'+document.getElementById("BorderColor").value+'",');
		tf.Write(TextPaddingSlider.getValue()+',');
		tf.Write(document.getElementById("Transition").value+',');
		tf.Write(TransitionDurationSlider.getValue()+',');
		tf.Write(TransparencySlider.getValue()+',');
		tf.Write(document.getElementById("ShadowType").value+',');
		tf.Write('"'+document.getElementById("ShadowColor").value+'",');
		tf.Write(document.getElementById("AppearanceBehavior").value+',');
		tf.Write(document.getElementById("TipPositionType").value+',');
		tf.Write(document.getElementById("Xpos").value+',');
		tf.Write(document.getElementById("Ypos").value+'');
		tf.Write("];");
		tf.WriteLine("");
		tf.WriteLine("TipShadowStrength=" + ShadowStrengthSlider.getValue() +";");
	}
	catch(ex)
	{
		alert(getText(errCouldNotSaveFile)+"\n\n"+getText(lblFile)+": "+strFile+"\n"+getText(lblErrorNumber)+": "+(ex.number & 0xffff)+"\n"+getText(lblErrorDescription)+": "+ex.description);
	}
	finally
	{
		try
		{
			tf.Close();
		}
		catch (ex0)
		{ ; }

		Pause(1,0);
		CloseAlert(0);
	}
}

function ShowTheme()
{
	position="themewizard.js";
	whatfunc="ShowTheme()";

	stopInterval();

	ManualSection="Theme";

	CreateThemePage();
	ThemeWizardOpen=true;

	AtStartUp=false;
	GetThemes("Theme");
	GetSkins("ThemeSkin");

	UserThemeDefaults();
	ReadTheme();

	SetNOSSAState(false);
}

function HideTheme(reload)
{
	position="themewizard.js";
	whatfunc="HideTheme()";

	WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\ThemeFile",themeFile,"REG_SZ");

	if (dhxWins.isWindow("ThemeWindow"))
	{
		ThemeWindow.close();
		ThemeWindow=null;

		ThemeWizardOpen=false;
	}

	if (reload)
		RefreshWPI();
}

function ToggleTheme()
{
	position="themewizard.js";
	whatfunc="ToggleTheme()";

	if (ReadMeWindow != null || AboutWindow != null)
		return;
	if (OptionsWizardOpen || ConfigWizardOpen || NetworkWizardOpen)
	{
		Alert("",getText(txtCanNotSwitchWizards),getText(lblOK),"",3,0,0,0);

		return;
	}

	if (!dhxWins.isWindow("ThemeWindow"))
	{
		isThemeSaved=true;
		ShowTheme();
	}
	else
	{
		if (isThemeSaved)
			HideTheme(true);
		else
		{
			if (Alert("",getText(txtDiscardChanges),getText(lblOK)+"|"+getText(lblCancel),"",5,0,0,0))
			{
				isThemeSaved=true;
				HideTheme(true);
			}
		}
	}
}
