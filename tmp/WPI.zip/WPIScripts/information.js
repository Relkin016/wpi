//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// Windows Post - Install Wizard
// information.js
//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

function ToggleInformation()
{
   position = "information.js";
   whatfunc = "ToggleInformation()";

   if ( ! dhxWins.isWindow("InfoWindow"))
   ShowInformation();
   else
   InfoWindow.bringToTop();
}

function ShowInformation()
{
   position = "information.js";
   whatfunc = "ShowInformation()";

   var gId = 0;

   InfoWindow = dhxWins.createWindow("InfoWindow", 50, 50, 700, 415);
   InfoWindow.setText(getText(txtInformation));
   InfoWindow.button("minmax1").hide();
   InfoWindow.denyResize();
   InfoWindow.center();

   informationTabs = InfoWindow.attachTabbar();
   informationTabs.setImagePath("../common/codebase/imgs/");
   informationTabs.addTab("Tab1", getText(tabArchitecture), "110px");
   informationTabs.addTab("Tab2", getText(tabHardware), "110px");
   informationTabs.addTab("Tab3", getText(tabMyComputer), "110px");
   informationTabs.addTab("Tab4", getText(tabVariables), "110px");
   informationTabs.addTab("Tab5", getText(tabConditions), "110px");
   informationTabs.addTab("Tab6", getText(tabJScript), "110px");

   ArchitectureGrid = informationTabs.cells("Tab1").attachGrid();
   ArchitectureGrid.setImagePath("../common/codebase/imgs/");
   ArchitectureGrid.setSkin(dhxSkin);
   ArchitectureGrid.setHeader('' + getText(lblProperty) + ',' + getText(lblValue) + '');
   ArchitectureGrid.setInitWidths("200,*");
   ArchitectureGrid.setColAlign("left,left");
   ArchitectureGrid.attachEvent("onBeforeSelect", function()
   {
      return false;
   }
   );
   ArchitectureGrid.init();
   gId = - 1;
   ArchitectureGrid.addRow(gId ++ , getText(lblArchBits) + ',' + getBits() + '');
   ArchitectureGrid.addRow(gId ++ , getText(lblArchID) + ',' + getArchIdentifier() + '');
   ArchitectureGrid.addRow(gId ++ , getText(lblArchName) + ',' + getArchName() + '');
   ArchitectureGrid.addRow(gId ++ , getText(lblArchNameString) + ',' + getArchNameString() + '');
   ArchitectureGrid.addRow(gId ++ , getText(lblArchType) + ',' + getArch() + '');
   ArchitectureGrid.addRow(gId ++ , getText(lblNumberProcessors) + ',' + getArchNumProcs() + '');
   ArchitectureGrid.addRow(gId ++ , getText(lblNumberOfCores) + ',' + getArchNumOfCores() + '');
   ArchitectureGrid.addRow(gId ++ , getText(lblNumberOfLogicalProcessors) + ',' + getArchNumLogicalProcs() + '');
   ArchitectureGrid.addRow(gId ++ , getText(lblMHz) + ',' + getArchMHz() + '');

   getVideoControllerID();
   getSoundDeviceID();
   getNetworkAdapterID();
   getWirelessNetworkAdapterID();
   getModemID();
   getKeyboardID();
   getPointingDeviceID();

   HardwareGrid = informationTabs.cells("Tab2").attachGrid();
   HardwareGrid.setImagePath("../common/codebase/imgs/");
   HardwareGrid.setSkin(dhxSkin);
   HardwareGrid.setHeader(getText(lblProperty) + ',' + getText(lblValue) + ',' + getText(lblPNPDeviceID));
   HardwareGrid.setInitWidths("220,220,280");
   HardwareGrid.setColAlign("left,left,left");
   HardwareGrid.attachEvent("onBeforeSelect", function()
   {
      return false;
   }
   );
   HardwareGrid.init();
   gId = - 1;
   HardwareGrid.addRow(gId ++ , getText(lblBaseBoardManufacturer) + ',' + getBaseBoardManufacturer() + ',' + '');
   HardwareGrid.addRow(gId ++ , getText(lblBaseBoardModel) + ',' + getBaseBoardModel() + ',' + '');
   HardwareGrid.addRow(gId ++ , getText(lblVideoController) + ',' + VideoControllerName + ',' + PNPDID_VideoController);
   HardwareGrid.addRow(gId ++ , getText(lblSoundDevice) + ',' + SoundDeviceName + ',' + PNPDID_SoundDevice);
   HardwareGrid.addRow(gId ++ , getText(lblNetworkAdapter) + ',' + NetworkAdapterName + ',' + PNPDID_NetworkAdapter);
   for (var i = 0; i < PNPDID_HDDController.length;
   i ++ )
   HardwareGrid.addRow(gId ++ , getText(lblHDDController) + ' ' + i + ',' + HDDControllerName[i] + ',' + PNPDID_HDDController[i]);
   HardwareGrid.addRow(gId ++ , getText(lblPointingDevice) + ',' + PointingDeviceName + ',' + PNPDID_PointingDevice);
   HardwareGrid.addRow(gId ++ , getText(lblPCManufacturer) + ',' + getSysManufacturer() + ',' + '');
   HardwareGrid.addRow(gId ++ , getText(lblPCModel) + ',' + getSysModel() + ',' + '');
   HardwareGrid.addRow(gId ++ , getText(lblPCType) + ',' + getSysPCType() + ',' + '');
   HardwareGrid.addRow(gId ++ , getText(lblPCSystemType) + ',' + getSysType() + ',' + '');
   HardwareGrid.addRow(gId ++ , getText(lblSystemEnclosureType) + ',' + getSystemEnclosureType() + ',' + '');
   HardwareGrid.addRow(gId ++ , getText(lblBIOSManufacturer) + ',' + getBIOSManufacturer() + ',' + '');
   HardwareGrid.addRow(gId ++ , getText(lblBIOSVersion) + ',' + getBIOSVersion() + ',' + '');
   HardwareGrid.addRow(gId ++ , getText(lblSMBIOSVersion) + ',' + getSMBIOSVersion() + ',' + '');
   HardwareGrid.addRow(gId ++ , getText(lblBIOSCaption) + ',' + getBIOSCaption() + ',' + '');
   HardwareGrid.addRow(gId ++ , getText(lblWirelessNetworkAdapter) + ',' + WirelessNetworkAdapterName + ',' + PNPDID_WirelessNetworkAdapter);
   HardwareGrid.addRow(gId ++ , getText(lblModem) + ',' + ModemName + ',' + PNPDID_Modem);
   HardwareGrid.addRow(gId ++ , getText(lblCDROM) + ',' + CDROMName + ',' + PNPDID_CDROM);
   HardwareGrid.addRow(gId ++ , getText(lblCDBurner) + ',' + CDBurnerName + ',' + PNPDID_CDBurner);
   HardwareGrid.addRow(gId ++ , getText(lblKeyboard) + ',' + KeyboardName + ',' + PNPDID_Keyboard);

   MyComputerGrid = informationTabs.cells("Tab3").attachGrid();
   MyComputerGrid.setImagePath("../common/codebase/imgs/");
   MyComputerGrid.setSkin(dhxSkin);
   MyComputerGrid.setHeader('' + getText(lblProperty) + ',' + getText(lblValue) + '');
   MyComputerGrid.setInitWidths("200,*");
   MyComputerGrid.setColAlign("left,left");
   MyComputerGrid.attachEvent("onBeforeSelect", function()
   {
      return false;
   }
   );
   MyComputerGrid.init();
   gId = - 1;
   MyComputerGrid.addRow(gId ++ , getText(lblFreeRAM) + ',' + getFreeRAM() + 'MB');
   MyComputerGrid.addRow(gId ++ , getText(lblTotalRAM) + ',' + getTotalRAM() + 'MB');
   MyComputerGrid.addRow(gId ++ , getText(lblCAvailable) + ',' + DriveAvailableSpace("C:") + 'GB');
   MyComputerGrid.addRow(gId ++ , getText(lblCTotal) + ',' + DriveTotalSize("C:") + 'GB');
   MyComputerGrid.addRow(gId ++ , getText(lblCFileSystem) + ',' + DriveFileSystem("C:") + '');
   MyComputerGrid.addRow(gId ++ , getText(lblOperatingSystem) + ',' + getOSver() + '');
   MyComputerGrid.addRow(gId ++ , getText(lblOSvernumber) + ',' + getOSvernum() + '');
   MyComputerGrid.addRow(gId ++ , getText(lblOSBuild) + ',' + getOSBuildID() + '');
   MyComputerGrid.addRow(gId ++ , getText(lblEditionID) + ',' + getOSeditionID() + '');
   MyComputerGrid.addRow(gId ++ , getText(lblServicePack) + ',' + getSPver() + '');
   MyComputerGrid.addRow(gId ++ , getText(lblLanguage) + ',' + getOSlang() + '');
   MyComputerGrid.addRow(gId ++ , getText(lblLocale) + ',' + getOSlocale() + '');
   MyComputerGrid.addRow(gId ++ , getText(lblProductKey) + ',' + getProductKey() + '');
   MyComputerGrid.addRow(gId ++ , getText(lblKeyboardLayout) + ',' + getKeyboardLayout() + '');
   MyComputerGrid.addRow(gId ++ , getText(lblInternetConnection) + ',' + ConnectedToInternet() + '');
   MyComputerGrid.addRow(gId ++ , getText(lblIEVersion) + ',' + getIEver() + '');

   VariablesGrid = informationTabs.cells("Tab4").attachGrid();
   VariablesGrid.setImagePath("../common/codebase/imgs/");
   VariablesGrid.setSkin(dhxSkin);
   VariablesGrid.setHeader('' + getText(lblProperty) + ',' + getText(lblValue) + '');
   VariablesGrid.setInitWidths("200,*");
   VariablesGrid.setColAlign("left,left");
   VariablesGrid.attachEvent("onBeforeSelect", function()
   {
      return false;
   }
   );
   VariablesGrid.init();
   gId = - 1;
   VariablesGrid.addRow(gId ++ , 'COMSPEC,'+ReplacePath("%comspec%")+'');
   VariablesGrid.addRow(gId ++ , 'OSLANG,' + oslang + '');
   VariablesGrid.addRow(gId ++ , 'WPIPATH,' + wpipath + '');
   VariablesGrid.addRow(gId ++ , 'ROOT,' + root + '');
   VariablesGrid.addRow(gId ++ , 'CDROM,' + cddrv + '');
   VariablesGrid.addRow(gId ++ , 'DOSPATH,' + dospath + '');
   VariablesGrid.addRow(gId ++ , 'SYSTEMDRIVE,' + ReplacePath("%systemdrive%") + '');
   VariablesGrid.addRow(gId ++ , 'WINDIR,' + ReplacePath("%windir%") + '');
   VariablesGrid.addRow(gId ++ , 'PROGRAMFILES,' + ReplacePath("%programfiles%") + '');
   VariablesGrid.addRow(gId ++ , 'TEMP,' + ReplacePath("%temp%") + '');
   VariablesGrid.addRow(gId ++ , 'SYSDIR,' + sysdir + '');
   VariablesGrid.addRow(gId ++ , 'USB,' + usbdrv + '');
   VariablesGrid.addRow(gId ++ , 'ALLUSERSPROFILE,' + ReplacePath("%allusersprofile%") + '');
   VariablesGrid.addRow(gId ++ , 'USERPROFILE,' + ReplacePath("%userprofile%") + '');
   VariablesGrid.addRow(gId ++ , 'USERPROFILEROOT,' + ReplacePath("%userprofileroot%") + '');
   VariablesGrid.addRow(gId ++ , 'APPDATA,' + ReplacePath("%appdata%") + '');
   VariablesGrid.addRow(gId ++ , 'COMMONPROGRAMFILES,' + ReplacePath("%commonprogramfiles%") + '');

   ConditionsGrid = informationTabs.cells("Tab5").attachGrid();
   ConditionsGrid.setImagePath("../common/codebase/imgs/");
   ConditionsGrid.setSkin(dhxSkin);
   ConditionsGrid.setHeader(getText(lblProperty));
   ConditionsGrid.setInitWidths("*");
   ConditionsGrid.setColAlign("left");
   ConditionsGrid.attachEvent("onBeforeSelect", function()
   {
      return false;
   }
   );
   ConditionsGrid.init();
   gId = - 1;
   ConditionsGrid.addRow(gId ++ , 'FileExists("C:\\Program Files\\ReadMe.txt")');
   ConditionsGrid.addRow(gId ++ , 'getFileSize("C:\\Program Files\\ReadMe.txt")>5000000');
   ConditionsGrid.addRow(gId ++ , 'getFileType("C:\\Program Files\\ReadMe.txt")=="PNG Image"');
   ConditionsGrid.addRow(gId ++ , 'getFileVersion("C:\\Program Files\\AVG\\AVG.exe")=="2.0"');
   ConditionsGrid.addRow(gId ++ , 'FolderExists("C:\\Program Files\\AVG")');
   ConditionsGrid.addRow(gId ++ , 'getFolderSize("C:\\Program Files\\AVG")>10000000');
   ConditionsGrid.addRow(gId ++ , 'DriveExists("D:")');
   ConditionsGrid.addRow(gId ++ , 'DriveType("D:")==4');
   ConditionsGrid.addRow(gId ++ , 'DriveVolumeName("G:")=="Music"');
   ConditionsGrid.addRow(gId ++ , 'DriveShareName("W:")=="\\\\server\\share"');
   ConditionsGrid.addRow(gId ++ , 'DriveFileSystem("C:")=="NTFS"');
   ConditionsGrid.addRow(gId ++ , 'DriveAvailableSpace("C:")>10');
   ConditionsGrid.addRow(gId ++ , 'DriveTotalSize("C:")>150');
   ConditionsGrid.addRow(gId ++ , 'getComSpec()=="C:\\Windows\\System32\\cmd.exe"');
   ConditionsGrid.addRow(gId ++ , 'getEnvVar("USERNAME")=="'+getEnvVar("USERNAME")+'"');
   ConditionsGrid.addRow(gId ++ , 'RegKeyExists("HKEY_CURRENT_USER\\Software\\WPI")');
   ConditionsGrid.addRow(gId ++ , 'RegValueExists("HKEY_CURRENT_USER\\Software\\WPI\\Theme")');
   ConditionsGrid.addRow(gId ++ , 'RegKeyValue("HKEY_CURRENT_USER\\Software\\WPI\\Theme")=="Windows"');
   ConditionsGrid.addRow(gId ++ , 'getOSver()=="'+getOSver()+'"');
   ConditionsGrid.addRow(gId ++ , 'getOSeditionID()=="'+getOSeditionID()+'"');
   ConditionsGrid.addRow(gId ++ , 'getSPver()==' + getSPver());
   ConditionsGrid.addRow(gId ++ , 'getOSvernum()=="'+getOSvernum()+'"');
   ConditionsGrid.addRow(gId ++ , 'getOSlang()=="'+getOSlang()+'"');
   ConditionsGrid.addRow(gId ++ , 'getOSlocale()=="'+getOSlocale()+'"');
   ConditionsGrid.addRow(gId ++ , 'getArch()=="'+getArch()+'"');
   ConditionsGrid.addRow(gId ++ , 'getBits()==' + getBits());
   ConditionsGrid.addRow(gId ++ , 'getArchName()=="'+getArchName()+'"');
   ConditionsGrid.addRow(gId ++ , 'getArchNameString()=="'+getArchNameString()+'"');
   ConditionsGrid.addRow(gId ++ , 'getArchIdentifier()=="'+getArchIdentifier()+'"');
   ConditionsGrid.addRow(gId ++ , 'getNumProcs()=="'+getArchNumProcs()+'"');
   ConditionsGrid.addRow(gId ++ , 'getArchMHz()=="'+getArchMHz()+'"');
   ConditionsGrid.addRow(gId ++ , 'getBaseBoardManufacturer()=="'+BaseBoardManufacturer+'"');
   ConditionsGrid.addRow(gId ++ , 'getBaseBoardModel()=="'+BaseBoardModel+'"');
   ConditionsGrid.addRow(gId ++ , 'getVideoControllerID()=="'+PNPDID_VideoController+'"');
   ConditionsGrid.addRow(gId ++ , 'getSoundDeviceID()=="'+PNPDID_SoundDevice+'"');
   ConditionsGrid.addRow(gId ++ , 'getNetworkAdapterID()=="'+PNPDID_NetworkAdapter+'"');
   ConditionsGrid.addRow(gId ++ , 'getWirelessNetworkAdapterID()=="'+PNPDID_WirelessNetworkAdapter+'"');
   ConditionsGrid.addRow(gId ++ , 'getModemID()=="'+PNPDID_Modem+'"');
   ConditionsGrid.addRow(gId ++ , 'getHDDControllerID("'+PNPDID_HDDController[0]+'")');
   ConditionsGrid.addRow(gId ++ , 'getCDROMID()=="'+PNPDID_CDROM+'"');
   ConditionsGrid.addRow(gId ++ , 'getCDBurnerID()=="'+PNPDID_CDBurner+'"');
   ConditionsGrid.addRow(gId ++ , 'getCDBurnerName()=="'+CDBurnerName+'"');
   ConditionsGrid.addRow(gId ++ , 'hasDVDBurner(' + hasDVDBurnerDrive + ')');
   ConditionsGrid.addRow(gId ++ , 'hasDVDDrive(' + hasDVDROMDrive + ')');
   ConditionsGrid.addRow(gId ++ , 'getKeyboardID()=="'+PNPDID_Keyboard+'"');
   ConditionsGrid.addRow(gId ++ , 'getPointingDeviceID()=="'+PNPDID_PointingDevice+'"');
   ConditionsGrid.addRow(gId ++ , 'getSystemEnclosureType()=="'+getSystemEnclosureType()+'"');
   ConditionsGrid.addRow(gId ++ , 'getSysManufacturer()=="'+getSysManufacturer()+'"');
   ConditionsGrid.addRow(gId ++ , 'getSysModel()=="'+getSysModel()+'"');
   ConditionsGrid.addRow(gId ++ , 'getSysPCType()=="'+getSysPCType()+'"');
   ConditionsGrid.addRow(gId ++ , 'getSysType()=="'+getSysType()+'"');
   ConditionsGrid.addRow(gId ++ , 'getFreeRAM()>512');
   ConditionsGrid.addRow(gId ++ , 'getTotalRAM()>1024');
   ConditionsGrid.addRow(gId ++ , 'getBIOSManufacturer()=="'+getBIOSManufacturer()+'"');
   ConditionsGrid.addRow(gId ++ , 'getBIOSVersion()=="'+getBIOSVersion()+'"');
   ConditionsGrid.addRow(gId ++ , 'getSMBIOSVersion()=="'+getSMBIOSVersion()+'"');
   ConditionsGrid.addRow(gId ++ , 'getBIOSCaption()=="'+getBIOSCaption()+'"');
   ConditionsGrid.addRow(gId ++ , 'getFirewallProduct()=="'+getFirewallProduct()+'"');
   ConditionsGrid.addRow(gId ++ , 'getAntiVirusProduct()=="'+getAntiVirusProduct()+'"');
   ConditionsGrid.addRow(gId ++ , 'getIEver()=="'+getIEver()+'"');
   ConditionsGrid.addRow(gId ++ , 'ConnectedToInternet(' + ConnToNet + ')');
   ConditionsGrid.addRow(gId ++ , 'isInstalled("Adobe Reader 8.1.2")');
   ConditionsGrid.addRow(gId ++ , 'isLogOnServer("'+LogOnServer+'")');
   ConditionsGrid.addRow(gId ++ , 'isUserDomain("'+UserDomain+'")');
   ConditionsGrid.addRow(gId ++ , 'isComputerName("'+ComputerName+'")');
   ConditionsGrid.addRow(gId ++ , 'isUserName("'+UserName+'")');
   ConditionsGrid.addRow(gId ++ , 'isDesktopLoaded(' + DesktopLoaded + ')');
   ConditionsGrid.addRow(gId ++ , '');
   ConditionsGrid.addRow(gId ++ , getText(lblTheseAreExamples));

   JScriptGrid = informationTabs.cells("Tab6").attachGrid();
   JScriptGrid.setImagePath("../common/codebase/imgs/");
   JScriptGrid.setSkin(dhxSkin);
   JScriptGrid.setHeader(getText(lblProperty));
   JScriptGrid.setInitWidths("*");
   JScriptGrid.setColAlign("left");
   JScriptGrid.setDelimiter("|");
   JScriptGrid.attachEvent("onBeforeSelect", function()
   {
      return false;
   }
   );
   JScriptGrid.init();
   gId = - 1;
   JScriptGrid.addRow(gId ++ , '{JSCRIPT}=alert("Open a window")');
   JScriptGrid.addRow(gId ++ , '{JSCRIPT}=ClearAutoLogonUser()');
   JScriptGrid.addRow(gId ++ , '{JSCRIPT}=CreateRegKey("HKEY_LOCAL_MACHINE\\Software\\Microsoft\\Windows\\CurrentVersion\\RunOnceEx\\001")');
   JScriptGrid.addRow(gId ++ , '{JSCRIPT}=CreateShortcut("Description","IconLocation","Hotkey","TargetPath","Arguments","Destination","Folder")');
   JScriptGrid.addRow(gId ++ , '{JSCRIPT}=CreateWindowsUser("Mark","password",true)');
   JScriptGrid.addRow(gId ++ , '{JSCRIPT}=DeleteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\WPI_Rocks")');
   JScriptGrid.addRow(gId ++ , '{JSCRIPT}=DeleteWindowsUser("Mark",true)');
   JScriptGrid.addRow(gId ++ , '{JSCRIPT}=ErrorReporting(false,true,true,false)');
   JScriptGrid.addRow(gId ++ , '{JSCRIPT}=FormatDrive("G:","Games","NTFS","4096",true,false)');
   JScriptGrid.addRow(gId ++ , '{JSCRIPT}=MapNetworkDrive("Letter","Path",true)');
   JScriptGrid.addRow(gId ++ , '{JSCRIPT}=PowerOptions(...)');
   JScriptGrid.addRow(gId ++ , '{JSCRIPT}=removeEnvVar("USERNAME")');
   JScriptGrid.addRow(gId ++ , '{JSCRIPT}=RenameComputer("Computer1")');
   JScriptGrid.addRow(gId ++ , '{JSCRIPT}=ScreenSaver("ssbezier",10,false)');
   JScriptGrid.addRow(gId ++ , '{JSCRIPT}=SetAutoLogonUser("Mark","password","domain")');
   JScriptGrid.addRow(gId ++ , '{JSCRIPT}=setEnvVar("USERNAME","Mark",true)');
   JScriptGrid.addRow(gId ++ , '{JSCRIPT}=SetFilePrinterSharing(true)');
   JScriptGrid.addRow(gId ++ , '{JSCRIPT}=SetFirewall(true)');
   JScriptGrid.addRow(gId ++ , '{JSCRIPT}=SetPageFileSize("C:",1024,2048,false)');
   JScriptGrid.addRow(gId ++ , '{JSCRIPT}=SetSecurityCenter_XP(true,true,true,true,false)');
   JScriptGrid.addRow(gId ++ , '{JSCRIPT}=ShareFolder("ShareName","Path")');
   JScriptGrid.addRow(gId ++ , '{JSCRIPT}=TimedWaitForDelete(10,"C:\\Program Files\\WinRAR\\WinRAR.exe",10)');
   JScriptGrid.addRow(gId ++ , '{JSCRIPT}=TimedWaitForFile("C:\\Program Files\\WinRAR\\WinRAR.exe",10)');
   JScriptGrid.addRow(gId ++ , '{JSCRIPT}=TimedWaitForProgram("Setup.exe",10)');
   JScriptGrid.addRow(gId ++ , '{JSCRIPT}=WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\WPI_Rocks",1,"REG_DWORD")');

   informationTabs.setTabActive('Tab1');
}

function HideInformation()
{
   position = "information.js";
   whatfunc = "HideInformation()";

   if (dhxWins.isWindow("InfoWindow"))
   {
      InfoWindow.close();
      InfoWindow = null;
   }
}

function ToggleReadMe()
{
   position = "information.js";
   whatfunc = "ToggleReadMe()";

   if ( ! dhxWins.isWindow("ReadMeWindow"))
   ShowReadMe();
   else
   ReadMeWindow.bringToTop();
}

function ShowReadMe()
{
   position = "information.js";
   whatfunc = "ShowReadMe()";

   ReadMeWindow = dhxWins.createWindow("ReadMeWindow", 50, 50, 500, 350);
   ReadMeWindow.setText(getText(lblReadMe));
   ReadMeWindow.setModal(true);
   ReadMeWindow.button("park").hide();
   ReadMeWindow.button("minmax1").hide();
   ReadMeWindow.button("close").hide();
   ReadMeWindow.denyResize();
   ReadMeWindow.center();
   ActiveWindow = ReadMeWindow.getText();
   BlockWindow = "ReadMeWindow";

   var newDiv = document.createElement("div");
   var objDiv = document.getElementById("layergroup");

   newDiv.id = "layerreadme";
   newDiv.style.display = "none";
   newDiv.style.overflow = "auto";
   newDiv.style.width = "100%";
   newDiv.style.height = "100%";
   newDiv.style.padding = "7px";

   objDiv.appendChild(newDiv);

   ReadMeWindow.attachObject("layerreadme");

   CreateTab("\\Common\\informationtemplate_readme.htm", "layerreadme");

   document.getElementById("legReadMe").innerHTML = getText(legReadMe);
   document.getElementById("lblOK").innerHTML = getText(lblOK);

   var txt = new String();
   txt = "";
   strFile = wpipath + "\\ReadMe.txt";
   try
   {
      tf = fso.OpenTextFile(strFile, 1);
      while ( ! tf.AtEndOfStream)
      txt = tf.ReadAll();
   }
   catch(ex)
   {
      ;

   }
   finally
   {
      tf.Close();
   }
   txt = txt.replace(/\n/gi, "<br>");
   document.getElementById("ReadMeTxt").innerHTML = txt;

   document.getElementById("layerreadme").style.display = 'block';

   AutoSizeWindow(ReadMeWindow, "layerreadme");
}

function HideReadMe()
{
   position = "information.js";
   whatfunc = "HideReadMe()";

   if (dhxWins.isWindow("ReadMeWindow"))
   {
      ReadMeWindow.close();
      ReadMeWindow = null;
   }
}
