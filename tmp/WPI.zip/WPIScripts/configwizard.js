//************************************************
// Windows Post-Install Wizard
// configwizard.js
//************************************************

function ConfigUpdated()
{
	position="configwizard.js";
	whatfunc="ConfigUpdated()";

	isConfigSaved=false;
}

function CreateControls()
{
	position="configwizard.js";
	whatfunc="CreateControls()";

	if (configTabs != null)
	return;

	ConfigWindow=dhxWins.createWindow("ConfigWindow", 50, 50, document.getElementById("bgpiclayer").offsetWidth-50, document.getElementById("bgpiclayer").offsetHeight-50);
	ConfigWindow.setText(getText(lblConfigWizard));
	ConfigWindow.setModal(true);
	ConfigWindow.button("park").hide();
	ConfigWindow.button("minmax1").hide();
	ConfigWindow.button("close").hide();
	ConfigWindow.keepInViewport(true);
	ConfigWindow.denyResize();
	ConfigWindow.center();
	ActiveWindow=ConfigWindow.getText();
	BlockWindow="ConfigWindow";

	StatusBar=ConfigWindow.attachStatusBar();

	var newDiv=document.createElement("div");
	var objDiv=document.getElementById("layergroup");

	newDiv.id="layerconfig";
	newDiv.style.display="none";
	newDiv.style.overflow="auto";
	newDiv.style.width="100%";
	newDiv.style.height="100%";
	newDiv.style.padding="10px";

	objDiv.appendChild(newDiv);

	ConfigWindow.attachObject("layerconfig");
	document.getElementById("layerconfig").style.visibility='hidden';

	CreateTab("\\Common\\configwizardtemplate.htm","layerconfig");
	CreateTab("\\Common\\configwizardtemplate_configurations.htm","tabtabConfigurations");
	CreateTab("\\Common\\configwizardtemplate_details.htm","tabtabDetails");
	CreateTab("\\Common\\configwizardtemplate_commands.htm","tabtabCommands");
	CreateTab("\\Common\\configwizardtemplate_dependencies.htm","tabtabDependencies");
	CreateTab("\\Common\\configwizardtemplate_tooltips.htm","tabtabToolTips");

	configTabs=new dhtmlXTabBar("ConfigTabs","top");
	configTabs.setImagePath("../common/codebase/imgs/");
	configTabs.setStyle(dhxSkin);
	configTabs.enableForceHiding(true);
	var tablist=new Array('tabConfigurations','tabDetails','tabCommands','tabDependencies','tabToolTips');
	for (var i=0; i<tablist.length; i++)
	{
	configTabs.addTab("Tab"+(i+1).toString(),getText(eval(tablist[i])),""+Math.round((parseInt(document.getElementById("ConfigTabs").offsetWidth)-16)/tablist.length)+"px");
	}

	LocalizeConfigButtonsTexts();
	LocalizeConfigTexts();

	CreateNavigation();

	LayoutCommandsMenuBar();
	SetUpConditionMenuBar("ConditionsMenuBar","cond", onClickHandlerConditions); 
    SetUpConditionMenuBar("GrayedConditionsMenuBar","gcond",onClickHandlerGrayedConditions);

	DescriptionEditor=new dhtmlXEditor("DescriptionEditor",dhxSkin);
    DescriptionEditor.setIconsPath("../common/codebase/imgs/");
    DescriptionEditor.init();

	for (var i=0; i<tablist.length; i++)
	{
	configTabs.setContent("Tab"+(i+1).toString(),"tab"+ tablist[i]);
	}

	configTabs.setTabActive('Tab2');

	CreateConfigurations();
	CreateSortOrder();
	CreateCommandsNavigation();

	document.getElementById("layerconfig").style.visibility='visible';
	document.getElementById("layerconfig").style.display='block';
}

function LocalizeConfigButtonsTexts()
{
	position="configwizard.js";
	whatfunc="LocalizeConfigButtonsTexts()";

	document.getElementById("configAdd").innerHTML=getText(btnAdd);
	document.getElementById("configClone").innerHTML=getText(btnClone);
	document.getElementById("configDelete").innerHTML=getText(btnDelete);
	document.getElementById("lblFilter").innerHTML=getText(lblFilter);
	document.getElementById("configNewConfig").innerHTML=getText(btnNewConfig);
	document.getElementById("configRead").innerHTML=getText(btnRead);
	document.getElementById("configSave").innerHTML=getText(btnSave);
	document.getElementById("configSaveAs").innerHTML=getText(btnSaveAs);
	document.getElementById("configExit").innerHTML=getText(btnExit);
}

function LocalizeConfigTexts()
{
	position="configwizard.js";
	whatfunc="LocalizeConfigTexts()";
	document.getElementById("lblUseMultipleDefaults").innerHTML=getText(lblUseMultipleDefaults);
	document.getElementById("legControlsConfigurations").innerHTML=getText(lblControls);
	document.getElementById("Configurations_Add").innerHTML=getText(btnAdd);
	document.getElementById("Configurations_Delete").innerHTML=getText(btnDelete);
	document.getElementById("legName").innerHTML=getText(legName);
	document.getElementById("lblProgramName").innerHTML=getText(lblProgramName);
	document.getElementById("lblShortDescription").innerHTML=getText(lblShortDescription);
	document.getElementById("legUniqueID").innerHTML=getText(legUniqueID);
	document.getElementById("legInstallOrder").innerHTML=getText(legInstallOrder);
	document.getElementById("legOptions").innerHTML=getText(legOptions);
	document.getElementById("lblDefault").innerHTML=getText(lblDefault);
	document.getElementById("lblForced").innerHTML=getText(lblForced);
	document.getElementById("legCategory").innerHTML=getText(legCategory);
	document.getElementById("legConfigurations").innerHTML=getText(legConfigurations);
	document.getElementById("legReturnCodeReqReboot").innerHTML=getText(legReturnCodeReqReboot);
	document.getElementById("lblRebootCode").innerHTML=getText(lblRebootCode);
	document.getElementById("lblRepeatCommandUntilOther").innerHTML=getText(lblRepeatCommandUntilOther);
	document.getElementById("legCheckForReboot").innerHTML=getText(legCheckForReboot);
	document.getElementById("lblCheckPFRO").innerHTML=getText(lblCheckPFRO);
	document.getElementById("legControlsCommands").innerHTML=getText(lblControls);
	document.getElementById("Commands_Add").innerHTML=getText(btnAdd);
	document.getElementById("Commands_Delete").innerHTML=getText(btnDelete);
	document.getElementById("legDependentOf").innerHTML=getText(legDependentOf);
	document.getElementById("legExcludes").innerHTML=getText(legExcludes);
	document.getElementById("legConditions").innerHTML=getText(legConditions);
	document.getElementById("txtPressAltG").innerHTML=getText(txtPressAltG);
	document.getElementById("legCondition").innerHTML=getText(legCondition);
	document.getElementById("legGrayedCondition").innerHTML=getText(legGrayedCondition);
	document.getElementById("lblInsertCondValues").innerHTML=getText(lblInsertCondValues);
	document.getElementById("legDescription").innerHTML=getText(legDescription);
	document.getElementById("legPictureFile").innerHTML=getText(legPictureFile);
	document.getElementById("legPictureWidth").innerHTML=getText(legWidth);
	document.getElementById("legPictureHeight").innerHTML=getText(legHeight);
	document.getElementById("legTextLocation").innerHTML=getText(legTextLocation);
	document.getElementById("legPicturePreview").innerHTML=getText(legPicturePreview);
	document.getElementById("cboFilter").options[0].text=getText(optAll);
	document.getElementById("cbocats").options[0].text=getText(optOther);
	document.getElementById("cbocats").options[1].text=getText(optApplications);
	document.getElementById("textl").options[0].text=getText(optTop);
	document.getElementById("textl").options[1].text=getText(optBottom);
	document.getElementById("textl").options[2].text=getText(optLeft);
	document.getElementById("textl").options[3].text=getText(optRight);
}

function CreateNavigation()
{
	position="configwizard.js";
	whatfunc="CreateNavigation()";

	if (!NavGrid)
	{
	if (SortWithinCats)
	configList.sort(byName);
	else
	configList.sort(byOrder);

	NavGrid=new dhtmlXGridObject('ConfigGrid');
	NavGrid.setImagePath("../common/codebase/imgs/");
	NavGrid.setSkin(dhxSkin);
	NavGrid.setHeader(getText(lblOrder)+','+getText(lblCategory)+','+getText(lblUniqueID)+','+getText(lblName));
	NavGrid.setInitWidths("100,200,255,*");
	NavGrid.setColAlign("left,left,left,left");
	NavGrid.setColTypes("ro,ro,ro,ro");
	NavGrid.setColSorting("int,str,str,str");
	NavGrid.enableMultiselect(false);
	NavGrid.enableMultiline(false);
	NavGrid.enableKeyboardSupport(false);
	NavGrid.enableDragAndDrop(true);
	NavGrid.attachEvent("onRowSelect",JumpToEntry);
	NavGrid.init();
	NavGrid.objBox.style.overflowX="hidden";
	NavGrid.attachEvent("onDrop",ConfigUpdated);
	NavGrid.attachEvent("onAfterSorting",ConfigUpdated);
	}

	PopulateGrid();
	NavGrid.selectRow(0,false,false,true);
	cpos=NavGrid.getRowId(0);
}

function PopulateGrid()
{
	position="configwizard.js";
	whatfunc="PopulateGrid()";

	NavGrid.clearAll();

	for (var i=0; i<configList.length && configList[i] != null; i++)
	{
	if (CatFilter=="all" || CatFilter==configList[i].cat)
		NavGrid.addRow(i,[configList[i].ordr,GetCategoryTranslation(ConvertSpecialCharactersToEntities(configList[i].cat)),configList[i].uid,ConvertSpecialCharactersToEntities(configList[i].prog)]);
	}

	NavGrid.setSortImgState(true,ConfigSortBy,ConfigSortAscDes);
	NavGrid.sortRows(ConfigSortBy,null,ConfigSortAscDes);
}

function CreateConfigurations()
{
	position="configwizard.js";
	whatfunc="CreateConfigurations()";

	if (!ConfigurationsGrid)
	{
	ConfigurationsGrid=new dhtmlXGridObject('ConfigurationsGrid');
	ConfigurationsGrid.setImagePath("../common/codebase/imgs/");
	ConfigurationsGrid.setSkin(dhxSkin);
	ConfigurationsGrid.setHeader(getText(lblCheckOnLoad)+','+getText(lblConfigurations));
	ConfigurationsGrid.setInitWidths("100,*");
	ConfigurationsGrid.setColAlign("center,left");
	ConfigurationsGrid.setColTypes("ra,ro");
	ConfigurationsGrid.enableMultiselect(false);
	ConfigurationsGrid.enableMultiline(false);
	ConfigurationsGrid.enableDragAndDrop(true);
	ConfigurationsGrid.enableKeyboardSupport(false);
	ConfigurationsGrid.init();
	ConfigurationsGrid.objBox.style.overflowX="hidden";
	}
}

function PopulateConfigurations()
{
	position="configwizard.js";
	whatfunc="PopulateConfigurations()";

	ConfigurationsGrid.clearAll();
	ConfigurationsGrid.addRow(0,[(CheckOnLoad=="default" ? 1 : 0),"<i>"+getText(optDefault)+"</i>"]);
	ConfigurationsGrid.addRow(1,[(CheckOnLoad=="all" ? 1 : 0),"<i>"+getText(optAll)+"</i>"]);
	ConfigurationsGrid.addRow(2,[(CheckOnLoad=="none" ? 1 : 0),"<i>"+getText(optNone)+"</i>"]);

	for (var i=0; i<Configurations.length; i++)
	ConfigurationsGrid.addRow(i+3,[(CheckOnLoad==Configurations[i] ? 1 : 0),ConvertSpecialCharactersToEntities(Configurations[i])]);
}

function CreateSortOrder()
{
	position="configwizard.js";
	whatfunc="CreateSortOrder()";

	if (!SortOrderGrid)
	{
	SortOrderGrid=new dhtmlXGridObject('SortOrderGrid');
	SortOrderGrid.setImagePath("../common/codebase/imgs/");
	SortOrderGrid.setSkin(dhxSkin);
	SortOrderGrid.setHeader(getText(txtCatSortOrder));
	SortOrderGrid.setInitWidths("*");
	SortOrderGrid.setColAlign("left");
	SortOrderGrid.setColTypes("ro");
	SortOrderGrid.setColSorting("str");
	SortOrderGrid.enableMultiselect(false);
	SortOrderGrid.enableMultiline(false);
	SortOrderGrid.enableKeyboardSupport(false);
	SortOrderGrid.enableDragAndDrop(true);
	SortOrderGrid.init();
	SortOrderGrid.objBox.style.overflowX="hidden";
	SortOrderGrid.attachEvent("onSelectionChange",ConfigUpdated);
	}
}

function CreateCommandsNavigation()
{
	position="configwizard.js";
	whatfunc="CreateCommandsNavigation()";

	if (!CommandsGrid)
	{
	CommandsGrid=new dhtmlXGridObject('CommandsGrid');
	CommandsGrid.setImagePath("../common/codebase/imgs/");
	CommandsGrid.setSkin(dhxSkin);
	CommandsGrid.setHeader(getText(legCommands));
	CommandsGrid.setInitWidths("*");
	CommandsGrid.setColAlign("left");
	CommandsGrid.setColTypes("ro");
	CommandsGrid.enableMultiselect(false);
	CommandsGrid.enableMultiline(false);
	CommandsGrid.enableKeyboardSupport(false);
	CommandsGrid.enableDragAndDrop(true);
	CommandsGrid.attachEvent("onRowSelect",function (rowId) { 
	FillInCommand(CommandsGrid.getRowIndex(rowId)); 
                }); 
	CommandsGrid.attachEvent("onDrop", ExtractCommandsValues);
	CommandsGrid.setDelimiter("','");
	CommandsGrid.init();
	CommandsGrid.objBox.style.overflowX="hidden";
	}

	CommandsGrid.selectRow(0,false,false,true);
}

function PopulateCommandsGrid()
{
	position="configwizard.js";
	whatfunc="PopulateCommandsGrid()";

	CommandsGrid.clearAll();
	Commands.splice(0,Commands.length);

	if (configList[cpos].cmds.length<1)
	{
	FillInCommand(-1);

	return;
	}

	Commands=configList[cpos].cmds.split("','");
	for (var i=0; i<Commands.length; i++)
	CommandsGrid.addRow(i,ConvertSpecialCharactersToEntities(Commands[i]));

	CommandsGrid.selectRow(0,false,false,true);
	FillInCommand(0);
}

function LayoutCommandsMenuBar()
{
	position="configwizard.js";
	whatfunc="LayoutCommandsMenuBar()";

	CommandsMenuBar=new dhtmlXMenuObject("CommandsMenuBar",dhxSkin);
	CommandsMenuBar.setImagePath("../common/codebase/imgs/");
	CommandsMenuBar.setOpenMode("win");
	CommandsMenuBar.attachEvent("onClick",onClickHandlerCommands);
	CommandsMenuBar.addNewSibling(null, "cmd_paths", getText(lblPaths), false);
	CommandsMenuBar.addNewChild("cmd_paths", 0, "paths_wpipaths", "WPIPath", false, "", "");
	CommandsMenuBar.addNewChild("paths_wpipaths", 0, "paths_wpipath", "WPIPath", false, "", "");
	CommandsMenuBar.addNewChild("paths_wpipaths", 1, "paths_cdrom", "CDROM", false, "", "");
	CommandsMenuBar.addNewChild("paths_wpipaths", 2, "paths_root", "Root", false, "", "");
	CommandsMenuBar.addNewChild("cmd_paths", 1, "paths_dos", "DOS", false, "", "");
	CommandsMenuBar.addNewChild("paths_dos", 0, "paths_dospath", "DOSPath", false, "", "");
	CommandsMenuBar.addNewChild("paths_dos", 1, "paths_sysdrv", "SystemDrive", false, "", "");
	CommandsMenuBar.addNewChild("paths_dos", 2, "paths_windir", "WindowsDir", false, "", "");
	CommandsMenuBar.addNewChild("paths_dos", 3, "paths_programfiles", "ProgramFiles", false, "", "");
	CommandsMenuBar.addNewChild("paths_dos", 4, "paths_temp", "TEMP", false, "", "");
	CommandsMenuBar.addNewChild("paths_dos", 5, "paths_sysdir", "SystemDir", false, "", "");
	CommandsMenuBar.addNewChild("paths_dos", 6, "paths_allusersprofile", "AllUsersProfile", false, "", "");
	CommandsMenuBar.addNewChild("paths_dos", 7, "paths_userprofile", "UserProfile", false, "", "");
	CommandsMenuBar.addNewChild("paths_dos", 8, "paths_userprofileroot", "UserProfileRoot", false, "", "");
	CommandsMenuBar.addNewChild("paths_dos", 9, "paths_appdata", "AppData", false, "", "");
	CommandsMenuBar.addNewChild("paths_dos", 10, "paths_commonprogramfiles", "CommonProgramFiles", false, "", "");
	CommandsMenuBar.addNewSibling("cmd_paths", "cmd_dos", getText(lblDOS), false);
	CommandsMenuBar.addNewChild("cmd_dos", 0, "cmd_dos2", getText(lblDOS), false, "", "");
	CommandsMenuBar.addNewChild("cmd_dos2", 0, "dos_filecopy", "FileCopy", false, "", "");
	CommandsMenuBar.addNewChild("cmd_dos2", 1, "dos_filemove", "FileMove", false, "", "");
	CommandsMenuBar.addNewChild("cmd_dos2", 2, "dos_rename", "Rename", false, "", "");
	CommandsMenuBar.addNewChild("cmd_dos2", 3, "dos_delete", "Delete", false, "", "");
	CommandsMenuBar.addNewChild("cmd_dos2", 4, "dos_makedir", "MakeDir", false, "", "");
	CommandsMenuBar.addNewChild("cmd_dos2", 5, "dos_dircopy", "DirCopy", false, "", "");
	CommandsMenuBar.addNewChild("cmd_dos2", 6, "dos_dirmove", "DirMove", false, "", "");
	CommandsMenuBar.addNewChild("cmd_dos2", 7, "dos_deletedir", "DeleteDir", false, "", "");
	CommandsMenuBar.addNewChild("cmd_dos2", 8, "dos_extract", "Extract", false, "", "");
	CommandsMenuBar.addNewChild("cmd_dos2", 9, "dos_start", "Start", false, "", "");
	CommandsMenuBar.addNewChild("cmd_dos2", 10, "dos_batch", "Batch", false, "", "");
	CommandsMenuBar.addNewChild("cmd_dos", 1, "cmd_system", getText(lblSystem), false, "", "");
	CommandsMenuBar.addNewChild("cmd_system", 0, "dos_regedit", "RegEdit", false, "", "");
	CommandsMenuBar.addNewChild("cmd_system", 1, "dos_regdll", "RegDLL", false, "", "");
	CommandsMenuBar.addNewChild("cmd_system", 2, "dos_unregdll", "UnRegDLL", false, "", "");
	CommandsMenuBar.addNewChild("cmd_system", 3, "dos_instinf", "InstINF", false, "", "");
	CommandsMenuBar.addNewChild("cmd_system", 4, "dos_launchinf", "LaunchInf", false, "", "");
    CommandsMenuBar.addNewSibling("cmd_dos", "cmd_jscript", getText(lblJSCRIPT), false);
	CommandsMenuBar.addNewChild("cmd_jscript", 0, "jscript_dos", getText(lblDOS), false, "", "");
	CommandsMenuBar.addNewChild("jscript_dos", 0, "jscript_TimedWaitForFile", "TimedWaitForFile()", false, "", "");
	CommandsMenuBar.addNewChild("jscript_dos", 1, "jscript_TimedWaitForDelete", "TimedWaitForDelete()", false, "", "");
	CommandsMenuBar.addNewChild("jscript_dos", 2, "jscript_TimedWaitForProgram", "TimedWaitForProgram()", false, "", "");
	CommandsMenuBar.addNewChild("jscript_dos", 3, "jscript_setEnvVar", "setEnvVar()", false, "", "");
	CommandsMenuBar.addNewChild("jscript_dos", 4, "jscript_removeEnvVar", "removeEnvVar()", false, "", "");
	CommandsMenuBar.addNewChild("jscript_dos", 5, "jscript_FormatDrive", "FormatDrive()", false, "", "");
	CommandsMenuBar.addNewChild("cmd_jscript", 1, "jscript_registry", getText(lblRegistry), false, "", "");
	CommandsMenuBar.addNewChild("jscript_registry", 0, "jscript_CreateRegKey", "CreateRegKey()", false, "", "");
	CommandsMenuBar.addNewChild("jscript_registry", 1, "jscript_WriteRegKey", "WriteRegKey()", false, "", "");
	CommandsMenuBar.addNewChild("jscript_WriteRegKey", 0, "jscript_WriteRegKeyString", getText(lblRegString), false, "", "");
	CommandsMenuBar.addNewChild("jscript_WriteRegKey", 1, "jscript_WriteRegKeyDWORD", getText(lblRegDWORD), false, "", "");
	CommandsMenuBar.addNewChild("jscript_WriteRegKey", 2, "jscript_WriteRegKeyQWORD", getText(lblRegQWORD), false, "", "");
	CommandsMenuBar.addNewChild("jscript_WriteRegKey", 3, "jscript_WriteRegKeyMultiString", getText(lblRegMultiString), false, "", "");
	CommandsMenuBar.addNewChild("jscript_WriteRegKey", 4, "jscript_WriteRegKeyExpandableString", getText(lblRegExpandableString), false, "", "");
	CommandsMenuBar.addNewChild("jscript_registry", 2, "jscript_DeleteRegKey", "DeleteRegKey()", false, "", "");
	CommandsMenuBar.addNewChild("cmd_jscript", 2, "jscript_system", getText(lblSystem), false, "", "");
	CommandsMenuBar.addNewChild("jscript_system", 0, "jscript_CreateShortcut", "CreateShortcut()", false, "", "");
	CommandsMenuBar.addNewChild("jscript_system", 1, "jscript_RenameComputer", "RenameComputer()", false, "", "");
	CommandsMenuBar.addNewChild("jscript_system", 2, "jscript_CreateWindowsUser", "CreateWindowsUser()", false, "", "");
	CommandsMenuBar.addNewChild("jscript_system", 3, "jscript_DeleteWindowsUser", "DeleteWindowsUser()", false, "", "");
	CommandsMenuBar.addNewChild("jscript_system", 4, "jscript_SetPageFileSize", "SetPageFileSize()", false, "", "");
	CommandsMenuBar.addNewChild("jscript_system", 5, "jscript_SetAutoLogonUser", "SetAutoLogonUser()", false, "", "");
	CommandsMenuBar.addNewChild("jscript_system", 6, "jscript_ClearAutoLogonUser", "ClearAutoLogonUser()", false, "", "");
	CommandsMenuBar.addNewChild("jscript_system", 7, "jscript_SecurityCenterXP", "SecurityCenter() XP", false, "", "");
	CommandsMenuBar.addNewChild("jscript_system", 8, "jscript_ScreenSaver", "ScreenSaver()", false, "", "");
	CommandsMenuBar.addNewChild("jscript_system", 9, "jscript_PowerOptions", "PowerOptions()", false, "", "");
	CommandsMenuBar.addNewChild("jscript_system", 10, "jscript_ErrorReporting", "ErrorReporting()", false, "", "");
	CommandsMenuBar.addNewChild("cmd_jscript", 3, "jscript_networking", getText(lblNetwork), false, "", "");
	CommandsMenuBar.addNewChild("jscript_networking", 0, "jscript_SetFirewall", "SetFirewall()", false, "", "");
	CommandsMenuBar.addNewChild("jscript_networking", 1, "jscript_SetFilePrinterSharing", "SetFilePrinterSharing()", false, "", "");
	CommandsMenuBar.addNewChild("jscript_networking", 2, "jscript_MapNetworkDrive", "MapNetworkDrive()", false, "", "");
	CommandsMenuBar.addNewChild("jscript_networking", 3, "jscript_ShareFolder", "ShareFolder()", false, "", "");
	CommandsMenuBar.addNewChild("cmd_jscript", 4, "jscript_other", getText(lblOther), false, "", "");
	CommandsMenuBar.addNewChild("jscript_other", 0, "jscript_alert", "alert()", false, "", "");
	CommandsMenuBar.addNewSibling("cmd_jscript", "internet", getText(lblInternet), false);
	CommandsMenuBar.addNewChild("internet", 0, "internet_Web", getText(lblOpenAWebSite), false, "", "");
	CommandsMenuBar.addNewChild("internet", 1, "internet_Download", getText(lblDownloadAProgram), false, "", "");
	CommandsMenuBar.addNewSibling("internet", "cmd_cond", getText(lblCondition), false); 
    CommandsMenuBar.addNewChild("cmd_cond", 0, "cmd_cond_operatingsystem", getText(lblOperatingSystem), false, "", ""); 
    CommandsMenuBar.addNewChild("cmd_cond", 1, "cmd_cond_architecture", getText(lblArchitecture), false, "", ""); 
    CommandsMenuBar.addNewChild("cmd_cond_architecture", 0, "cmd_cond_architecture_x86", "x86", false, "", ""); 
    CommandsMenuBar.addNewChild("cmd_cond_architecture", 1, "cmd_cond_architecture_x64", "x64", false, "", ""); 
	CommandsMenuBar.addNewSibling("cmd_cond", "cmd_other", getText(lblOther), false); 
    CommandsMenuBar.addNewChild("cmd_other", 1, "other_runbg", "Run In Bg", false, "", ""); 
    CommandsMenuBar.addNewChild("cmd_other", 2, "other_taskkill", "TaskKill", false, "", ""); 
    CommandsMenuBar.addNewChild("cmd_other", 3, "other_sleep", "Sleep", false, "", ""); 
    CommandsMenuBar.addNewChild("cmd_other", 4, "other_reboot", "Reboot", false, "", ""); 
	CommandsMenuBar.setOverflowHeight(9);
}
function SetUpConditionMenuBar(menuId,whichCond,condHandler) 
{ 
	position="configwizard.js"; 
	whatfunc="SetUpConditionMenuBar()"; 
	 
	var ConditionsMenuBar=new dhtmlXMenuObject(menuId,dhxSkin,true); 
	ConditionsMenuBar.setImagePath("../common/codebase/imgs/"); 
	ConditionsMenuBar.setOpenMode("win"); 
	ConditionsMenuBar.attachEvent("onClick",condHandler); 
	 
	ConditionsMenuBar.addNewSibling(null, WhichCond + "_filesystem", getText(lblFileSystem), false); 
	ConditionsMenuBar.addNewChild(WhichCond + "_filesystem", 0, WhichCond + "_filesystem_file", getText(lblFile), false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_filesystem_file", 0, "filesystem_FileExists", "FileExists()", false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_filesystem_file", 1, "filesystem_getFileSize", "getFileSize()", false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_filesystem_file", 2, "filesystem_getFileType", "getFileType()", false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_filesystem_file", 3, "filesystem_getFileVersion", "getFileVersion()", false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_filesystem_file", 4, "filesystem_fileVersionGreaterThan", "fileVersionGreaterThan()", false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_filesystem", 1, WhichCond + "_filesystem_folder", getText(lblFolder), false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_filesystem_folder", 0, "filesystem_FolderExists", "FolderExists()", false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_filesystem_folder", 1, "filesystem_getFolderSize", "getFolderSize()", false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_filesystem", 2, WhichCond + "_filesystem_drive", getText(lblDrive), false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_filesystem_drive", 0, "filesystem_DriveExists", "DriveExists()", false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_filesystem_drive", 1, "filesystem_DriveType", "DriveType()", false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_filesystem_drive", 2, "filesystem_DriveVolumeName", "DriveVolumeName()", false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_filesystem_drive", 3, "filesystem_DriveShareName", "DriveShareName()", false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_filesystem_drive", 4, "filesystem_DriveFileSystem", "DriveFileSystem()", false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_filesystem_drive", 5, "filesystem_DriveAvailableSpace", "DriveAvailableSpace()", false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_filesystem_drive", 6, "filesystem_DriveTotalSize", "DriveTotalSize()", false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_filesystem", 3, "filesystem_getComSpec", "getComSpec()", false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_filesystem", 4, "filesystem_getEnvVar", "getEnvVar()", false, "", ""); 
	ConditionsMenuBar.addNewSibling(WhichCond + "_filesystem", WhichCond + "_registry", getText(lblRegistry), false); 
	ConditionsMenuBar.addNewChild(WhichCond + "_registry", 0, "registry_RegKeyExists", "RegKeyExists()", false, "", "");  
    ConditionsMenuBar.addNewChild(WhichCond + "_registry", 1, "registry_RegValueExists", "RegValueExists()", false, "", "");  
    ConditionsMenuBar.addNewChild(WhichCond + "_registry", 2, "registry_RegKeyValue", "RegKeyValue()", false, "", ""); 
	ConditionsMenuBar.addNewSibling(WhichCond + "_registry", WhichCond + "_architecture", getText(lblArchitecture), false); 
	ConditionsMenuBar.addNewChild(WhichCond + "_architecture", 0, WhichCond + "_architecture_os", getText(lblOperatingSystem), false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_architecture_os", 0, "architecture_getOSver", "getOSver()", false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_architecture_os", 1, "architecture_getOSvernum", "getOSvernum()", false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_architecture_os", 2, "architecture_getSPver", "getSPver()", false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_architecture_os", 3, "architecture_getOSlang", "getOSlang()", false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_architecture_os", 4, "architecture_getOSlocale", "getOSlocale()", false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_architecture", 1, WhichCond + "_architecture_arch", getText(lblArchitecture), false, "", "");
	ConditionsMenuBar.addNewChild(WhichCond + "_architecture_arch", 0, "architecture_getArch", "getArch()", false, "", ""); 
    ConditionsMenuBar.addNewChild(WhichCond + "_architecture_arch", 1, "architecture_getBits", "getBits()", false, "", ""); 
    ConditionsMenuBar.addNewChild(WhichCond + "_architecture_arch", 2, "architecture_getArchName", "getArchName()", false, "", ""); 
    ConditionsMenuBar.addNewChild(WhichCond + "_architecture_arch", 3, "architecture_getArchNameString", "getArchNameString()", false, "", ""); 
    ConditionsMenuBar.addNewChild(WhichCond + "_architecture_arch", 4, "architecture_getArchIdentifier", "getArchIdentifier()", false, "", ""); 
    ConditionsMenuBar.addNewChild(WhichCond + "_architecture_arch", 5, "architecture_getNumProcs", "getNumProcs()", false, "", ""); 
    ConditionsMenuBar.addNewChild(WhichCond + "_architecture_arch", 6, "architecture_getArchMHz", "getArchMHz()", false, "", "");
	ConditionsMenuBar.addNewChild(WhichCond + "_architecture", 2, WhichCond + "_architecture_hardware", getText(lblHardware), false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_architecture_hardware", 0, "architecture_getBaseBoardManufacturer", "getBaseBoardManufacturer()", false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_architecture_hardware", 1, "architecture_getBaseBoardModel", "getBaseBoardModel()", false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_architecture_hardware", 2, "architecture_getVideoControllerID", "getVideoControllerID()", false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_architecture_hardware", 3, "architecture_getSoundDeviceID", "getSoundDeviceID()", false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_architecture_hardware", 4, "architecture_getNetworkAdapterID", "getNetworkAdapterID()", false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_architecture_hardware", 5, "architecture_getWirelessNetworkAdapterID", "getWirelessNetworkAdapterID()", false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_architecture_hardware", 6, "architecture_getModemID", "getModemID()", false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_architecture_hardware", 7, "architecture_getHDDControllerID", "getHDDControllerID()", false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_architecture_hardware", 8, "architecture_getCDROMID", "getCDROMID()", false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_architecture_hardware", 9, "architecture_getCDBurnerID", "getCDBurnerID()", false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_architecture_hardware", 10, "architecture_getCDBurnerName", "getCDBurnerName()", false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_architecture_hardware", 11, "architecture_hasDVDROM", "hasDVDROM()", false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_architecture_hardware", 12, "architecture_hasDVDBurner", "hasDVDBurner()", false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_architecture_hardware", 13, "architecture_hasDVDDrive", "hasDVDDrive()", false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_architecture_hardware", 14, "architecture_getKeyboardID", "getKeyboardID()", false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_architecture_hardware", 15, "architecture_getPointingDeviceID", "getPointingDeviceID()", false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_architecture_hardware", 99, "architecture_getSystemEnclosureType", "getSystemEnclosureType()", false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_architecture", 3, WhichCond + "_architecture_system", getText(lblSystem), false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_architecture_system", 0, "architecture_getSysManufacturer", "getSysManufacturer()", false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_architecture_system", 1, "architecture_getSysModel", "getSysModel()", false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_architecture_system", 2, "architecture_getSysPCType", "getSysPCType()", false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_architecture_system", 3, "architecture_getSysType", "getSysType()", false, "", ""); 
	ConditionsMenuBar.addNewSeparator("architecture_getSysType", 4); 
	ConditionsMenuBar.addNewChild(WhichCond + "_architecture_system", 5, "architecture_getFreeRAM", "getFreeRAM()", false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_architecture_system", 6, "architecture_getTotalRAM", "getTotalRAM()", false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_architecture", 4, WhichCond + "_architecture_bios", getText(lblBIOS), false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_architecture_bios", 0, "architecture_getBIOSManufacturer", "getBIOSManufacturer()", false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_architecture_bios", 1, "architecture_getBIOSVersion", "getBIOSVersion()", false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_architecture_bios", 2, "architecture_getSMBIOSVersion", "getSMBIOSVersion()", false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_architecture_bios", 3, "architecture_getBIOSCaption", "getBIOSCaption()", false, "", ""); 
	ConditionsMenuBar.addNewSibling(WhichCond + "_architecture", WhichCond + "_security", getText(lblSecurity), false); 
	ConditionsMenuBar.addNewChild(WhichCond + "_security", 0, "security_isLogOnServer", "isLogOnServer()", false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_security", 1, "security_isUserDomain", "isUserDomain()", false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_security", 2, "security_isComputerName", "isComputerName()", false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_security", 3, "security_isUserName", "isUserName()", false, "", ""); 
	ConditionsMenuBar.addNewSeparator("security_isUserName", 4); 
	ConditionsMenuBar.addNewChild(WhichCond + "_security", 5, "security_getFirewallProduct", "getFirewallProduct()", false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_security", 6, "security_getAntiVirusProduct", "getAntiVirusProduct()", false, "", ""); 
	ConditionsMenuBar.addNewSibling(WhichCond + "_security", WhichCond + "_other", getText(lblOther), false); 
	ConditionsMenuBar.addNewChild(WhichCond + "_other", 0, "other_ConnectedToInternet", "ConnectedToInternet()", false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_other", 1, "other_isInstalled", "isInstalled()", false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_other", 2, "other_getIEver", "getIEver()", false, "", ""); 
	ConditionsMenuBar.addNewChild(WhichCond + "_other", 3, "other_isDesktopLoaded", "isDesktopLoaded()", false, "", ""); 
	ConditionsMenuBar.setOverflowHeight(6); 
}

function onClickHandlerCommands(itemId,itemValue)
{
	position="configwizard.js";
	whatfunc="onClickHandlerCommands()";
	switch(itemId)
	{
	
	case 'paths_wpipath':
	HandleCommandsSelectionMenu("%wpipath%\\");
	break;

	case 'paths_cdrom':
	HandleCommandsSelectionMenu("%cdrom%\\");
	break;

	case 'paths_root':
	HandleCommandsSelectionMenu("%root%\\");
	break;

	case 'paths_dospath':
	HandleCommandsSelectionMenu("%dospath%\\");
	break;

	case 'paths_sysdrv':
	HandleCommandsSelectionMenu("%sysdrv%\\");
	break;

	case 'paths_windir':
	HandleCommandsSelectionMenu("%windir%\\");
	break;

	case 'paths_programfiles':
	HandleCommandsSelectionMenu("%programfiles%\\");
	break;

	case 'paths_temp':
	HandleCommandsSelectionMenu("%temp%\\");
	break;

	case 'paths_sysdir':
	HandleCommandsSelectionMenu("%sysdir%\\");
	break;

	case 'paths_allusersprofile':
	HandleCommandsSelectionMenu("%allusersprofile%\\");
	break;

	case 'paths_userprofile':
	HandleCommandsSelectionMenu("%userprofile%\\");
	break;

	case 'paths_userprofileroot':
	HandleCommandsSelectionMenu("%userprofileroot%\\");
	break;

	case 'paths_appdata':
	HandleCommandsSelectionMenu("%appdata%\\");
	break;

	case 'paths_commonprogramfiles':
	HandleCommandsSelectionMenu("%commonprogramfiles%\\");
	break;

	case 'dos_filecopy':
	HandleCommandsSelectionMenu("{FILECOPY} ");
	break;

	case 'dos_filemove':
	HandleCommandsSelectionMenu("{FILEMOVE} ");
	break;

	case 'dos_rename':
	HandleCommandsSelectionMenu("{RENAME} ");
	break;

	case 'dos_delete':
	HandleCommandsSelectionMenu("{DELETE} ");
	break;

	case 'dos_makedir':
	HandleCommandsSelectionMenu("{MAKEDIR} ");
	break;

	case 'dos_dircopy':
	HandleCommandsSelectionMenu("{DIRCOPY} ");
	break;

	case 'dos_dirmove':
	Alert("",getText(txtBothMustBeInQuotes),getText(lblOK),"",3,0,0,0);
	HandleCommandsSelectionMenu("{DIRMOVE} ");
	break;

	case 'dos_deletedir':
	HandleCommandsSelectionMenu("{DELDIR} ");
	break;

	case 'dos_extract':
	Alert("",getText(txtBothMustBeInQuotes),getText(lblOK),"",3,0,0,0);
	HandleCommandsSelectionMenu("{EXTRACT} ");
	break;

	case 'dos_start':
	HandleCommandsSelectionMenu("{START} ");
	break;

	case 'dos_regedit':
	HandleCommandsSelectionMenu("{REGEDIT} ");
	break;
	
	case 'dos_batch':
	HandleCommandsSelectionMenu("{BATCH} ");
	break;
	
	case 'dos_regdll':
	HandleCommandsSelectionMenu("{REGDLL} ");
	break;

	case 'dos_unregdll':
	HandleCommandsSelectionMenu("{UNREGDLL} ");
	break;

	case 'dos_instinf':
	HandleCommandsSelectionMenu("{INSTINF} ");
	break;
	
	case 'dos_launchinf':
	HandleCommandsSelectionMenu("{LAUNCHINF} ");
	break;

	case 'jscript_alert':
	HandleCommandsSelectionMenu('{JSCRIPT}=alert("Your message")');
	break;

	case 'jscript_TimedWaitForFile':
	HandleCommandsSelectionMenu('{JSCRIPT}=TimedWaitForFile("C:\\Folder\\File.exe",10)');
	break;

	case 'jscript_TimedWaitForDelete':
	HandleCommandsSelectionMenu('{JSCRIPT}=TimedWaitForDelete("C:\\Folder\\File.exe",10)');
	break;

	case 'jscript_TimedWaitForProgram':
	HandleCommandsSelectionMenu('{JSCRIPT}=TimedWaitForProgram("Setup.exe",10)');
	break;

	case 'jscript_CreateRegKey':
	ShowCreateRegKey();
	break;

	case 'jscript_WriteRegKeyString':
	WriteRegType="REG_SZ";
	ShowWriteRegKey1();
	break;

	case 'jscript_WriteRegKeyDWORD':
	WriteRegType="REG_DWORD";
	ShowWriteRegKey1();
	break;

	case 'jscript_WriteRegKeyQWORD':
	WriteRegType="REG_QWORD";
	ShowWriteRegKey1();
	break;

	case 'jscript_WriteRegKeyMultiString':
	WriteRegType="REG_MULTI_SZ";
	ShowWriteRegKey2();
	break;

	case 'jscript_WriteRegKeyExpandableString':
	WriteRegType="REG_EXPAND_SZ";
	ShowWriteRegKey1();
	break;

	case 'jscript_DeleteRegKey':
	HandleCommandsSelectionMenu('{JSCRIPT}=DeleteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\Test Key")');
	break;

	case 'jscript_setEnvVar':
	HandleCommandsSelectionMenu('{JSCRIPT}=setEnvVar("VARIABLE","value",true)');
	break;

	case 'jscript_removeEnvVar':
	HandleCommandsSelectionMenu('{JSCRIPT}=removeEnvVar("VARIABLE")');
	break;

	case 'jscript_CreateShortcut':
	ShowCreateShortcut();
	break;

	case 'jscript_RenameComputer':
	HandleCommandsSelectionMenu('{JSCRIPT}=RenameComputer("Name")');
	break;

	case 'jscript_CreateWindowsUser':
	ShowCreateWindowsUser();
	break;

	case 'jscript_DeleteWindowsUser':
	ShowDeleteWindowsUser();
	break;

	case 'jscript_SetFirewall':
	ShowSetFirewall();
	break;

	case 'jscript_SetFilePrinterSharing':
	ShowSetFilePrinterSharing();
	break;

	case 'jscript_MapNetworkDrive':
	ShowMapNetworkDrive();
	break;

	case 'jscript_ShareFolder':
	ShowShareFolder();
	break;

	case 'jscript_SetPageFileSize':
	ShowSetPageFileSize();
	break;

	case 'jscript_FormatDrive':
	ShowFormatDrive();
	break;

	case 'jscript_SetAutoLogonUser':
	ShowSetAutoLogonUser();
	break;

	case 'jscript_SecurityCenterXP':
	ShowSetSecurityCenter_XP();
	break;

	case 'jscript_ScreenSaver':
	ShowScreenSaver();
	break;

	case 'jscript_PowerOptions':
	ShowPowerOptions();
	break;

	case 'jscript_ErrorReporting':
	ShowErrorReporting();
	break;

	case 'jscript_ClearAutoLogonUser':
	HandleCommandsSelectionMenu('{JSCRIPT}=ClearAutoLogonUser()');
	break;

	case 'internet_Web':
	HandleCommandsSelectionMenu("{WEB} http://www.");
	break;

	case 'internet_Download':
	HandleCommandsSelectionMenu("{DOWNLOAD} http://www.");
	break;

    case 'cmd_cond_operatingsystem': 
	HandleCommandsSelectionMenu("{OS=Win8.1 || Win8 || Win7 || Vista || XP || 2K} "); 
	break;
 
    case 'cmd_cond_architecture_x86': 
	HandleCommandsSelectionMenu("{x86} "); 
	break; 
 
    case 'cmd_cond_architecture_x64': 
	HandleCommandsSelectionMenu("{x64} "); 
	break;

	case 'other_runbg':
	HandleCommandsSelectionMenu("{RUNBG} ");
	break;

	case 'other_taskkill':
	HandleCommandsSelectionMenu("{TASKKILL} prog.exe");
	break;

	case 'other_sleep':
	HandleCommandsSelectionMenu("{SLEEP} 30");
	break;

	case 'other_reboot':
	HandleCommandsSelectionMenu("{REBOOT} 30");
	break;
	}
}

function onClickHandlerConditions(itemId,itemValue)
{
	position="configwizard.js";
	whatfunc="onClickHandlerConditions()";

	WhichCond="cond";
	onClickHandlerConditionsMenus(itemId,itemValue);
	ConfigUpdated();
}

function onClickHandlerGrayedConditions(itemId,itemValue)
{
	position="configwizard.js";
	whatfunc="onClickHandlerGrayedConditions()";

	WhichCond="gcond";
	onClickHandlerConditionsMenus(itemId,itemValue);
	ConfigUpdated();
}

function onClickHandlerConditionsMenus(itemId,itemValue)
{
	position="configwizard.js";
	whatfunc="onClickHandlerConditionsMenus()";
	
	switch(itemId)
	{
	case 'filesystem_FileExists':
	HandleConditionsSelectionMenu(!InsertCondValues ? "FileExists()" : 'FileExists("C:\\Folder\\File.exe")');
	break;

	case 'filesystem_getFileSize':
	HandleConditionsSelectionMenu(!InsertCondValues ? "getFileSize()" : 'getFileSize("C:\\Folder\\File.exe")>50000');
	break;

	case 'filesystem_getFileType':
	HandleConditionsSelectionMenu(!InsertCondValues ? "getFileType()" : 'getFileType("C:\\Folder\\File.exe")=="PNG Image"');
	break;

	case 'filesystem_getFileVersion':
	HandleConditionsSelectionMenu(!InsertCondValues ? "getFileVersion()" : 'getFileVersion("C:\\Folder\\File.exe")=="2.0"');
	break;

	case 'filesystem_fileVersionGreaterThan':
	HandleConditionsSelectionMenu(!InsertCondValues ? "fileVersionGreaterThan()" : 'fileVersionGreaterThan("2.0",getFileVersion("C:\\Folder\\File.exe"))');
	break;

	case 'filesystem_FolderExists':
	HandleConditionsSelectionMenu(!InsertCondValues ? "FolderExists()" : 'FolderExists("C:\\Folder\\Folder")');
	break;

	case 'filesystem_getFolderSize':
	HandleConditionsSelectionMenu(!InsertCondValues ? "getFolderSize()" : 'getFolderSize("C:\\Folder\\Folder")>10000000');
	break;

	case 'filesystem_DriveExists':
	HandleConditionsSelectionMenu(!InsertCondValues ? "DriveExists()" : 'DriveExists("F:")');
	break;

	case 'filesystem_DriveType':
	HandleConditionsSelectionMenu(!InsertCondValues ? "DriveType()" : 'DriveType("D:")==4');
	break;

	case 'filesystem_DriveVolumeName':
	HandleConditionsSelectionMenu(!InsertCondValues ? "DriveVolumeName()" : 'DriveVolumeName("G:")=="Music"');
	break;

	case 'filesystem_DriveShareName':
	HandleConditionsSelectionMenu(!InsertCondValues ? "DriveShareName()" : 'DriveShareName("W:")=="\\\\server\\share"');
	break;

	case 'filesystem_DriveFileSystem':
	HandleConditionsSelectionMenu(!InsertCondValues ? "DriveFileSystem()" : 'DriveFileSystem("C:")=="NTFS"');
	break;

	case 'filesystem_DriveAvailableSpace':
	HandleConditionsSelectionMenu(!InsertCondValues ? "DriveAvailableSpace()" : 'DriveAvailableSpace("C:")>10');
	break;

	case 'filesystem_DriveTotalSize':
	HandleConditionsSelectionMenu(!InsertCondValues ? "DriveTotalSize()" : 'DriveTotalSize("C:")>150');
	break;

	case 'filesystem_getComSpec':
	HandleConditionsSelectionMenu(!InsertCondValues ? "getComSpec()" : 'getComSpec()=="'+getComSpec()+'"');
	break;

	case 'filesystem_getEnvVar':
	HandleConditionsSelectionMenu(!InsertCondValues ? "getEnvVar()" : 'getEnvVar("VARIABLE")=="value"');
	break;

	case 'filesystem_setEnvVar':
	HandleConditionsSelectionMenu(!InsertCondValues ? "setEnvVar()" : 'setEnvVar("VARIABLE","value",true)');
	break;

	case 'registry_RegKeyExists': 
    HandleConditionsSelectionMenu(!InsertCondValues ? "RegKeyExists()" : 'RegKeyExists("HKEY_CURRENT_USER\\Software\\WPI")'); 
     break; 
 
    case 'registry_RegValueExists': 
    HandleConditionsSelectionMenu(!InsertCondValues ? "RegValueExists()" : 'RegValueExists("HKEY_CURRENT_USER\\Software\\WPI\\Theme")'); 
    break;

	case 'registry_RegKeyValue':
	HandleConditionsSelectionMenu(!InsertCondValues ? "RegKeyValue()" : 'RegKeyValue("HKEY_CURRENT_USER\\Software\\WPI\\Theme")=="Windows"');
	break;

	case 'architecture_getOSver':
	HandleConditionsSelectionMenu(!InsertCondValues ? "getOSver()" : 'getOSver()=="'+getOSver()+'"');
	break;
	
	case 'architecture_getOSvernum': 
    HandleConditionsSelectionMenu(!InsertCondValues ? "getOSvernum()" : 'getOSvernum()=="'+getOSvernum()+'"'); 
    break;

	case 'architecture_getSPver':
	HandleConditionsSelectionMenu(!InsertCondValues ? "getSPver()" : 'getSPver()=='+getSPver());
	break;

	case 'architecture_getOSlang':
	HandleConditionsSelectionMenu(!InsertCondValues ? "getOSlang()" : 'getOSlang()=="'+getOSlang()+'"');
	break;

	case 'architecture_getOSlocale':
	HandleConditionsSelectionMenu(!InsertCondValues ? "getOSlocale()" : 'getOSlocale()=="'+getOSlocale()+'"');
	break;
	
	case 'architecture_getArch':
	HandleConditionsSelectionMenu(!InsertCondValues ? "getArch()" : 'getArch()=="'+getArch()+'"');
	break;

	case 'architecture_getBits':
	HandleConditionsSelectionMenu(!InsertCondValues ? "getBits()" : 'getBits()=='+getBits());
	break;

	case 'architecture_getArchName':
	HandleConditionsSelectionMenu(!InsertCondValues ? "getArchName()" : 'getArchName()=="'+getArchName()+'"');
	break;

	case 'architecture_getArchNameString':
	HandleConditionsSelectionMenu(!InsertCondValues ? "getArchNameString()" : 'getArchNameString()=="'+getArchNameString()+'"');
	break;

	case 'architecture_getArchIdentifier':
	HandleConditionsSelectionMenu(!InsertCondValues ? "getArchIdentifier()" : 'getArchIdentifier()=="'+getArchIdentifier()+'"');
	break;

	case 'architecture_getNumProcs':
	HandleConditionsSelectionMenu(!InsertCondValues ? "getNumProcs()" : 'getNumProcs()>1');
	break;

	case 'architecture_getArchMHz':
	HandleConditionsSelectionMenu(!InsertCondValues ? "getArchMHz()" : 'getArchMHz()>2000');
	break;

	case 'architecture_getBaseBoardManufacturer':
	HandleConditionsSelectionMenu(!InsertCondValues ? "getBaseBoardManufacturer()" : 'getBaseBoardManufacturer()=="'+getBaseBoardManufacturer()+'"');
	break;

	case 'architecture_getBaseBoardModel':
	HandleConditionsSelectionMenu(!InsertCondValues ? "getBaseBoardModel()" : 'getBaseBoardModel()=="'+getBaseBoardModel()+'"');
	break;

	case 'architecture_getVideoControllerID':
	HandleConditionsSelectionMenu(!InsertCondValues ? "getVideoControllerID()" : 'getVideoControllerID()=="'+getVideoControllerID()+'"');
	break;

	case 'architecture_getSoundDeviceID':
	HandleConditionsSelectionMenu(!InsertCondValues ? "getSoundDeviceID()" : 'getSoundDeviceID()=="'+getSoundDeviceID()+'"');
	break;

	case 'architecture_getNetworkAdapterID':
	HandleConditionsSelectionMenu(!InsertCondValues ? "getNetworkAdapterID()" : 'getNetworkAdapterID()=="'+getNetworkAdapterID()+'"');
	break;

	case 'architecture_getWirelessNetworkAdapterID':
	HandleConditionsSelectionMenu(!InsertCondValues ? "getWirelessNetworkAdapterID()" : 'getWirelessNetworkAdapterID()=="'+getWirelessNetworkAdapterID()+'"');
	break;

	case 'architecture_getModemID':
	HandleConditionsSelectionMenu(!InsertCondValues ? "getModemID()" : 'getModemID()=="'+getModemID()+'"');
	break;

	case 'architecture_getHDDControllerID':
	HandleConditionsSelectionMenu(!InsertCondValues ? 'getHDDControllerID("PCI\\VEN_")' : 'getHDDControllerID("PCI\\VEN_")');
	break;

	case 'architecture_getCDROMID':
	HandleConditionsSelectionMenu(!InsertCondValues ? "getCDROMID()" : 'getCDROMID()=="'+getCDROMID()+'"');
	break;

	case 'architecture_getCDBurnerID':
	HandleConditionsSelectionMenu(!InsertCondValues ? "getCDBurnerID()" : 'getCDBurnerID()=="'+getCDBurnerID()+'"');
	break;

	case 'architecture_getCDBurnerName':
	HandleConditionsSelectionMenu(!InsertCondValues ? "getCDBurnerName()" : 'getCDBurnerName()=="'+getCDBurnerName()+'"');
	break;

	case 'architecture_hasDVDROM':
	HandleConditionsSelectionMenu(!InsertCondValues ? "hasDVDROM()" : 'hasDVDROM()');
	break;

	case 'architecture_hasDVDBurner':
	HandleConditionsSelectionMenu(!InsertCondValues ? "hasDVDBurner()" : 'hasDVDBurner()');
	break;

	case 'architecture_hasDVDDrive':
	HandleConditionsSelectionMenu(!InsertCondValues ? "hasDVDDrive()" : 'hasDVDDrive()');
	break;

	case 'architecture_getKeyboardID':
	HandleConditionsSelectionMenu(!InsertCondValues ? "getKeyboardID()" : 'getKeyboardID()=="'+getKeyboardID()+'"');
	break;

	case 'architecture_getPointingDeviceID':
	HandleConditionsSelectionMenu(!InsertCondValues ? "getPointingDeviceID()" : 'getPointingDeviceID()=="'+getPointingDeviceID()+'"');
	break;

	case 'architecture_getSystemEnclosureType':
	HandleConditionsSelectionMenu(!InsertCondValues ? "getSystemEnclosureType()" : 'getSystemEnclosureType()=="'+getSystemEnclosureType()+'"');
	break;

	case 'architecture_getSysManufacturer':
	HandleConditionsSelectionMenu(!InsertCondValues ? "getSysManufacturer()" : 'getSysManufacturer()=="'+getSysManufacturer()+'"');
	break;

	case 'architecture_getSysModel':
	HandleConditionsSelectionMenu(!InsertCondValues ? "getSysModel()" : 'getSysModel()=="'+getSysModel()+'"');
	break;

	case 'architecture_getSysPCType':
	HandleConditionsSelectionMenu(!InsertCondValues ? "getSysPCType()" : 'getSysPCType()=="'+getSysPCType()+'"');
	break;

	case 'architecture_getSysType':
	HandleConditionsSelectionMenu(!InsertCondValues ? "getSysType()" : 'getSysType()=="'+getSysType()+'"');
	break;

	case 'architecture_getFreeRAM':
	HandleConditionsSelectionMenu(!InsertCondValues ? "getFreeRAM()" : 'getFreeRAM()>512');
	break;

	case 'architecture_getTotalRAM':
	HandleConditionsSelectionMenu(!InsertCondValues ? "getTotalRAM()" : 'getTotalRAM()>1024');
	break;

	case 'architecture_getBIOSManufacturer':
	HandleConditionsSelectionMenu(!InsertCondValues ? "getBIOSManufacturer()" : 'getBIOSManufacturer()=="'+getBIOSManufacturer()+'"');
	break;

	case 'architecture_getBIOSVersion':
	HandleConditionsSelectionMenu(!InsertCondValues ? "getBIOSVersion()" : 'getBIOSVersion()=="'+getBIOSVersion()+'"');
	break;

	case 'architecture_getSMBIOSVersion':
	HandleConditionsSelectionMenu(!InsertCondValues ? "getSMBIOSVersion()" : 'getSMBIOSVersion()=="'+getSMBIOSVersion()+'"');
	break;

	case 'architecture_getBIOSCaption':
	HandleConditionsSelectionMenu(!InsertCondValues ? "getBIOSCaption()" : 'getBIOSCaption()=="'+getBIOSCaption()+'"');
	break;

	case 'security_isLogOnServer':
	HandleConditionsSelectionMenu(!InsertCondValues ? "isLogOnServer()" : 'isLogOnServer("'+LogOnServer+'")');
	break;

	case 'security_isUserDomain':
	HandleConditionsSelectionMenu(!InsertCondValues ? "isUserDomain()" : 'isUserDomain("'+UserDomain+'")');
	break;

	case 'security_isComputerName':
	HandleConditionsSelectionMenu(!InsertCondValues ? "isComputerName()" : 'isComputerName("'+ComputerName+'")');
	break;

	case 'security_isUserName':
	HandleConditionsSelectionMenu(!InsertCondValues ? "isUserName()" : 'isUserName("'+UserName+'")');
	break;

	case 'security_getFirewallProduct':
	HandleConditionsSelectionMenu(!InsertCondValues ? "getFirewallProduct()" : 'getFirewallProduct()=="'+getFirewallProduct()+'"');
	break;

	case 'security_getAntiVirusProduct':
	HandleConditionsSelectionMenu(!InsertCondValues ? "getAntiVirusProduct()" : 'getAntiVirusProduct()=="'+getAntiVirusProduct()+'"');
	break;

	case 'other_ConnectedToInternet':
	HandleConditionsSelectionMenu(!InsertCondValues ? "ConnectedToInternet()" : 'ConnectedToInternet("'+ConnToNet+'")');
	break;

	case 'other_isInstalled':
	HandleConditionsSelectionMenu(!InsertCondValues ? "isInstalled()" : 'isInstalled("Adobe Reader 8.1.2")');
	break;

	case 'other_getIEver':
	HandleConditionsSelectionMenu(!InsertCondValues ? "getIEver()" : 'getIEver()=="'+getIEver()+'"');
	break;

	case 'other_isDesktopLoaded':
	HandleConditionsSelectionMenu(!InsertCondValues ? "isDesktopLoaded()" : 'isDesktopLoaded("'+DesktopLoaded+'")');
	break;
	}
}

function FillInConfig(pos)
{
	position="configwizard.js";
	whatfunc="FillInConfig()";

	document.getElementById("prog").value=configList[pos].prog;
	document.getElementById("shortdesc").value=configList[pos].shortdesc;
	document.getElementById("uid").value=configList[pos].uid;
	document.getElementById("ordr").value=configList[pos].ordr;
	document.getElementById("dflt").checked=configList[pos].dflt=="yes" ? 1 : 0;
	document.getElementById("forc").checked=configList[pos].forc=="yes" ? 1 : 0;
	document.getElementById("cbocats").value=configList[pos].cat;
	document.getElementById("cat").value="";
	document.getElementById("cat").style.visibility='hidden';
	document.getElementById("SelectConfigs").value="blank";
	document.getElementById("configs").value=configList[pos].configs;
	document.getElementById("RebootCode").value=configList[pos].rebootcode;
	document.getElementById("RepeatCommand").value=configList[pos].repeatcommand;
	document.getElementById("CheckPFRO").checked=configList[pos].pfro=="yes" ? 1 : 0;
	document.getElementById("picf").value=configList[pos].picf;
	document.getElementById("picw").value=configList[pos].picw;
	document.getElementById("pich").value=configList[pos].pich;
	document.getElementById("textl").value=configList[pos].textl;
	document.getElementById("deps").value=configList[pos].deps;
	document.getElementById("excl").value=configList[pos].excl;
	document.getElementById("cond").value=configList[pos].cond;
	document.getElementById("gcond").value=configList[pos].gcond;
	HandleRebootCode();
	PopulateCommandsGrid();
	DescriptionEditor.setContent(configList[pos].desc);
	TogglePictureGadgets();
}

function ExtractCommandsValues()
{
	position="configwizard.js";
	whatfunc="ExtractCommandsValues()";

	Commands.splice(0,Commands.length);

	for (i=0; i<CommandsGrid.getRowsNum(); i++)
Commands.splice(Commands.length,0,RestoreSpecialCharactersFromEntities(CommandsGrid.cells(CommandsGrid.getRowId(i),0).getValue()));

	if (Commands.length>0)
	configList[cpos].cmds=Commands.join("','");
	else
	configList[cpos].cmds="";
}

function FillInCommand(pos)
{
	position="configwizard.js";
	whatfunc="FillInCommand()";

	ToggleCommandsControlGadgets();

	if (pos != -1)
	{
	document.getElementById("cmd1").value=Commands[pos];
	document.getElementById("cmd1").disabled=false;
	document.getElementById("cmd1Show").style.display='block';
	document.getElementById("cmd1Hide").style.display='none';
	ToggleUSSFs(false);
	}
	else
	{
	document.getElementById("cmd1").value="";
	document.getElementById("cmd1").disabled=true;
	document.getElementById("cmd1Show").style.display='none';
	document.getElementById("cmd1Hide").style.display='block';
	ToggleUSSFs(true);
	}
}

function CopyConfig(pos)
{
	position="configwizard.js";
	whatfunc="CopyConfig()";

	configList[pos].prog=document.getElementById("prog").value;
	configList[pos].shortdesc=document.getElementById("shortdesc").value;
	configList[pos].uid=document.getElementById("uid").value;
	configList[pos].desc=DescriptionEditor.getContent();
	configList[pos].ordr=document.getElementById("ordr").value;
	configList[pos].dflt=document.getElementById("dflt").checked ? "yes" : "no";
	configList[pos].forc=document.getElementById("forc").checked ? "yes" : "no";
	configList[pos].cat=document.getElementById("cbocats").value;
	if (configList[pos].cat=="other")
	configList[pos].cat=document.getElementById("cat").value;
	configList[pos].configs=document.getElementById("configs").value;
	configList[pos].rebootcode=document.getElementById("RebootCode").value;
	configList[pos].repeatcommand=document.getElementById("RepeatCommand").checked ? "yes" : "no";
	configList[pos].pfro=document.getElementById("CheckPFRO").checked ? "yes" : "no";

	ExtractCommandsValues();
	configList[pos].cmds=Commands.join("','");
	configList[pos].deps=document.getElementById("deps").value;
	configList[pos].excl=document.getElementById("excl").value;
	configList[pos].cond=document.getElementById("cond").value;
	configList[pos].gcond=document.getElementById("gcond").value;
	configList[pos].picf=document.getElementById("picf").value;
	configList[pos].picw=document.getElementById("picw").value;
	configList[pos].pich=document.getElementById("pich").value;
	configList[pos].textl=document.getElementById("textl").value;
}

function clearProgram(entry)
{
	position="configwizard.js";
	whatfunc="clearProgram()";

	entry.prog="";
	entry.shortdesc="";
	entry.uid="";
	entry.desc="";
	entry.ordr="";
	entry.dflt="yes";
	entry.forc="no";
	entry.cat="Applications";
	entry.configs="";
	entry.rebootcode="";
	entry.repeatcommand="no";
	entry.pfro="no";
	entry.cmds="";
	entry.deps="";
	entry.excl="";
	entry.cond="";
	entry.gcond="";
	entry.picf="";
	entry.picw="";
	entry.pich="";
	entry.textl="";
}

function ToggleAllGadgets(state)
{
	position="configwizard.js";
	whatfunc="ToggleAllGadgets()";
	document.getElementById("prog").disabled=false;
	document.getElementById("shortdesc").disabled=state;
	document.getElementById("uid").disabled=state;
	document.getElementById("ordr").disabled=state;
	document.getElementById("dflt").disabled=state;
	document.getElementById("forc").disabled=state;
	document.getElementById("cbocats").disabled=state;
	document.getElementById("cat").disabled=state;
	document.getElementById("cat").style.visibility='hidden';
	document.getElementById("SelectConfigs").disabled=state;
	document.getElementById("configs").disabled=state;
	document.getElementById("RebootCode").disabled=state;
	document.getElementById("RepeatCommand").disabled=state;
	document.getElementById("CheckPFRO").disabled=state;
	document.getElementById("deps").disabled=state;
	document.getElementById("excl").disabled=state;
	document.getElementById("cond").disabled=state;
	document.getElementById("gcond").disabled=state;
	document.getElementById("picf").disabled=state;
	ToggleGenUID(state);
	ToggleCmdGadgets();
	ToggleComboBox(state);
	TogglePictureGadgets();
	TogglePictureFileRequesters(state);
	ToggleDefaultImages(state);
}


function ToggleCmdGadgets()
{
	position="configwizard.js";
	whatfunc="ToggleCmdGadgets()";

	if (configList[cpos].cmds.length<1)
	{
	document.getElementById("cmd1").disabled=true;
	ToggleCmdFileRequesters(true);
	ToggleUSSFs(true);
	}
	else
	{
	document.getElementById("cmd1").disabled=false;
	ToggleCmdFileRequesters(false);
	ToggleUSSFs(false);
	}
}

function TogglePictureGadgets()
{
	position="configwizard.js";
	whatfunc="TogglePictureGadgets()";

	document.getElementById("picw").disabled=(document.getElementById("picf").disabled || document.getElementById("picf").value=="" ? 1 : 0);
	document.getElementById("pich").disabled=(document.getElementById("picf").disabled || document.getElementById("picf").value=="" ? 1 : 0);
	document.getElementById("textl").disabled=(document.getElementById("picf").disabled || document.getElementById("picf").value=="" ? 1 : 0);

	if (document.getElementById("picf").value=="")
	{
	configList[cpos].picw="";
	configList[cpos].pich="";
	configList[cpos].textl=null;

	document.getElementById("picw").value="";
	document.getElementById("pich").value="";
	document.getElementById("textl").value=null;
	}
	else
	{
	document.getElementById("picw").value=configList[cpos].picw;
	document.getElementById("pich").value=configList[cpos].pich;
	document.getElementById("textl").value=configList[cpos].textl;
	}

	SetPicturePreview();
}

function ToggleGenUID(state)
{
	position="configwizard.js";
	whatfunc="ToggleGenUID()";

	if (state)
	{
	document.getElementById("GenUIDShow").style.display='none';
	document.getElementById("GenUIDHide").style.display='block';
	}
	else
	{
	document.getElementById("GenUIDShow").style.display='block';
	document.getElementById("GenUIDHide").style.display='none';
	}
}

function ToggleComboBox(state)
{
	position="configwizard.js";
	whatfunc="ToggleComboBox()";

	document.getElementById("cbocats").disabled=state;
	document.getElementById("cboDeps").disabled=state;
	document.getElementById("cboExcl").disabled=state;
}

function ToggleCmdFileRequesters(state)
{
	position="configwizard.js";
	whatfunc="ToggleCmdFileRequesters()";

	if (state)
	{
	document.getElementById("cmd1Show").style.display='none';
	document.getElementById("cmd1Hide").style.display='block';
	}
	else
	{
	document.getElementById("cmd1Show").style.display='block';
	document.getElementById("cmd1Hide").style.display='none';
	}
}

function TogglePictureFileRequesters(state)
{
	position="configwizard.js";
	whatfunc="TogglePictureFileRequesters()";

	if (state)
	{
	document.getElementById("picfShow").style.display='none';
	document.getElementById("picfHide").style.display='block';
	}
	else
	{
	document.getElementById("picfShow").style.display='block';
	document.getElementById("picfHide").style.display='none';
	}
}

function ToggleUSSFs(state)
{
	position="configwizard.js";
	whatfunc="ToggleUSSFs()";

	if (state)
	{
	document.getElementById("USSF1Show").style.display='none';
	document.getElementById("USSF1Hide").style.display='block';
	}
	else
	{
	document.getElementById("USSF1Show").style.display='block';
	document.getElementById("USSF1Hide").style.display='none';
	}
}

function ToggleDefaultImages(state)
{
	position="configwizard.js";
	whatfunc="ToggleDefaultImages()";

	if (state)
	{
	document.getElementById("DefaultImageShow").style.display='none';
	document.getElementById("DefaultImageHide").style.display='block';
	}
	else
	{
	document.getElementById("DefaultImageShow").style.display='block';
	document.getElementById("DefaultImageHide").style.display='none';
	}
}

function ToggleCommandsControlGadgets()
{
	position="configwizard.js";
	whatfunc="ToggleCommandsControlGadgets()";

	var state=false;

	if (CommandsGrid.getRowsNum()<2)
	state=true;

	document.getElementById("Btn_Commands_Delete").disabled=CommandsGrid.getRowsNum()==0 ? true : false;
}

function FillInConfigFile()
{
	position="configwizard.js";
	whatfunc="FillInConfigFile()";

	StatusBar.setText(configFile);
	FillInPathBox(configFile);
}

function PopulateFilter()
{
	position="configwizard.js";
	whatfunc="PopulateFilter()";

	var cats=GetCats();

	for (var i=document.getElementById("cboFilter").options.length-1; i>=1; i--)
	document.getElementById("cboFilter").remove(i);

	for (var i=0; i<cats.length; i++)
	{
	var opt=document.createElement("option");
	opt.value=cats[i];
	opt.text=cats[i];
	document.getElementById("cboFilter").options.add(opt);
	}
}

function HandleFilterSelection()
{
	position="configwizard.js";
	whatfunc="HandleFilterSelection()";

	CatFilter=document.getElementById("cboFilter").value;

	SortingState=NavGrid.getSortingState();
	PopulateGrid();
	cpos=NavGrid.getRowId(0);
	NavGrid.selectRowById(cpos,false,true);
	FillInConfig(cpos);
}

function JumpToEntry(pos)
{
	position="configwizard.js";
	whatfunc="JumpToEntry()";

	CopyConfig(cpos);
	cpos=pos;
	FillInConfig(cpos);
}

function FirstEntry()
{
	position="configwizard.js";
	whatfunc="FirstEntry()";

	CopyConfig(cpos);
	cpos=0;
	NavGrid.selectRowById(cpos,false,true);
	FillInConfig(cpos);
}

function LastEntry()
{
	position="configwizard.js";
	whatfunc="LastEntry()";

	CopyConfig(cpos);
	cpos=configList.length-1;
	NavGrid.selectRowById(cpos,false,true);
	FillInConfig(cpos);
}

function AddEntry()
{
	position="configwizard.js";
	whatfunc="AddEntry()";

	if (CatFilter != "all")
	{
	CopyConfig(cpos);
	document.getElementById("cboFilter").value="all";
	HandleFilterSelection();
	}

	configTabs.setTabActive('Tab2',false);

	if (configList.length>0)
	CopyConfig(cpos);
	cpos=configList.length-1;
	cpos++;
	configList[cpos]=new program(cpos);
	clearProgram(configList[cpos]);
	configList[cpos].prog=getText(txtNew).toString();
	configList[cpos].uid=getText(txtNew).toString().toUpperCase();
	FillInConfig(cpos);

	NavGrid.addRow(cpos,[configList[cpos].ordr,ConvertSpecialCharactersToEntities(configList[cpos].cat),configList[cpos].uid,ConvertSpecialCharactersToEntities(configList[cpos].prog)]);
	ToggleAllGadgets(true);

	NavGrid.selectRowById(cpos,false,true);
	ConfigUpdated();

	selectText(this.document.all.prog,getText(txtNew));
}

function CloneEntry()
{
	position="configwizard.js";
	whatfunc="CloneEntry()";

	var temp=cpos;

	configTabs.setTabActive('Tab2',false);

	CopyConfig(cpos);
	cpos=configList.length-1;
	cpos++;
	configList[cpos]=new program(pn);
	clearProgram(configList[cpos]);
	CopyConfig(cpos);
	configList[cpos].prog += "-2";
	configList[cpos].ordr="";
	configList[cpos].uid += "-2";
	FillInConfig(cpos);

	NavGrid.addRow(cpos,[configList[cpos].ordr,ConvertSpecialCharactersToEntities(configList[cpos].cat),configList[cpos].uid,ConvertSpecialCharactersToEntities(configList[cpos].prog)]);
	ToggleAllGadgets(false);

	NavGrid.selectRowById(cpos,false,true);
	document.getElementById("prog").focus();

	ConfigUpdated();
}

function DeleteEntry()
{
	position="configwizard.js";
	whatfunc="DeleteEntry()";

	if (!Alert("",getText(txtDeleteConfirm) +" '"+ configList[cpos].prog + "'?",getText(lblOK)+"|"+getText(lblCancel),"",5,0,0,0))
	return;
	 var catname = configList[cpos].cat; 
        configList.splice(cpos,1); 
        var catcount = 0; 
        for (var i=0; i<configList.length && configList[i] != null; i++) 
                if (catname == configList[i].cat) 
                        catcount++; 
                         
        if (!catcount) 
        { 
                for (var i=document.getElementById("cboFilter").options.length-1; i>=1; i--) 
                        if (document.getElementById("cboFilter").options[i].text == catname) 
                                document.getElementById("cboFilter").remove(i); 
                 
                if (CatFilter == catname) 
                { 
                        CatFilter = "all"; 
                        document.getElementById("cboFilter").value = CatFilter; 
                } 
        }
        
	SortingState=NavGrid.getSortingState();
	PopulateGrid();
	cpos=NavGrid.getRowId(0);
	NavGrid.selectRowById(cpos,false,true);

	if (configList.length==0)
	AddEntry();
	else
	FillInConfig(cpos);

	ConfigUpdated();
}

function ExtractConfigurations()
{
	position="configwizard.js";
	whatfunc="ExtractConfigurations()";

	var i;

	i=Configurations.length;
	Configurations.splice(0,i);

	for (i=3; i<ConfigurationsGrid.getRowsNum(); i++)
	Configurations.splice(Configurations.length,0,ConfigurationsGrid.cells(ConfigurationsGrid.getRowId(i),1).getValue());
}

function GetCheckOnLoad()
{
	position="configwizard.js";
	whatfunc="GetCheckOnLoad()";

	var txt;

	for (var i=0; i<ConfigurationsGrid.getRowsNum(); i++)
	{
	if (ConfigurationsGrid.cells(ConfigurationsGrid.getRowId(i),0).getValue()==true)
	{
	txt=ConfigurationsGrid.cells(ConfigurationsGrid.getRowId(i),1).getValue();

	txt=txt.replace(/<i>/gi,"").replace(/<\/i>/gi,"");
	if (txt==getText(optDefault))
	txt="default";
	if (txt==getText(optAll))
	txt="all";
	if (txt==getText(optNone))
	txt="none";

	return txt;
	}
	}

	return "";
}

function ClickAddConfiguration()
{
	position="configwizard.js";
	whatfunc="ClickAddConfiguration()";

	document.getElementById("NewConfiguration").disabled=false;
	document.getElementById("NewConfiguration").value=getText(txtNew);

	selectText(this.document.all.NewConfiguration,getText(txtNew));
}

function AddConfiguration()
{
	position="configwizard.js";
	whatfunc="AddConfiguration()";

	ConfigurationsGrid.addRow(ConfigurationsGrid.getRowsNum(),[0,ConvertSpecialCharactersToEntities(document.getElementById("NewConfiguration").value)]);

	ExtractConfigurations();
	InsertConfigsValues();

	document.getElementById("NewConfiguration").value="";
	document.getElementById("NewConfiguration").disabled=true;

	ConfigUpdated();
}

function DeleteConfiguration()
{
	position="configwizard.js";
	whatfunc="DeleteConfiguration()";

	var txt;

	if (!ConfigurationsGrid.getSelectedRowId())
	return;

	txt=ConfigurationsGrid.cells(ConfigurationsGrid.getSelectedRowId(),1).getValue();
	txt=txt.replace(/<i>/gi,"").replace(/<\/i>/gi,"");
	if (txt==getText(optDefault) || txt==getText(optAll) || txt==getText(optNone))
	{
	Alert("",getText(txtCantDeleteItem),getText(lblOK),"",3,-1,0,0);

	return;
	}

	if (ConfigurationsGrid.cells(ConfigurationsGrid.getSelectedRowId(),0).getValue()==true)
	ConfigurationsGrid.cells(0,0).setValue(true);

	ConfigurationsGrid.deleteRow(ConfigurationsGrid.getSelectedRowId());

	ExtractConfigurations();
	InsertConfigsValues();

	ConfigUpdated();
}

function PopulateSortOrderGrid()
{
	position="configwizard.js";
	whatfunc="PopulateSortOrderGrid()";

	SortOrderGrid.clearAll();
	var cats=GetCats();

	if (cats.length<1)
	return;

	for (var i=0; i<cats.length; i++)
	SortOrderGrid.addRow(i,ConvertSpecialCharactersToEntities(cats[i]));
}

function LocalizeSortOrder()
{
	position="configwizard.js";
	whatfunc="LocalizeSortOrder()";

	var tab=SortOrder.split(",");

	for (var i=0; i<tab.length; i++)
	tab[i]=GetCategoryTranslation(tab[i]);

	document.getElementById("SortOrder").value=tab.toString();
}

function UpdateSortOrder()
{
	position="configwizard.js";
	whatfunc="UpdateSortOrder()";

	var sort=String(SortOrder).split(",");
	var sorttmp='';

	for (i=0; i<sort.length; i++)
	{
	var found=false;
	var j=1;
	while (prog[j] !=null) // Parse Config list search category
	{
	if (cat[j]==sort[i])
	{
	sorttmp +=(sorttmp != '') ? ',' + sort[i] : sort[i];
	break;
	}
	j++;
	}
	}
	SortOrder=sorttmp;
}

function ExtractSortOrderValues()
{
	position="configwizard.js";
	whatfunc="ExtractSortOrderValues()";

	CatSortOrder.splice(0,CatSortOrder.length);

	for (i=0; i<SortOrderGrid.getRowsNum(); i++)
	CatSortOrder.splice(CatSortOrder.length,0,SortOrderGrid.cells(SortOrderGrid.getRowId(i),0).getValue());

	if (CatSortOrder.length>0)
	SortOrder=CatSortOrder.join(",");
	else
	SortOrder=new String();
}

function HandleNameChange()
{
	position="configwizard.js";
	whatfunc="HandleNameChange()";

	var NewUpper=getText(txtNew).toString().toUpperCase();

	if (document.getElementById("prog").value=="")
	{
	ItemDefaults();
	document.getElementById("prog").value=getText(txtNew);
	}

	CopyConfig(cpos);
	if (document.getElementById("uid").value=="" || document.getElementById("uid").value==NewUpper)
	{
	var uid=document.getElementById("prog").value.replace(/\W/g,"").toUpperCase().substr(0,25);
	uid=HandleSpecialCharacters(uid,false);
	NavGrid.cells(cpos,2).setValue(uid);
	document.getElementById("uid").value=uid;

	DescriptionEditor.setContent(document.getElementById("prog").value);
	ToggleAllGadgets(false);
	}
	else
	{
	GenUID(0);
	}

	NavGrid.cells(cpos,3).setValue(ConvertSpecialCharactersToEntities(configList[cpos].prog));

}

function HandleInstallOrder()
{
	position="configwizard.js";
	whatfunc="HandleInstallOrder()";

	CopyConfig(cpos);
	NavGrid.cells(cpos,0).setValue(configList[cpos].ordr);
}

function HandleUIDChange()
{
	position="configwizard.js";
	whatfunc="HandleUIDChange()";

	var uid=document.getElementById("uid").value.replace(/\W/g,"").toUpperCase().substr(0,25);
	uid=HandleSpecialCharacters(uid,false);

	NavGrid.cells(cpos,2).setValue(uid);
	document.getElementById("uid").value=uid;

	if (configList[cpos].uid != uid)
	{
	if (Alert("",getText(lblChangeAllOccurances),getText(lblOK)+"|"+getText(lblCancel),"",5,0,0,0))
	{
	for (var i=0; i<configList.length; i++)
	{
	var x, splits=[];

	splits=configList[i].deps.split(",");
	for (x=0; x<splits.length; x++)
	{
		if (configList[cpos].uid==splits[x])
	splits[x]=uid;
	}
	configList[i].deps=splits.join(",");

	splits=configList[i].excl.split(",");
	for (x=0; x<splits.length; x++)
	{
		if (configList[cpos].uid==splits[x])
	splits[x]=uid;
	}
	configList[i].excl=splits.join(",");
	}
	}
	}

	CopyConfig(cpos);
	FillUID();
}

function GenUID(mode)
{
	position="configwizard.js";
	whatfunc="GenUID()";

	var uid;

	uid=document.getElementById("prog").value;
	uid=uid.replace(/\W/g,"").toUpperCase().substr(0,25);
	uid=HandleSpecialCharacters(uid,false);

	if (mode==0)
	{
	if (document.getElementById("uid").value != "" || document.getElementById("uid").value != null)
	return;
	}
	document.getElementById("uid").value=uid;

	if (mode==0)
	HandleUIDChange();
	else
	{
	var uid=document.getElementById("uid").value.replace(/\W/g,"").toUpperCase().substr(0,25);
	uid=HandleSpecialCharacters(uid,false);

	NavGrid.cells(cpos,2).setValue(uid);
	document.getElementById("uid").value=uid;

	HandleUIDChange();

	CopyConfig(cpos);
	}

	FillUID();
	FindEntry();
	ToggleAllGadgets(false);
	document.getElementById("uid").focus();
}

function FillUID()
{
	position="configwizard.js";
	whatfunc="FillUID()";

	document.getElementById("cboDeps").innerHTML="";
	document.getElementById("cboExcl").innerHTML="";

	var opt=document.createElement("option");
	opt.value="blank";
	opt.text="";
	document.getElementById("cboDeps").options.add(opt);

	var opt=document.createElement("option");
	opt.value="blank";
	opt.text="";
	document.getElementById("cboExcl").options.add(opt);

	for (var i=0; i<configList.length && configList[i] != null; i++)
	{
	if (configList[i].uid != "")
	{
	var opt=document.createElement("option");
	opt.value=configList[i].uid;
	opt.text=configList[i].prog;
	document.getElementById("cboDeps").options.add(opt);

	var opt=document.createElement("option");
	opt.value=configList[i].uid;
	opt.text=configList[i].prog;
	document.getElementById("cboExcl").options.add(opt);
	}
	}
}

function HandleRebootCode()
{
	position="configwizard.js";
	whatfunc="HandleRebootCode()";

	var value=document.getElementById("RebootCode").value;

	if (value=="0" || value=="1")
	{
	Alert("",getText(txtValueCanNotBe0Or1),getText(lblOK),"",3,-1,0,0);
	document.getElementById("RebootCode").value="";

	return;
	}

	if (value != "")
	{
	document.getElementById("RepeatCommand").disabled=false;
	}
	else
	{
	document.getElementById("RepeatCommand").checked=false;
	document.getElementById("RepeatCommand").disabled=true;
	}
}

function CommandAdd()
{
	position="configwizard.js";
	whatfunc="CommandAdd()";

	CommandsGrid.addRow(CommandsGrid.getRowsNum(),getText(txtNew));
	ExtractCommandsValues();
	CommandsGrid.selectRow(CommandsGrid.getRowsNum()-1,false,false,true);
	FillInCommand(CommandsGrid.getRowsNum()-1);
	document.getElementById("cmd1").focus();

	selectText(this.document.all.cmd1,getText(txtNew));

	ConfigUpdated();
}

function CommandDelete()
{
	position="configwizard.js";
	whatfunc="CommandDelete()";

	if (!Alert("",getText(txtDeleteCommandConfirm),getText(lblOK)+"|"+getText(lblCancel),"",5,0,0,0))
	return;
	CommandsGrid.deleteRow(CommandsGrid.getSelectedRowId());
	ExtractCommandsValues();
	Commands.splice(CommandsGrid.getRowIndex(CommandsGrid.getSelectedRowId()),1);
	PopulateCommandsGrid();
	ConfigUpdated();
}

function HandleCommandsSelectionMenu(val)
{
	position="configwizard.js";
	whatfunc="HandleCommandsSelectionMenu()";
	if (document.getElementById("cmd1").disabled) 
                Alert("",getText(txtMustAddCommand),"",3,-1,0,0);

	var txt="";

	txt=document.getElementById("cmd1").value;

	if (txt==getText(txtNew))
	txt="";

	if (val.substr(0,1)=="{")	// Picked a new DOS command
	txt="";

	if (txt=="")
	{
	txt=val;
	document.getElementById("cmd1").value=txt;
	}
	else
	{
	txt += " ";
	txt += val;
	document.getElementById("cmd1").value=txt;
	}

	moveCaretToEnd(this.document.all.cmd1);
}

function HandleCommandChange()
{
	position="configwizard.js";
	whatfunc="HandleCommandChange()";

	CommandsGrid.cells(CommandsGrid.getSelectedRowId(),0).setValue(ConvertSpecialCharactersToEntities(document.getElementById("cmd1").value));

	CopyConfig(cpos);

	ConfigUpdated();
}

function clearcmd1Browse()
{
	position="configwizard.js";
	whatfunc="clearcmd1Browse()";

	document.getElementById("div_cmd1Browse").innerHTML="";
	document.getElementById("div_cmd1Browse").innerHTML='<input id="cmd1Browse" type="file" style="display:none;">';
}

function SetCmd1Path()
{
	position="configwizard.js";
	whatfunc="SetCmd1Path()";

	if (document.getElementById("cmd1Browse").value != "")
	{
	tempName=document.getElementById("cmd1Browse").value;
	if (theStart=tempName.indexOf(":") != -1)
	tempName=trimString(tempName);
	if (tempName.substring(0,2)=="\\\\")
	{
	theStart=-1;
	tempName=trimString(tempName);
	}

	if (document.getElementById("cmd1").value=="" || document.getElementById("cmd1").value==getText(txtNew))
	document.getElementById("cmd1").value=tempName;
	else
	{
	if (document.getElementById("cmd1").value.substr(0,9)=="{INSTINF}" || document.getElementById("cmd1").value.substr(0,9)=="{LAUNCHINF}")
	tempName=tempName.replace(/\"/gi,"");

	document.getElementById("cmd1").value += tempName;
	}

	ConfigUpdated();

	moveCaretToEnd(this.document.all.cmd1);
	}
}

function HandleDependentOf()
{
	position="configwizard.js";
	whatfunc="HandleDependentOf()";

	var n=document.getElementById("cboDeps").selectedIndex;
	var val=document.getElementById("cboDeps")[n].value;
	var txt="";

	if (document.getElementById("cboDeps").value != "blank")
	{
	if (document.getElementById("cboDeps").value==configList[cpos].uid)
	{
	Alert("",getText(txtThatIsThisItem),getText(lblOK),"",3,-1,0,0);
	}
	else
	{
	txt=document.getElementById("deps").value;
	if (txt=="" && txt.indexOf(val)==-1)
	{
	txt += document.getElementById("cboDeps").value;
	document.getElementById("deps").focus();
	document.getElementById("deps").value=txt;
	}
	else if (txt != "" && txt.indexOf(val)==-1)
	{
	txt += ",";
	txt += document.getElementById("cboDeps").value;
	document.getElementById("deps").focus();
	document.getElementById("deps").value=txt;
	}
	}
	}

	document.getElementById("cboDeps").value="blank";
}

function HandleExcludes()
{
	position="configwizard.js";
	whatfunc="HandleExcludes()";

	var n=document.getElementById("cboExcl").selectedIndex;
	var val=document.getElementById("cboExcl")[n].value;
	var txt="";

	if (document.getElementById("cboExcl").value != "blank")
	{
	if (document.getElementById("cboExcl").value==configList[cpos].uid)
	{
	Alert("",getText(txtThatIsThisItem),getText(lblOK),"",3,-1,0,0);
	}
	else
	{
	txt=document.getElementById("excl").value;
	if (txt=="" && txt.indexOf(val)==-1)
	{
	txt += document.getElementById("cboExcl").value;
	document.getElementById("excl").focus();
	document.getElementById("excl").value=txt;
	}
	else if (txt != "" && txt.indexOf(val)==-1)
	{
	txt += ",";
	txt += document.getElementById("cboExcl").value;
	document.getElementById("excl").focus();
	document.getElementById("excl").value=txt;
	}
	}
	}

	document.getElementById("cboExcl").value="blank";
}

function HandleConditionsSelectionMenu(val) 
{ 
        position="configwizard.js"; 
        whatfunc="HandleConditionsSelectionMenu()"; 
 
        insertAtCaret(document.getElementById(WhichCond), val); 
 
        ConfigUpdated(); 
}

function HandleInsertCondValues()
{
	position="configwizard.js";
	whatfunc="HandleInsertCondValues()";

	InsertCondValues=document.getElementById("InsertCondValues").checked;
}

function trimString(str)
{
	position="configwizard.js";
	whatfunc="trimString()";

	var trimpath;
	var trimpathvar;
	if (DefaultInstallPath=="default")
	{
	if ((WPIPathPosition=str.toLowerCase().indexOf(wpipath.toLowerCase())) != -1) 
                { 
                        trimpath=str.substring(WPIPathPosition,wpipath.length); 
                        trimpathvar="%wpipath%";    //Could have used %cdrom% 
                }

	else if (str.indexOf(sysdir) != -1)
	{
	trimpath=sysdir;
	trimpathvar="%sysdir%";
	}
		
	else if (str.indexOf(windir) != -1)
	{
	trimpath=windir;
	trimpathvar="%windir%";
	}
	else if (str.indexOf(programfiles) != -1)
	{
	trimpath=programfiles;
	trimpathvar="%programfiles%";
	}
	else if (str.indexOf(allusersprofile) != -1)
	{
	trimpath=allusersprofile;
	trimpathvar="%allusersprofile%";
	}
	else if (str.indexOf(userprofile) != -1)
	{
	trimpath=userprofile;
	trimpathvar="%userprofile%";
	}
	else if (str.indexOf(userprofileroot) != -1)
	{
	trimpath=userprofileroot;
	trimpathvar="%userprofileroot%";
	}
	else if (str.indexOf(appdata) != -1)
	{
	trimpath=appdata;
	trimpathvar="%appdata%";
	}
	else if (str.indexOf(commonprogramfiles) != -1)
	{
	trimpath=commonprogramfiles;
	trimpathvar="%commonprogramfiles%";
	}
	else if (str.indexOf(temp) != -1)
	{
	trimpath=temp;
	trimpathvar="%temp%";
	}
	else if (str.indexOf(root) != -1)
	{
	trimpath=root;
	trimpathvar="%root%";
	}
	else if (str.indexOf(sysdrv) != -1)
	{
	trimpath=sysdrv;
	trimpathvar="%sysdrv%";
	}
	else if (str.indexOf("\\\\")==0)
	{
	trimpath="";
	trimpathvar="";
	}
	else
	{
	trimpath=wpipath;
	trimpathvar="%wpipath%";    //Default from before...Could have used %cdrom%
	}
	}
	else if (DefaultInstallPath=="%wpipath%")
	{
	trimpath=wpipath;
	trimpathvar="%wpipath%";
	}
	else if (DefaultInstallPath=="%cdrom%")
	{
	trimpath=wpipath;
	trimpathvar="%cdrom%";
	}
	else if (DefaultInstallPath=="%root%")
	{
	trimpath=wpipath;
	trimpathvar="%root%";
	}
	else if (DefaultInstallPath=="custom")
	{
	trimpath=str.substring(0,str.lastIndexOf("\\"));
	trimpathvar=CustomInstallPath;
	}
	else
	{
	trimpath='';
	trimpathvar='';
	}

	str=str.replace(trimpath, ''); //remove the trimpath
	if (theStart != -1)
	str='"' + trimpathvar + str.substring(theStart-1,str.length)+'"';
	else
	str='"' + str.substring(theStart-1,str.length)+'"';

	return str;
}

function clearpicfBrowse()
{
	position="configwizard.js";
	whatfunc="clearpicfBrowse()";

	document.getElementById("div_picfBrowse").innerHTML="";
	document.getElementById("div_picfBrowse").innerHTML='<input id="picfBrowse" type="file" style="display:none;">';
}

function GetPictureName()
{
	position="configwizard.js";
	whatfunc="GetPictureName()";

	BrowseName=trimString(document.getElementById("picfBrowse").value);
}

function SetPicturePath(mode)
{
	position="configwizard.js";
	whatfunc="SetPicturePath()";

	if (mode==1 || document.getElementById("picfBrowse").value != "")
	{
	if (mode==1)
	{
	BrowseName=document.getElementById("picf").value;
	}
	else
	{
	GetPictureName();
	document.getElementById("picf").value=BrowseName;
	}

	var newImage=new Image();

	if (BrowseName.indexOf("\\")==-1)
	{
	newImage.name="../Graphics/"+BrowseName;
	newImage.src="../Graphics/"+BrowseName;
	}
	else
	{
	var txt=ReplacePath(BrowseName).replace(/\"/g,'').replace(/\//g,"\\");
	txt=txt.replace(/\"/g,'').replace(/\//g,"\\");
	newImage.name=txt;
	newImage.src=txt;
	}

	configList[cpos].picw=newImage.width;
	configList[cpos].pich=newImage.height;
	configList[cpos].textl="Right";

	document.getElementById("picw").value=newImage.width;
	document.getElementById("pich").value=newImage.height;
	document.getElementById("textl").value="Right";
	document.getElementById("PicturePreview").style.backgroundRepeat="no-repeat";
	document.getElementById("PicturePreview").style.backgroundPosition="center center";
	if (BrowseName.indexOf("\\")==-1)
	document.getElementById("PicturePreview").style.backgroundImage="url('../Graphics/"+BrowseName+"')";
	else
	document.getElementById("PicturePreview").style.backgroundImage="url("+ReplacePath(BrowseName)+")";

	ConfigUpdated();
	}
}

function SetPicturePreview()
{
	position="configwizard.js";
	whatfunc="SetPicturePreview()";

	var bImage=new Image();
	var txt;

	document.getElementById("PicturePreview").style.backgroundRepeat="no-repeat";
	document.getElementById("PicturePreview").style.backgroundPosition="center center";

	if (document.getElementById("picf").value != "")
	{
	if (document.getElementById("picf").value.indexOf("\\")==-1)
	txt="../Graphics/"+document.getElementById("picf").value;
	else
	txt=ReplacePath(document.getElementById("picf").value).replace(/\"/g,'');
	bImage.name=txt;
	bImage.src=txt;
	document.getElementById("PicturePreview").style.backgroundImage="url('"+txt+"')";
	document.getElementById("picw").value=document.getElementById("picw").value;
	document.getElementById("pich").value=document.getElementById("pich").value;
	}
	else
	{
	document.getElementById("PicturePreview").style.backgroundImage="";
	document.getElementById("picw").value="";
	document.getElementById("pich").value="";
	}
}

function HandleDefaultImage()
{
	position="configwizard.js";
	whatfunc="HandleDefaultImage()";

	configList[cpos].picf="InstallPackage.png";
	configList[cpos].picw=128;
	configList[cpos].pich=128;
	configList[cpos].textl="Right";

	document.getElementById("picf").value=configList[cpos].picf;
	document.getElementById("picw").value=configList[cpos].picw;
	document.getElementById("pich").value=configList[cpos].pich;
	document.getElementById("textl").value=configList[cpos].textl;
	document.getElementById("PicturePreview").style.backgroundRepeat="no-repeat";
	document.getElementById("PicturePreview").style.backgroundPosition="center center";
	document.getElementById("PicturePreview").style.backgroundImage="url('../Graphics/InstallPackage.png')";

	TogglePictureGadgets();
}

function FindEntry()
{
	position="configwizard.js";
	whatfunc="FindEntry()";

	for (var i=0; i<configList.length && configList[i] != null; i++)
	{
	if (configList[i].uid==document.getElementById("uid").value)
	{
	cpos=i;
	FillInConfig(cpos);
	break;
	}
	}
}

function HandleCatSelection()
{
	position="configwizard.js";
	whatfunc="HandleCatSelection()";

	if (document.getElementById("cbocats").value=="other")
	{
	document.getElementById("cat").style.visibility="visible";
	document.getElementById("cat").value=getText(txtNew);
	selectText(this.document.all.cat,getText(txtNew));
	}
	else
	{
	document.getElementById("cat").style.visibility="hidden";
	if (CatFilter != "all")
	{
	CopyConfig(cpos);
	PopulateFilter();
	document.getElementById("cboFilter").value=document.getElementById("cbocats").value;
	HandleFilterSelection();
	}
	}

	CopyConfig(cpos);
	NavGrid.cells(cpos,1).setValue(ConvertSpecialCharactersToEntities(configList[cpos].cat));
}

function HandleNewCat()
{
	position="configwizard.js";
	whatfunc="HandleNewCat()";

	var opt=document.createElement("option");
	opt.value=document.getElementById("cat").value;
	opt.text=noTags(opt.value);
	document.getElementById("cboFilter").options.add(opt);
	Pause(0,50);

	var opt=document.createElement("option");
	opt.value=document.getElementById("cat").value;
	opt.text=noTags(opt.value);
	document.getElementById("cbocats").options.add(opt);
	Pause(0,50);
	document.getElementById("cbocats").selectedIndex=document.getElementById("cbocats").length-1;

	if (CatFilter != "all")
	{
	document.getElementById("cboFilter").value=document.getElementById("cat").value;
	CopyConfig(cpos);
	HandleFilterSelection();
	}

	CopyConfig(cpos);
	NavGrid.cells(cpos,1).setValue(ConvertSpecialCharactersToEntities(configList[cpos].cat));

	document.getElementById("cat").style.visibility="hidden";

	SortOrderGrid.addRow(SortOrderGrid.getRowsNum(),ConvertSpecialCharactersToEntities(configList[cpos].cat));
}

function HandleConfigSelection()
{
	position="configwizard.js";
	whatfunc="HandleConfigSelection()";

	var txt="";

	if (document.getElementById("SelectConfigs").value != "blank")
	{
	txt=document.getElementById("configs").value;
	if (txt != "")
	txt += ",";
	txt += document.getElementById("SelectConfigs").value;
	document.getElementById("configs").value=txt;
	}

	document.getElementById("SelectConfigs").value="blank";
}

function DefaultCatsValues()
{
	position="configwizard.js";
	whatfunc="DefaultCatsValues()";

	for (var i=document.getElementById("cbocats").options.length-1; i>1; i--)
	{
	document.getElementById("cbocats").remove(i);
	}
}

function InsertCatsValues()
{
	position="configwizard.js";
	whatfunc="InsertCatsValues()";

	DefaultCatsValues();

	var cats=GetCats();

	for (var i=0; i<cats.length; i++)
	{
	if (cats[i] != "Applications" && cats[i])
	{
	var opt=document.createElement("option");

	opt.value=cats[i];
	opt.text=cats[i];
	document.getElementById("cbocats").options.add(opt);
	}
	}
}

function InsertConfigsValues()
{
	position="configwizard.js";
	whatfunc="InsertConfigsValues()";

	document.getElementById("SelectConfigs").options.length=1;

	for (var i=0; i<Configurations.length; i++)
	{
	var opt=document.createElement("option");

	opt.value=Configurations[i];
	opt.text=noTags(Configurations[i]);
	document.getElementById("SelectConfigs").options.add(opt);
	}
}

function GetConfigValue(inVal,isNum)
{
	position="configwizard.js";
	whatfunc="GetConfigValue()";

	var txt=new String();

	txt=inVal;
	txt=txt.replace(/\\/g,"\\\\");

	if (!isNum && txt != "")
	{
	txt=txt.replace(/'/g,"\\'");
	txt=("'" + txt + "'");
	}

	if (!isNum && txt=="")
	txt="''";

	return txt;
}

function WriteConfigValue(tf, fName, inVal, isNum)
{
	position="configwizard.js";
	whatfunc="WriteConfigValue()";

	if (inVal==null || inVal=="")
	return;

	var txt=new String();

	txt=(fName + "[pn]=[" + GetConfigValue(inVal, isNum) + "];");
	txt=txt.replace(/''/g,"'");
	tf.WriteLine(txt);
}

function ConfigDefaults()
{
	position="configwizard.js";
	whatfunc="ConfigDefaults()";

	configTabs.setTabActive('Tab2',false);

	pn=1;
	cpos=0;
	configList[0]=new program(pn);
	clearProgram(configList[0]);
	ToggleAllGadgets(true);
	configList[cpos].prog=getText(txtNew);
	configList[cpos].uid=getText(txtNew);
	FillInConfig(cpos);
	FirstEntry();
	document.getElementById("prog").focus();
}

function ItemDefaults()
{
	position="configwizard.js";
	whatfunc="ItemDefaults()";

	configTabs.setTabActive('Tab2',false);

	clearProgram(configList[cpos]);
	ToggleAllGadgets(false);
	configList[cpos].prog=getText(txtNew);
	configList[cpos].uid=getText(txtNew);
	FillInConfig(cpos);
	document.getElementById("prog").focus();
}

function NewConfig()
{
	position="configwizard.js";
	whatfunc="NewConfig()";

	var temp;

	if (!isConfigSaved)
	{
	if (!Alert("",getText(txtDiscardChangesContinue),getText(lblOK)+"|"+getText(lblCancel),"",5,0,0,0))
	return;
	}
	temp=Alert("",getText(txtSaveConfigAs),getText(lblOK)+"|"+getText(lblCancel),configFile,6,0,125,0);
	if (temp != null)
	{
	if (FileExists(temp))
	{
	if (!Alert("",temp+"\n\n"+getText(txtFileExistsReplace),getText(lblOK)+"|"+getText(lblCancel),"",5,0,0,0))
	return;
	}

	configFile=temp;
	SetConfigPath(true);
	configList=[];
	cpos=0;
	ClearAllArrays();
	NavGrid.clearAll();
	AddEntry();
	SaveConfig();
	ReadConfig();
	selectText(this.document.all.prog,getText(txtNew));
	}
}

function configClearReadBrowse()
{
	position="configwizard.js";
	whatfunc="configClearReadBrowse()";

	document.getElementById("div_configReadBrowse").innerHTML="";
	document.getElementById("div_configReadBrowse").innerHTML='<input id="configReadBrowse" type="file" style="display:none;">';
}

function HandleReadConfig()
{
	position="configwizard.js";
	whatfunc="HandleReadConfig()";

	if (!isConfigSaved)
	{
	if (!Alert("",getText(txtDiscardChangesContinue),getText(lblOK)+"|"+getText(lblCancel),"",5,0,0,0))
	return;
	}

	configClearReadBrowse();
	document.all.configReadBrowse.click();

	if (document.getElementById("configReadBrowse").value != "")
	{
	isConfigSaved=true;
	oldFile=configFile;
	SetConfigPath(false);
	FillInConfigFile();
	ReadConfig();
	ToggleAllGadgets(false);
	}
}

function SetConfigPath(mode)
{
	position="configwizard.js";
	whatfunc="SetConfigPath()";

	var i, txt;

	if (!mode)
	{
	configFile=document.getElementById("configReadBrowse").value;
	}
	else
	{
	}
}

function GetConfigPath()
{
	position="configwizard.js";
	whatfunc="GetConfigPath()";

	var temp;
	temp=Alert("",getText(txtSaveConfigAs),getText(lblOK)+"|"+getText(lblCancel),configFile,6,0,125,0);
	if (temp != null)
	{
	configFile=temp;
	SetConfigPath(true);
	SaveConfig();
	}
}

function ConfigurationDefaults(clear)
{
	position="configwizard.js";
	whatfunc="ConfigurationDefaults";

	if (clear)
	{
// General tab
	Configurations=[];
	ShowMultiDefault=true;
	SortOrder=new String();
	}

	if (document.getElementById("layerconfig").style.display=='block')
	{
	PopulateConfigurations();
	document.getElementById("ShowMultiDefault").checked=ShowMultiDefault;
	}
}

function GetConfigVersion()
{
	position="configwizard.js";
	whatfunc="GetConfigVersion()";

	var line=new String();
	var num=1, ver=-1;

	strFile=configFile;
	if (FileExists(strFile))
	{
	try
	{
	tf=fso.OpenTextFile(strFile,1,0,-2);
	while (!tf.AtEndOfStream && num<2)
	{
	line=tf.ReadLine();
	if (line.indexOf("// WPI Config ") != -1)
	{
		line=line.replace(/[^0-9]/g,'');
		ver=Number(line);
	}
	else
		ver=0;
	num++;
	}
	}
	catch(ex)
	{ ; }
	finally
	{
	try
	{
	tf.Close();
	}
	catch (ex0)
	{ ; }
	}
	}

	return ver;
}

function ReadConfig()
{
	position="configwizard.js";
	whatfunc="ReadConfig()";

	var line=new String();
	var opt=new String();
	var val=new String();
	var i, txt;
	var foundpn=false;

	WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\ConfigFile",configFile,"REG_SZ");

	val=GetConfigVersion();
	if (val>-1 && val<720)
	{
	if (Alert("",getText(txtUpdateConfig),getText(lblOK)+"|"+getText(lblCancel),"",5,0,0,0))
	{
	UpdateWizard1();
	RefreshWPI();
	}
	else
	{
	configFile=oldFile;
	FillInConfigFile();
	WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\ConfigFile",configFile,"REG_SZ");

	return;
	}
	}

	pn=1;
	strFile=configFile;
	if (FileExists(strFile))
	{
	configList=[];
	try
	{
	tf=fso.OpenTextFile(strFile,1,0,-2);
	while (!tf.AtEndOfStream)
	{
	line=tf.ReadLine();
	if (line.search("^ *$")==0)
		continue;  // empty line
	if (line.search("^ *//")==0)
		continue; // comments
	if (line.search("^ *pn")==0)
	{
		foundpn=true;
		continue; // pn++
	}
	line=line.replace(/^var /g,"");
	line=line.replace(/^ */g,"");

	if (!foundpn)
	{
		if (line.indexOf("Configurations=[") != -1)
		{
	try
	{
		eval(line);
		continue;
	}
	catch(ex2)
	{
		Configurations=[];
		continue;
	}
		}
		if (line.indexOf("ShowMultiDefault=") != -1)
		{
	try
	{
		eval(line);
		continue;
	}
	catch(ex2)
	{
		ShowMultiDefault=true;
		continue;
	}
		}
		if (line.indexOf("CheckOnLoad=") != -1)
		{
	try
	{
		eval(line);
		continue;
	}
	catch(ex2)
	{
		CheckOnLoad='default';
		continue;
	}
		}
		if (line.indexOf("SortOrder=[") != -1)
		{
	try
	{
		eval(line);
		continue;
	}
	catch(ex2)
	{
		SortOrder=new String();
		continue;
	}
		}
	}

	opt=line.substring(0,line.indexOf("["));
	val=line.substring(line.indexOf("=")+1, line.length);
	val=val.replace(/^ *\[ */,"").replace(/^ *' */,"");
	val=val.replace(/ *] *$/,"").replace(/ *' *$/,"");
	val=val.replace(/ *]; *$/,"").replace(/ *' *$/,"");
	val=val.replace(/\\\\/g,"\\");
	val=val.replace(/\\'/g,"'");
	switch (opt)
	{
		case "prog":
	configList[pn-1]=new program(pn);
	clearProgram(configList[pn-1]);
	configList[pn-1].prog=val;
	pn++;
	break;

		case "shortdesc":
	configList[pn-2].shortdesc=val;
	break;

		case "uid":
	configList[pn-2].uid=val;
	break;

		case "desc":
	configList[pn-2].desc=val;
	break;

		case "ordr":
	configList[pn-2].ordr=val;
	break;

		case "dflt":
	configList[pn-2].dflt=val;
	break;

		case "forc":
	configList[pn-2].forc=val;
	break;

		case "cat":
	configList[pn-2].cat=val;
	break;

		case "configs":
	configList[pn-2].configs=val;
	break;

		case "rebootcode":
	configList[pn-2].rebootcode=val;
	break;

		case "repeatcommand":
	configList[pn-2].repeatcommand=val;
	break;

		case "pfro":
	configList[pn-2].pfro=val;
	break;

		case "cmds":
	val=val.replace(/%comma%/g,",");
	val=val.replace(/&amp;/g,"&");
	configList[pn-2].cmds=val;
	break;

		case "deps":
	val=val.replace (/ *' *, *' */g,",");
	configList[pn-2].deps=val;
	break;

		case "excl":
	val=val.replace (/ *' *, *' */gi,",");
	configList[pn-2].excl=val;
	break;

		case "cond":
	configList[pn-2].cond=val;
	break;

		case "gcond":
	configList[pn-2].gcond=val;
	break;

		case "picf":
	configList[pn-2].picf=val;
	break;

		case "picw":
	if (configList[pn-2].picf)
		configList[pn-2].picw=val;
	break;

		case "pich":
	if (configList[pn-2].picf)
		configList[pn-2].pich=val;
	break;

		case "textl":
	if (configList[pn-2].picf)
		configList[pn-2].textl=val;
	break;
	}
	}
	}
	catch(ex)
	{ ; }
	finally
	{
	try
	{
	tf.Close();
	}
	catch (ex0)
	{ ; }
	}
	}
	else
	{
	pn=1;
	cpos=0;
	CreateControls();

	AddEntry();

	ConfigurationDefaults(true);

	CreateConfigurations();
	PopulateConfigurations();
	CreateSortOrder();

	CreateNavigation();
	FillInConfigFile();

	ConfigDefaults();

	DefaultCatsValues();
	InsertCatsValues();
	PopulateFilter();
	InsertConfigsValues();

	FillUID();

	FillInConfig(cpos);

	selectText(this.document.all.prog,getText(txtNew));

	return;
	}

	if (SortWithinCats)
	configList.sort(byName);
	else
	configList.sort(byOrder);

	cpos=0;
	CreateControls();
	CreateConfigurations();
	PopulateConfigurations();
	CreateSortOrder();
	CreateNavigation();
	FillInConfigFile();

	InsertCatsValues();
	PopulateFilter();

	document.getElementById("ShowMultiDefault").checked=ShowMultiDefault;
	PopulateSortOrderGrid();
	DefaultCatsValues();
	InsertCatsValues();

	InsertConfigsValues();

	FillUID();

	FillInConfig(cpos);
}

function SaveConfig()
{
	position="configwizard.js";
	whatfunc="SaveConfig()";

	var txt;

	if (fromCDDrive)
	{
	Alert("",getText(txtCanNotSaveToCD),getText(lblOK),"",2,0,0,0);

	return;
	}

	strFile=configFile;
	try
	{
	Alert("","<center>"+getText(txtSavingConfigFile),"---none---","",1,-1,0,-80);

	tf=fso.CreateTextFile(strFile,true,true);

	tf.WriteLine("// WPI Config 8.0.0");
	tf.WriteLine("//");
	tf.WriteLine("// User defined options");
	tf.WriteLine("//");
	tf.WriteLine("");
	tf.WriteLine("");
	tf.WriteLine("// Configurations tab");
	tf.WriteLine("CheckOnLoad='" + GetCheckOnLoad() + "';");
	ExtractConfigurations();
	if (Configurations.length>0)
	tf.WriteLine("Configurations=['" + Configurations.join("','") + "'];");
	else
	tf.WriteLine("Configurations=[];");
	tf.WriteLine("ShowMultiDefault=" + document.getElementById("ShowMultiDefault").checked + ";");
	tf.WriteLine("// ---");
	ExtractSortOrderValues();
	if (SortOrder.length>0)
	{
	CatSortOrder.splice(0,CatSortOrder.length);
	CatSortOrder=SortOrder.split(",");
	for (var j=0; j<CatSortOrder.length; j++)		// For apostrophes
	CatSortOrder[j]=CatSortOrder[j].replace(/&amp;/gi,"&").replace(/\\/g,"\\\\").replace(/'/g,"\\'");
	tf.WriteLine("SortOrder=['" + CatSortOrder.join("','") + "'];");
	}
	else
	tf.WriteLine("SortOrder=[];");
	tf.WriteLine("// ---");
	SortingState=NavGrid.getSortingState();
	ConfigSortBy=SortingState[0];
	ConfigSortAscDes=SortingState[1];
	tf.WriteLine("ConfigSortBy="+ConfigSortBy+";");
	tf.WriteLine("ConfigSortAscDes='"+ConfigSortAscDes+"';");
	tf.WriteLine("");
	tf.WriteLine("//---------------------------------------------------------------------------------------------");
	tf.WriteLine("// Your programs here...");
	tf.WriteLine("//---------------------------------------------------------------------------------------------");
	tf.WriteLine("pn=1;");

	CopyConfig(cpos);

	for (var i=0; i<configList.length && configList[i] != null; i++)
	{
	WriteConfigValue(tf, "prog", configList[i].prog,0);
	WriteConfigValue(tf, "shortdesc", configList[i].shortdesc,0);

	txt=GetConfigValue(configList[i].uid,0);
	txt=txt.replace(/ */g,"");
	WriteConfigValue(tf, "uid", txt, 1);
	WriteConfigValue(tf, "ordr", configList[i].ordr,1);
	WriteConfigValue(tf, "dflt", configList[i].dflt,0);
	WriteConfigValue(tf, "forc", configList[i].forc,0);
	WriteConfigValue(tf, "cat", configList[i].cat,0);
	WriteConfigValue(tf, "configs", configList[i].configs,0);

	if (configList[i].rebootcode != "")
	{
	WriteConfigValue(tf, "rebootcode", configList[i].rebootcode,1);
	WriteConfigValue(tf, "repeatcommand", configList[i].repeatcommand,0);
	}

	WriteConfigValue(tf, "pfro", configList[i].pfro,0);

	if (configList[i].cmds.length>0) 
                        { 
                                CurCommands=configList[i].cmds.split("','"); 
                                for (var j=0; j<CurCommands.length; j++) 
                                { 
                                        CurCommands[j]=CurCommands[j].replace(/\\/g,"\\\\").replace(/'/g,"\\'");                // For apostrophes 
                                        CurCommands[j]=CurCommands[j].replace(/,/gi,"%comma%"); 
                                } 
                                tf.WriteLine("cmds[pn]=['" + CurCommands.join("','") + "'];"); 
                        }


	else
	tf.WriteLine("cmds[pn]=[];");

	txt=GetConfigValue(configList[i].deps,0);
	if (txt != "''")
	{
	txt=txt.replace(/ */g,"");
	txt=txt.replace(/'/g,",");
	txt=txt.replace(/,,/g,",");
	txt=txt.replace(/,/g,"','");
	txt=txt.replace(/^',/,"").replace(/,'$/,"");
	WriteConfigValue(tf, "deps", txt, 1);
	}

	txt=GetConfigValue(configList[i].excl,0);
	if (txt != "''")
	{
	txt=txt.replace(/ */g,"");
	txt=txt.replace(/'/g,",");
	txt=txt.replace(/,,/g,",");
	txt=txt.replace(/,/g,"','");
	txt=txt.replace(/^',/,"").replace(/,'$/,"");
	WriteConfigValue(tf, "excl", txt, 1);
	}

	WriteConfigValue(tf, "cond", configList[i].cond,0);
	WriteConfigValue(tf, "gcond",configList[i].gcond,0);
	WriteConfigValue(tf, "desc", configList[i].desc.replace(/\r/gi,"").replace(/\n/gi,""),0);
	WriteConfigValue(tf, "picf", configList[i].picf,0);
	WriteConfigValue(tf, "picw", configList[i].picw,0);
	WriteConfigValue(tf, "pich", configList[i].pich,0);
	WriteConfigValue(tf, "textl", configList[i].textl,0);
	tf.WriteLine("pn++;");
	tf.WriteLine("");
	}
	tf.WriteLine("//---------------------------------------------------------------------------------------------");
	tf.WriteLine("// End of program definitions ...");
	tf.WriteLine("//---------------------------------------------------------------------------------------------");
	isConfigSaved=true ;
	}
	catch(ex)
	{
	alert(getText(errCouldNotSaveFile)+"\n\n"+getText(lblFile)+": "+strFile+"\n"+getText(lblErrorNumber)+": "+(ex.number & 0xffff)+"\n"+getText(lblErrorDescription)+": "+ex.description);
	}
	finally
	{
	try
	{
	tf.Close();
	}
	catch (ex0)
	{ ; }

	Pause(1,0);
	CloseAlert(0);
	}

	Pause(0,500);
}

function ShowConfig()
{
	position="configwizard.js";
	whatfunc="ShowConfig()";

	stopInterval();

	ManualSection="Config";
	ConfigWizardOpen=true;

	ReadConfig();

	ConfigurationDefaults(false);

	SetNOSSAState(false);
}

function HideConfig(reload)
{
	position="configwizard.js";
	whatfunc="HideConfig()";

	WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\ConfigFile",configFile,"REG_SZ");

	if (dhxWins.isWindow("ConfigWindow"))
	{
	ConfigWindow.close();
	ConfigWindow=null;

	ConfigWizardOpen=false;
	}

	if (reload)
	RefreshWPI();
}

function ToggleConfig()
{
	position="configwizard.js";
	whatfunc="ToggleConfig()";

	if (ReadMeWindow != null || AboutWindow != null)
	return;
	if (OptionsWizardOpen || NetworkWizardOpen || ThemeWizardOpen)
	{
	Alert("",getText(txtCanNotSwitchWizards),getText(lblOK),"",3,0,0,0);

	return;
	}

	if (!dhxWins.isWindow("ConfigWindow"))
	{
	isConfigSaved=true;
	ShowConfig();
	}
	else
	{
	if (isConfigSaved)
	HideConfig(true);
	else
	{
	if (Alert("",getText(txtDiscardChanges),getText(lblOK)+"|"+getText(lblCancel),"",5,0,0,0))
	{
	isConfigSaved=true;
	HideConfig(true);
	}
	}
	}
}

function ConvertSpecialCharactersToEntities(text) 
{ 
    try
    {
        return text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); 
    }
    catch (ex)
    {
    }        
} 
 
function RestoreSpecialCharactersFromEntities(text) 
{ 
    try
    {
        return text.replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>'); 
    }
    catch (ex)
    {
    }        
}
