//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// Windows Post - Install Wizard
// installer.js
//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

var InstallScroll = new Object();

InstallScroll.Pane = function(scrollContainerId)
{
   this.bottomThreshold = 17;
   this.scrollContainerId = scrollContainerId;
   this._lastScrollPosition = 100000000;
}

InstallScroll.Pane.prototype.activeScroll = function()
{
   var _ref = this;
   var scrollDiv = document.getElementById(this.scrollContainerId);
   var currentHeight = 0;
   var _getElementHeight = function()
   {
      var intHt = 0;

      if (scrollDiv.style.pixelHeight)
      intHt = scrollDiv.style.pixelHeight;
      else
      intHt = scrollDiv.offsetHeight;

      return parseInt(intHt);
   }

   var _hasUserScrolled = function()
   {
      if (_ref._lastScrollPosition == scrollDiv.scrollTop || _ref._lastScrollPosition == null)
      return false;

      return true;
   }

   var _scrollIfInZone = function()
   {
      if ( ! _hasUserScrolled || (currentHeight - scrollDiv.scrollTop - _getElementHeight() <= _ref.bottomThreshold))
      {
         scrollDiv.scrollTop = currentHeight;
         _ref._isUserActive = false;
      }
   }

   if (scrollDiv.scrollHeight > 0)
   currentHeight = scrollDiv.scrollHeight;
   else if (scrollDiv.offsetHeight > 0)
   currentHeight = scrollDiv.offsetHeight;

   _scrollIfInZone();

   _ref = null;
   scrollDiv = null;
}

var divScroll = new InstallScroll.Pane('Install_prog');

function checkInstall(arg)
{
   position = "installer.js";
   whatfunc = "checkInstall()";

   InstallArg = arg;

   if (OptionsWizardOpen || ConfigWizardOpen || NetworkWizardOpen)
   {
      Alert("", getText(txtCanNotStartInstall), getText(lblOK), "", 3, 0, 0, 0);

      return;
   }

   // If started from hdd, make sure you want to really do an install
   if (fromHardDrive && VerifyInstallHDD && InstallArg != 'exit')
   {
      if ( ! Alert("", getText(txtVerifyInstallHDD), getText(lblOK) + "|" + getText(lblCancel), "", 5, 0, 0, 0))
      return;
   }

   if (InstallArg == 'exit' && forceInstall)
   {
      Alert("", getText(msgForceInstall), getText(lblOK), "", 4, 0, 0, 0);
      return;
   }

   if (InstallArg != 'exit' || ReallyForce)
   {
      if (InstallArg == 'exit')
      {
         Alert("", getText(msgStartInstall), getText(lblOK), "", 4, 0, 50, 75);
         remChecks();
      }

      isInstaller = true;
      // So no exit sound plays

      if (networkUser != "")
      {
         CheckForNetworkUser(networkUser);
         // UserPos set here
         checkInstall2(InstallArg);
      }
      else if (NetworkOptions.OpenPickUser)
      CreatePickUserPage();
      else
      checkInstall2(InstallArg);
   }
   else
   ExitWPI();
}

function checkInstall2()
{
   position = "installer.js";
   whatfunc = "checkInstall2()";

   InstallPrograms();

   if (InstallArg == 'exit' && ReallyForce)
   ExitWPI();

   if (ExitBeforeInstall)
   ExitWPI();

   UserAbortedReopen = RegKeyValue("HKEY_CURRENT_USER\\Software\\WPI\\UserAbortedReopen");
   if (ReOpenAfterInstall || UserAbortedReopen)
   {
      strFile = wpipath + "\\Common\\WPI.hta";
      document.location = "file:///" + strFile.replace(/\\/g, '/');
   }
   else
   ExitWPI();
}

function ShowInstaller()
{
   position = "installer.js";
   whatfunc = "ShowInstaller()";

   var iWidth, iHeight;

   iWidth = 460;
   iHeight = 560;

   strFile = wpipath + "\\Common\\Installer.hta";
   if ( ! FileExists(strFile))
   {
      alert(getText(errCouldNotOpenFile) + " '"+strFile+"'.");
      ExitWPI();
   }

   if ( ! ResumeInstall)
   htm();
   // Turn off tips

   if ( ! ResumeInstall)
   {
      ins_initInterval();
      WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\InstallStartTime", ins_startSecs, "REG_DWORD");
      // Set install state to in progress
   }

   if ( ! ResumeInstall)
   {
      SetNotExitingFlag();
      document.location = "file:///" + strFile.replace(/\\/g, '/');
   }

   window.resizeTo(0, 0);
   var XCoord = ((screen.width / 2) - (iWidth / 2));
   var YCoord = ((screen.height / 2) - (iHeight / 2));
   if (InstallerWindowX != - 1)
   XCoord = InstallerWindowX;
   if (InstallerWindowY != - 1)
   YCoord = InstallerWindowY;
   window.moveTo(XCoord, YCoord);
   window.resizeTo(iWidth, iHeight);
   window.resizeTo(iWidth + (460 - document.body.clientWidth), iHeight + (560 - document.body.clientHeight));

   while (window.document.readyState != 'complete' && ! ResumeInstall)
   Pause(0, 100);

   document.getElementById("Abort").innerHTML = getText(btnAbort);
   document.getElementById("Pause").innerHTML = getText(btnPause);
   document.getElementById("installLayer").style.cursor = 'wait';
   document.getElementById("AbortButton").blur();
   document.getElementById("PauseButton").blur();
   document.getElementById("RestartShutDown").options[1].text = getText(optRestart);
   document.getElementById("RestartShutDown").options[2].text = getText(optShutDown);
   SetRestartShutDown();
   if (DisableInstallCombobox)
   document.getElementById("RestartShutDown").disabled = true;

   WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\UserAborted", 0, "REG_DWORD");
   // Reset abort state
   WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\ResumeInstall", 1, "REG_DWORD");
   // Set install state to in progress
   WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\CurrentInstall", 0, "REG_DWORD");
   // Save current position for reboots
   if (LoadDesktopBeforeInstall)														// For a reboot, when to start
   {
      WriteRegKey("HKEY_LOCAL_MACHINE\\Software\\Microsoft\\Windows\\CurrentVersion\\RunOnce\\WPIresume", sysdir + '\\mshta.exe "'+wpipath+'\\Common\\Installer.hta"', "REG_SZ");
   }
   else
   {
      WriteRegKey("HKEY_LOCAL_MACHINE\\Software\\Microsoft\\Windows\\CurrentVersion\\RunOnceEx\\001\\1", sysdir + '\\mshta.exe "'+wpipath+'\\Common\\Installer.hta"', "REG_SZ");
   }

   if (PlayAudioInInstaller)
   {
      InstallAudioPath = RegKeyValue("HKEY_CURRENT_USER\\Software\\WPI\\InstallAudioPath");
      document.getElementById("MediaPlayerDIV").style.display = 'block';
   }

   GetUserInfo();
   SetUserInfo();

   if (RegKeyValue("HKEY_CURRENT_USER\\Software\\WPI\\SndInstallStartCB"))
   {
      PlaySound(RegKeyValue("HKEY_CURRENT_USER\\Software\\WPI\\SndInstallStart"));
      Pause(1, 0);
   }
   if (PlayAudioInInstaller && ! CopyAudioFolder)
   {
      document.getElementById("MediaPlayer").controls.play();
   }
}


function InstallPrograms()
{
   position = "installer.js";
   whatfunc = "InstallPrograms()";

   var i, j, tempCmd;
   var firstItem = true;
   var box = "";
   var ReturnCodeReboot = false, BreakInstall = false;
   var CurrentPFRO = 0;

   // Make sure we use the real % CDROM % path
   hdd = "";

   if ( ! ResumeInstall)
   {
      for (i = 1; prog[i] != null; i ++ )
      {
         if (document.getElementById("chkbox" + i) && document.getElementById("chkbox" + i).checked)
         {
            programs[programs.length ++ ] = new program(i);
            programs[programs.length - 1].texti = i;
            // For InsertCatNames()

            ScanForEntries(new program(i));
         }
      }
      WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\RebootEntryFound", RebootEntryFound ? 1 : 0, "REG_DWORD");

      if ( ! InstallByCategory)
      programs.sort(SortByOrder);
   }

   OpenLogFile();
   if ( ! ResumeInstall)
   OpenRebootFile();
   OpenHistoryFile();

   if ( ! ResumeInstall)
   {
      var NumToInstall = 0;

      // Do first stuff added in reverse order
      if (ExecuteBeforeEnabled && ExecuteBefore != null)
      {
         programs.splice(0, 0, new program(999991));
         programs[0].prog = "Execute Before";
         programs[0].uid = "EXECUTE_BEFORE";
         programs[0].ordr = 0;
         programs[0].cat = "WPI Built In";
         programs[0].cmds = ExecuteBefore;
         numCommands ++ ;
      }

      if (UserPos != - 1)
      {
         programs.splice(0, 0, new program(999985));
         programs[0].prog = getText(txtSettingNetworkOptions);
         programs[0].uid = "SET_NETWORK_OPTIONS";
         programs[0].ordr = 0;
         programs[0].cat = "WPI Built In";

         var x = 0, netsh = [];

         if (NetworkOptions.Users[UserPos].ComputerName != "")
         {
            netsh[x ++ ] = '{JSCRIPT}=RenameComputer("'+NetworkOptions.Users[UserPos].ComputerName+'")';
         }

         netsh[x ++ ] = '{JSCRIPT}=CreateWindowsUser("'+NetworkOptions.Users[UserPos].UserName+'"%comma%"'+decode64(NetworkOptions.Users[UserPos].UserPassword)+'"%comma%' + (NetworkOptions.Users[UserPos].Administrator ? 'true' : 'false') + ')';

         if (NetworkOptions.Users[UserPos].Workgroup != "")
         {
            netsh[x ++ ] = '{JSCRIPT}=JoinWorkgroup("'+NetworkOptions.Users[UserPos].Workgroup+'")';
         }

         if (NetworkOptions.Users[UserPos].ObtainIP == "Automatically")
         {
            netsh[x ++ ] = '{NETSH} interface ip set address name="Local Area Connection" source=dhcp';
         }
         else
         {
            netsh[x ++ ] = '{NETSH} interface ip set address name="Local Area Connection" source=static addr=' + NetworkOptions.Users[UserPos].IPAddress + ' PB_Mask=' + NetworkOptions.Users[UserPos].SubnetPB_Mask + ' gateway=' + NetworkOptions.Users[UserPos].DefaultGateway + (NetworkOptions.Users[UserPos].DefaultGateways[0].Metric != "Automatic" ? ' gwmetric=' + NetworkOptions.Users[UserPos].DefaultGateways[0].Metric : ' gwmetric=0');
            netsh[x ++ ] = '{NETSH} interface ip set dns name="Local Area Connection" source=static addr=' + NetworkOptions.Users[UserPos].PreferredDNS + ' register=primary';
         }
         if (NetworkOptions.Users[UserPos].IPAddresses.length > 1)
         {
            for (var i = 1; i < NetworkOptions.Users[UserPos].IPAddresses.length;
            i ++ )
            {
               netsh[x ++ ] = '{NETSH} interface ip add address name="Local Area Connection" addr=' + NetworkOptions.Users[UserPos].IPAddresses[i].IP + ' PB_Mask=' + NetworkOptions.Users[UserPos].IPAddresses[i].Subnet;
            }

         }
         if (NetworkOptions.Users[UserPos].DefaultGateways.length > 1)
         {
            for (var i = 1; i < NetworkOptions.Users[UserPos].DefaultGateways.length;
            i ++ )
            {
               netsh[x ++ ] = '{NETSH} interface ip add address name="Local Area Connection" gateway=' + NetworkOptions.Users[UserPos].DefaultGateways[i].Gateway + (NetworkOptions.Users[UserPos].DefaultGateways[i].Metric != "Automatic" ? ' gwmetric=' + NetworkOptions.Users[UserPos].DefaultGateways[i].Metric : ' gwmetric=0');
            }

         }

         // This is working on Vista, but not XP
         if (NetworkOptions.Users[UserPos].AutomaticMetric)
         {
            netsh[x ++ ] = '{NETSH} interface ip set interface "Local Area Connection" metric=0';
         }
         else
         {
            netsh[x ++ ] = '{NETSH} interface ip set interface "Local Area Connection" metric=' + NetworkOptions.Users[UserPos].InterfaceMetric;
         }

         if (NetworkOptions.Users[UserPos].ObtainDNS == "Automatically")
         {
            netsh[x ++ ] = '{NETSH} interface ip set dns name="Local Area Connection" source=dhcp';
         }
         else
         {
            if (NetworkOptions.Users[UserPos].DNSServers.length > 1)
            {
               for (var i = 1; i < NetworkOptions.Users[UserPos].DNSServers.length;
               i ++ )
               {
                  netsh[x ++ ] = '{NETSH} interface ip add dns name="Local Area Connection" addr=' + NetworkOptions.Users[UserPos].DNSServers[i].IP + ' index=' + (i + 1);
               }
            }
         }

         if (NetworkOptions.Users[UserPos].WINSServers.length == 0)
         {
            netsh[x ++ ] = '{NETSH} interface ip set wins name="Local Area Connection" source=dhcp';
         }
         else
         {
            for (var i = 0; i < NetworkOptions.Users[UserPos].WINSServers.length;
            i ++ )
            {
               netsh[x ++ ] = '{NETSH} interface ip add wins name="Local Area Connection" addr=' + NetworkOptions.Users[UserPos].WINSServers[i].IP;
            }
         }

         if (NetworkOptions.Users[UserPos].RebootAfterApplied)
         {
            netsh[x ++ ] = '{REBOOT} 10';
            RebootEntryFound = true;
            WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\RebootEntryFound", 1, "REG_DWORD");
         }

         if (NetworkOptions.Users[UserPos].AutoLogonUser)
         {
            netsh[x ++ ] = '{JSCRIPT}=SetAutoLogonUser("'+NetworkOptions.Users[UserPos].UserName+'"%comma%"'+decode64(NetworkOptions.Users[UserPos].UserPassword)+'"%comma%"'+LogOnServer+'")';
         }

         numCommands += netsh.length;
         programs[0].cmds = netsh.join(",");
      }

      if (PlayAudioInInstaller && CopyAudioFolder)
      {
         programs.splice(0, 0, new program(999980));
         programs[0].prog = getText(txtCopyAudioFolderToHD);
         programs[0].uid = "COPY_AUDIO_TO_HD";
         programs[0].ordr = 0;
         programs[0].cat = "WPI Built In";
         programs[0].cmds = "{DIRCOPY} " + wpipath + "\\Audio " + CopyAudioPath;
         numCommands ++ ;
      }

      if (ExecuteAfterEnabled && ExecuteAfter != null)
      {
         programs.splice(programs.length, 0, new program(999992));
         programs[programs.length - 1].prog = "Execute After";
         programs[programs.length - 1].uid = "EXECUTE_AFTER";
         programs[programs.length - 1].ordr = 0;
         programs[programs.length - 1].cat = "WPI Built In";
         programs[programs.length - 1].cmds = ExecuteAfter;
         numCommands ++ ;
      }

      if (UserPos != - 1 && NetworkOptions.Users[UserPos].ClearAutoLogonUser)
      {
         programs.splice(programs.length, 0, new program(999998));
         programs[programs.length - 1].prog = getText(txtSettingNetworkOptions);
         programs[programs.length - 1].uid = "SET_NETWORK_OPTIONS";
         programs[programs.length - 1].ordr = 0;
         programs[programs.length - 1].cat = "WPI Built In";
         programs[programs.length - 1].cmds = "{JSCRIPT}=ClearAutoLogonUser()";
         numCommands ++ ;
      }

      if (PlayAudioInInstaller && CopyAudioFolder && DeleteAudioFolder)
      {
         programs.splice(programs.length, 0, new program(999999));
         programs[programs.length - 1].prog = getText(txtDeleteAudioFolder);
         programs[programs.length - 1].uid = "DELETE_AUDIO_FROM_HD";
         programs[programs.length - 1].ordr = 0;
         programs[programs.length - 1].cat = "WPI Built In";
         programs[programs.length - 1].cmds = "{DELDIR} " + '"'+CopyAudioPath+'"';
         numCommands ++ ;
      }

      if (programs.length == 0)
      return;

      if (RebootEntryFound)
      WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\numCommands", numCommands, "REG_DWORD");
      // Save numCommands for reboots

      WriteLogLinePlain("\r\n" + getText(ListofProgsToInstall));
      for (i = 0; programs[i] != null; i ++ )
      {
         if (programs[i].desc != "WPI Built In Category")
         {
            WriteLogLinePlain("   " + programs[i].prog);
            RebootEntry(programs[i]);
            NumToInstall ++ ;
         }
      }
      WriteLogLinePlain("\r\n" + NumToInstall + " " + getText(InstallItems) + ", " + numCommands + " " + getText(InstallCommands));
   }

   CloseRebootFile();

   if ( ! ResumeInstall && LoadDesktopBeforeInstall && ! DesktopLoaded)
   {
      WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\ResumeInstall", 1, "REG_DWORD");
      // Set install state to in progress
      WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\CurrentInstall", 0, "REG_DWORD");
      // Save current position for reboots
      WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\ResumeCount", ResumeCount, "REG_DWORD");
      WriteRegKey("HKEY_LOCAL_MACHINE\\Software\\Microsoft\\Windows\\CurrentVersion\\RunOnce\\WPIresume", sysdir + '\\mshta.exe "'+wpipath+'\\Common\\Installer.hta"', "REG_SZ");

      ExitBeforeInstall = true;

      return;
   }

   ShowInstaller();
   ins_startInterval();

   if (ResumeInstall)
   {
      ReadHistoryEntries();
      UpdateProgressBar(Math.round((curCommand / numCommands) * 100));
   }
   else
   ClearProgressBar();

   ResumeInstall ? i = CurrentInstall : i = 0;

   if (ResumeInstall)
   {
      CurrentCategory = programs[CurrentInstall].cat;
      firstItem = false;
   }

   for (i; i < programs.length && programs[i] != null;
   i ++ )
   {
      UserAborted = RegKeyValue("HKEY_CURRENT_USER\\Software\\WPI\\UserAborted");
      if (UserAborted)
      break;

      if ( ! ResumeInstall || (LoadDesktopBeforeInstall && ResumeCount == 1))
      {
         box = '';
         if (programs[i].cat[0] == CurrentCategory)
         {
            box += '<table border="0" width="100%" cellpadding="0" cellspacing="0">';
            box += '<tr><td class="InstallText" nowrap>';
            box += programs[i].prog;
            box += '</td></tr></table>';
         }
         else
         {
            if (InstallByCategory)
            {
               if ( ! firstItem)
               {
                  box += '<br>';
                  AddToInstallList(box);
                  AddHistoryEntry(box + "\n");
               }
               firstItem = false;

               box = '<span class="InstallText">';
               box += '<b><i>' + programs[i].cat + '</i></b>';
               box += '</span>';
               AddToInstallList(box);
               AddHistoryEntry(box + "\n");

               CurrentCategory = programs[i].cat;
            }
            box = '';
            box += '<table border="0" width="100%" cellpadding="0" cellspacing="0">';
            box += '<tr><td class="InstallText" nowrap>';
            box += programs[i].prog;
            box += '</td></tr></table>';
         }
         AddToInstallList(box);
         AddHistoryEntry(box + "\n");
      }

      if (PlayAudioInInstaller && DeleteAudioFolder && programs[i].uid == "DELETE_AUDIO_FROM_HD")		// Stop player so can delete folder
      {
         document.getElementById("MediaPlayer").controls.stop();
         document.getElementById("MediaPlayer").url = "";
         Pause(0, 2500);
      }

      if ( ! ResumeInstall)
      StartLogEntry(programs[i]);

      CurrentPFRO = RegKeyValue("HKEY_CURRENT_USER\\Software\\WPI\\CurrentPFRO");
      if (programs[i].pfro == "yes" && CurrentPFRO == "")
      {
         if (CheckPendingFileRenameOperations())
         {
            WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\CurrentPFRO", i, "REG_DWORD");

            CheckAutoLogonCount();

            cmdLine = '"'+sysdir+'\\shutdown.exe" -r -f -t 10 -c "'+getText(ComputerWillRestartPFRO)+'"';
            RunCmd(cmdLine, false, true);
            PauseNew(3600, 0);
            // Give some time for {reboot} to take affect
         }
      }
      if (CurrentPFRO != "")
      {
         DeleteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\CurrentPFRO");
      }

      WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\CurrentInstall", i, "REG_DWORD");
      // Save current position for reboots
      document.getElementById("NumItems").innerHTML = (i + 1) + "/" + programs.length;

      UserAborted = RegKeyValue("HKEY_CURRENT_USER\\Software\\WPI\\UserAborted");
      if (UserAborted)
      break;
      if ( ! ResumeInstall)
      WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\LastExec", 0, "REG_DWORD");
      // Save current position for reboots

      ResumeInstall ? j = LastExec + 1 : j = 1;
      var string = new String(programs[i].cmds);
      Commands.splice(0, Commands.length);
      Commands = string.split(",");
      Commands.unshift("");
      // Really starting at 1
      for (j; j < Commands.length; j ++ )
      {
         UserPaused = RegKeyValue("HKEY_CURRENT_USER\\Software\\WPI\\UserPaused");
         while(UserPaused)
         {
            Pause(0, 250);
            // Pause the installation on user request
            UserPaused = RegKeyValue("HKEY_CURRENT_USER\\Software\\WPI\\UserPaused");
         }

         if (ReturnCodeReboot)
         break;

         UserAborted = RegKeyValue("HKEY_CURRENT_USER\\Software\\WPI\\UserAborted");
         if (UserAborted)
         break;

         WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\LastExec", j, "REG_DWORD");
         // Save current position for reboots
         tempCmd = Commands[j];
         if (tempCmd != null && ReplacePath(tempCmd) != '')
         {
            box = '';
            box += '<table border="0" width="100%" cellpadding="0" cellspacing="0">';
            box += '<tr><td class="InstallText" nowrap>';
            box += '<img src="../Common/imgs/spacer.gif" border="0" width="20" height="1">';
            box += getText(lblCommand) + ' ' + j + '...';
            box += '</td><td width="100%">';
            box += '<div id="div'+i+'_'+j+'_'+FailNum+'" class="InstallText" style="position:relative; top:0px; left:0px; width:100%;"></div>';
            box += '</td></tr></table>';
            AddToInstallList(box);
            WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\curCommand", curCommand + 1, "REG_DWORD");
            // Save current command position for reboots
            WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\NumFailed", NumFailed, "REG_DWORD");
            // Save current command position for reboots

            var srf = InstallOne(i, j, programs[i].rebootcode);
            if (srf == 0)
            {
               document.getElementById("div" + i + "_" + j + "_" + FailNum).className = "InstallSuccess";
               if ( ! ShowInstallerImages)
               UpdateInstallList(("div" + i + "_" + j + "_" + FailNum), getText(txtInstallSuccess));
               else
               UpdateInstallList(("div" + i + "_" + j + "_" + FailNum), '<img src="../Themes/'+Theme+'/Install_Success.png" border="0" width="16" height="16">');
               box = box.replace('class="InstallText" style=', 'class="InstallSuccess" style=');
               if ( ! ShowInstallerImages)
               box = box.replace('"></div>','">' + getText(txtInstallSuccess) + '</div>');
               else
               box = box.replace('"></div>','"><img src="../Themes/'+Theme+'/Install_Success.png" border="0" width="16" height="16"></div>');
               AddHistoryEntry(box + "\n");

               if (RegKeyValue("HKEY_CURRENT_USER\\Software\\WPI\\SndInstallSuccessCB"))
               {
                  PlaySound(RegKeyValue("HKEY_CURRENT_USER\\Software\\WPI\\SndInstallSuccess"));
                  Pause(0, 200);
               }
            }
            if (srf == 1)
            {
               document.getElementById("div" + i + "_" + j + "_" + FailNum).className = "InstallFail";
               if ( ! ShowInstallerImages)
               UpdateInstallList(("div" + i + "_" + j + "_" + FailNum), getText(txtInstallFailed));
               else
               UpdateInstallList(("div" + i + "_" + j + "_" + FailNum), '<img src="../Themes/'+Theme+'/Install_Fail.png" border="0" width="16" height="16">');
               box = box.replace('class="InstallText" style=', 'class="InstallFail" style=');
               if ( ! ShowInstallerImages)
               box = box.replace('"></div>','">' + getText(txtInstallFailed) + '</div>');
               else
               box = box.replace('"></div>','"><img src="../Themes/'+Theme+'/Install_Fail.png" border="0" width="16" height="16"></div>');
               AddHistoryEntry(box + "\n");

               if (RegKeyValue("HKEY_CURRENT_USER\\Software\\WPI\\SndInstallFailCB"))
               {
                  PlaySound(RegKeyValue("HKEY_CURRENT_USER\\Software\\WPI\\SndInstallFail"));
                  Pause(0, 200);
               }

               if (AbortInstallIfFailure)
               BreakInstall = true;
            }
            else if (srf == 2)
            {
               document.getElementById("div" + i + "_" + j + "_" + FailNum).className = "InstallWarning";
               if ( ! ShowInstallerImages)
               UpdateInstallList(("div" + i + "_" + j + "_" + FailNum), getText(txtInstallWarning));
               else
               UpdateInstallList(("div" + i + "_" + j + "_" + FailNum), '<img src="../Themes/'+Theme+'/Install_Warning.png" border="0" width="16" height="16">');
               box = box.replace('class="InstallText" style=', 'class="InstallWarning" style=');
               if ( ! ShowInstallerImages)
               box = box.replace('"></div>','">' + getText(txtInstallWarning) + '</div>');
               else
               box = box.replace('"></div>','"><img src="../Themes/'+Theme+'/Install_Warning.png" border="0" width="16" height="16"></div>');
               AddHistoryEntry(box + "\n");

               if (RegKeyValue("HKEY_CURRENT_USER\\Software\\WPI\\SndInstallWarningCB"))
               {
                  PlaySound(RegKeyValue("HKEY_CURRENT_USER\\Software\\WPI\\SndInstallWarning"));
                  Pause(0, 200);
               }
            }
            else if (srf == 3)
            {
               document.getElementById("div" + i + "_" + j + "_" + FailNum).className = "InstallWarning";
               if ( ! ShowInstallerImages)
               UpdateInstallList(("div" + i + "_" + j + "_" + FailNum), getText(txtInstallSkipped));
               else
               UpdateInstallList(("div" + i + "_" + j + "_" + FailNum), '<img src="../Themes/'+Theme+'/Install_Warning.png" border="0" width="16" height="16">');
               box = box.replace('class="InstallText" style=', 'class="InstallWarning" style=');
               if ( ! ShowInstallerImages)
               box = box.replace('"></div>','">' + getText(txtInstallSkipped) + '</div>');
               else
               box = box.replace('"></div>','"><img src="../Themes/'+Theme+'/Install_Warning.png" border="0" width="16" height="16"></div>');
               AddHistoryEntry(box + "\n");

               if (RegKeyValue("HKEY_CURRENT_USER\\Software\\WPI\\SndInstallWarningCB"))
               {
                  PlaySound(RegKeyValue("HKEY_CURRENT_USER\\Software\\WPI\\SndInstallWarning"));
                  Pause(0, 200);
               }
            }
            else if (srf == 4)
            {
               document.getElementById("div" + i + "_" + j + "_" + FailNum).className = "InstallWarning";
               if ( ! ShowInstallerImages)
               UpdateInstallList(("div" + i + "_" + j + "_" + FailNum), getText(txtInstallRebootRequired));
               else
               UpdateInstallList(("div" + i + "_" + j + "_" + FailNum), '<img src="../Themes/'+Theme+'/Install_Warning.png" border="0" width="16" height="16">');
               box = box.replace('class="InstallText" style=', 'class="InstallWarning" style=');
               if ( ! ShowInstallerImages)
               box = box.replace('"></div>','">' + getText(txtInstallRebootRequired) + '</div>');
               else
               box = box.replace('"></div>','"><img src="../Themes/'+Theme+'/Install_Warning.png" border="0" width="16" height="16"></div>');
               AddHistoryEntry(box + "\n");

               if (RegKeyValue("HKEY_CURRENT_USER\\Software\\WPI\\SndInstallWarningCB"))
               {
                  PlaySound(RegKeyValue("HKEY_CURRENT_USER\\Software\\WPI\\SndInstallWarning"));
                  Pause(0, 200);
               }

               ReturnCodeReboot = true;
            }
         }

         if (ReturnCodeReboot)
         break;

         if (BreakInstall)
         break;

         curCommand ++ ;
         UpdateProgressBar(Math.abs((curCommand / numCommands) * 100));
         Pause(0, 250);
      }

      if (PlayAudioInInstaller && CopyAudioFolder && programs[i].uid == "COPY_AUDIO_TO_HD")
      {
         document.getElementById("MediaPlayer").controls.play();
      }

      if (ReturnCodeReboot)
      {
         CheckAutoLogonCount();
         if (programs[i].repeatcommand == "yes")
         {
            var RepeatCommand = RegKeyValue("HKEY_CURRENT_USER\\Software\\WPI\\LastExec");
            WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\LastExec", RepeatCommand - 1, "REG_DWORD");
            // Save current position for reboots

            FailNum ++ ;
            WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\FailNum", FailNum, "REG_DWORD");
         }

         cmdLine = '"'+sysdir+'\\shutdown.exe" -r -f -t 5 -c "'+getText(ComputerWillRestart)+'"';
         RunCmd(cmdLine, false, true);
         PauseNew(3600, 0);
         // Give some time for {reboot} to take affect
      }

      if (BreakInstall)
      {
         WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\UserPaused", 0, "REG_DWORD");
         WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\UserAborted", 1, "REG_DWORD");
         WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\UserAbortedReopen", 0, "REG_DWORD");

         if (ContinueWhereFailed)
         {
            var LastFail = RegKeyValue("HKEY_CURRENT_USER\\Software\\WPI\\LastExec");
            WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\LastExec", LastFail - 1, "REG_DWORD");
            // Save current position for reboots

            FailNum ++ ;
            WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\FailNum", FailNum, "REG_DWORD");
         }
      }

      UserAborted = RegKeyValue("HKEY_CURRENT_USER\\Software\\WPI\\UserAborted");
      if (UserAborted)
      break;
      if ( ! ResumeInstall || (ResumeInstall && LastExec < Commands.length))
      WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\LastExec", Commands.length, "REG_DWORD");
      // Save current position for reboots

      if (ResumeInstall)
      {
         LastExec != Commands.length + 2 ? WriteLogLine(getText(FinishedInstallation)) : null;
         ResumeInstall = false;
         RebootEntryFound = true;
         continue;
      }
      else
      {
         WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\LastExec", Commands.length + 2, "REG_DWORD");
         WriteLogLine(getText(FinishedInstallation));
      }

      UserPaused = RegKeyValue("HKEY_CURRENT_USER\\Software\\WPI\\UserPaused");
      while(UserPaused)
      {
         Pause(0, 250);
         // Pause the installation on user request
         UserPaused = RegKeyValue("HKEY_CURRENT_USER\\Software\\WPI\\UserPaused");
      }

      UserAborted = RegKeyValue("HKEY_CURRENT_USER\\Software\\WPI\\UserAborted");
      if (UserAborted)
      break;
   }
   UserAborted = RegKeyValue("HKEY_CURRENT_USER\\Software\\WPI\\UserAborted");

   if (BreakInstall)
   {
      WriteLogLinePlain("\r\n\r\n" + getText(txtInstallAbortedFailure));

      if (ExecuteCommandIfFailure != '')
      {
         var ReturnCode, result;

         try
         {
            ReturnCode = WshShell.Run(ExecuteCommandIfFailure, AlwaysShowOutputWindow ? 0 : 1, true);

            if (ReturnCode == 0)
            result = getText(InstallSuccess);
            else
            result = getText(InstallFail);
         }
         catch(ex)
         {
            result = getText(InstallFail);
         }

         WriteLogLinePlain("\r\n\r\n" + getText(lblAbortInstallIfFailure) + ":\r\n");
         WriteLogLine('cmd1 ' + result + ' (' + getText(ReturnedCode) + ' ' + ReturnCode + '): ' + ExecuteCommandIfFailure);
      }
   }

   if ( ! BreakInstall && UserAborted)
   WriteLogLinePlain("\r\n\r\n" + getText(InstallAbortedByUser));

   UpdateProgressBar(100);
   Pause(0, 250);

   CloseLogFile();
   LogInstallation = false;
   RebootInstallationLog = false;
   CloseHistoryFile();

   UserAborted = RegKeyValue("HKEY_CURRENT_USER\\Software\\WPI\\UserAborted");
   if ( ! UserAborted && ! ReturnCodeReboot)
   {
      DeleteRebootFile();
      DeleteHistoryFile();

      RestartComputer = RegKeyValue("HKEY_CURRENT_USER\\Software\\WPI\\RestartComputer");
      RestartType = RegKeyValue("HKEY_CURRENT_USER\\Software\\WPI\\RestartType");

      WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\ResumeInstall", 0, "REG_DWORD");
      DeleteAllRegKeys();
   }
   else
   {
      RestartComputer = false;
      // Yes ?
   }

   ins_stopInterval();
   DeleteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\InstallStartTime");

   if (RestartComputer)
   {
      CheckAutoLogonCount();

      DeleteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\RestartComputer");
      DeleteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\RestartType");

      if ( ! RestartType)
      cmdLine = '"'+sysdir+'\\shutdown.exe" -r -f -t ' + RestartSeconds + ' -c "'+getText(ComputerWillRestart)+'"';
      else
      cmdLine = '"'+sysdir+'\\shutdown.exe" -s -f -t ' + RestartSeconds + ' -c "'+getText(ComputerWillShutdown)+'"';
      RunCmd(cmdLine, false, DoNotLoadDesktop);
   }

   if (RegKeyValue("HKEY_CURRENT_USER\\Software\\WPI\\SndInstallFinishCB"))
   {
      document.getElementById("MediaPlayer").controls.stop();
      document.getElementById("MediaPlayer").url = "";
      PlaySound(RegKeyValue("HKEY_CURRENT_USER\\Software\\WPI\\SndInstallFinish"));
   }
   Pause(3, 0);
}

function InstallOne(item, cmdNum, RebootCode)
{
   position = "installer.js";
   whatfunc = "InstallOne()";

   var cmdName = "cmd" + cmdNum;

   var cmd, cmdLine, ReturnCode = 999, result, SuccessRebootFail = 0;
   var IsReboot = false;

   cmd = Commands[cmdNum];
   if (cmd == null || (cmdLine = ReplacePath(cmd)) == '')
   return 0;

   if (cmd.toUpperCase().indexOf("{REBOOT}") == 0 || (ResumeInstall && cmd.toUpperCase().indexOf("SHUTDOWN.EXE") == 0))
   IsReboot = true;

   isIE = false;
   cmdLine = handleCommand(cmdLine, item, cmdNum);

   if (cmdLine == "SKIP0")
   {
      SuccessRebootFail = 3;
      result = getText(InstallSkipped);
      WriteLogLine(cmdName + ' ' + result + ' (' + getText(InstallWrongArchitecture) + '): ' + cmd.replace(/\\\\/gi,"\\"));

      return SuccessRebootFail;
   }

   if (cmdLine == getText(txtErrorRegEditFileExists) || cmdLine == getText(txtErrorExtractFileExists))
   {
      NumFailed ++ ;
      SuccessRebootFail = 1;
      WriteLogLine(cmdName + ' ' + getText(FailFileDoesNotExist) + ': ' + Commands[cmdNum]);

      return false;
   }

   document.getElementById("InstallItem").innerHTML = cmdLine;

   if (cmdLine.toUpperCase().indexOf("{JSCRIPT}=") == 0)
   {
      cmdLine = cmdLine.replace(/{JSCRIPT}=/gi,"");
      cmdLine = cmdLine.replace(/\\/gi,"\\\\");

      try
      {
         ReturnCode = eval(cmdLine);
         result = getText(InstallSuccess);
         WriteLogLine(cmdName + ' ' + result + ' (' + getText(ReturnedCode) + ' ' + ReturnCode + '): ' + cmdLine.replace(/\\\\/gi,"\\"));
         SuccessRebootFail = 0;
      }
      catch(ex)
      {
         NumFailed ++ ;
         result = getText(InstallFail);
         WriteLogLine(cmdName + ' ' + result + ' (' + getText(ReturnedCode) + ' ' + ReturnCode + '): ' + cmdLine.replace(/\\\\/gi,"\\"));
         SuccessRebootFail = 1;
      }

      return SuccessRebootFail;
   }

   try
   {
      if (isIE && ! FileExists(ReplacePath("%programfiles%\\Internet Explorer\\iexplore.exe")))
      throw 1;

      if (AlwaysShowOutputWindow)
      fsoCmd = false;
      ReturnCode = WshShell.Run(cmdLine, fsoCmd ? 0 : 1, waitForIt);

      if (isIE)	// IE always returns 1, even if successful
      ReturnCode = 0;

      if (ReturnCode == 0)
      {
         result = getText(InstallSuccess);
         SuccessRebootFail = 0;
      }
      else if (ReturnCode == 1)
      {
         NumFailed ++ ;
         result = getText(InstallFail);
         SuccessRebootFail = 1;
      }
      else if (ReturnCode == RebootCode)
      {
         result = getText(InstallRebootRequired);
         SuccessRebootFail = 4;
      }
      else if (ReturnCode == 259)
      {
         result = getText(InstallStillActive);
         SuccessRebootFail = 2;
      }
      else
      {
         result = getText(InstallWarning);
         SuccessRebootFail = 2;
      }
   }
   catch(ex)
   {
      NumFailed ++ ;
      result = getText(InstallFail);
      SuccessRebootFail = 1;
   }
   WriteLogLine(cmdName + ' ' + result + ' (' + getText(ReturnedCode) + ' ' + ReturnCode + '): ' + cmdLine);
   fsoCmd = false;
   waitForIt = true;

   if (IsReboot)
   {
      CheckAutoLogonCount();

      box = '';
      box += '<table border="0" width="100%" cellpadding="0" cellspacing="0">';
      box += '<tr><td class="InstallText" nowrap>';
      box += '<img src="../Common/imgs/spacer.gif" border="0" width="20" height="1">';
      box += getText(lblCommand) + ' ' + cmdNum + '...';
      box += '</td><td width="100%">';
      if ( ! ShowInstallerImages)
      box += '<div id="div'+item+'_'+cmdNum+'_'+FailNum+'" class="InstallSuccess" style="position:relative; top:0px; left:0px; width:100%;">' + getText(txtInstallSuccess) + '</div>';
      else
      box += '<div id="div'+item+'_'+cmdNum+'_'+FailNum+'" class="InstallSuccess" style="position:relative; top:0px; left:0px; width:100%;"><img src="../Themes/'+Theme+'/Install_Success.png" border="0" width="16" height="16"></div>';
      box += '</td></tr></table>';
      AddHistoryEntry(box + "\n");

      PauseNew(3600, 0);
      // Give some time for {reboot} to take affect
   }

   return SuccessRebootFail;
}

function handleCommand(cmd, item, cmdNum)
{
   position = "installer.js";
   whatfunc = "handleCommand()";

   var braceEndPosition = cmd.indexOf("}");
   if (cmd.substr(0, 1) == "{" && braceEndPosition > 0)
   {
      var statementToken = cmd.substr(1, braceEndPosition - 1);
      var splittedStatementToken = statementToken.split("=");
      var statement = splittedStatementToken[0].toUpperCase();
      var statementArguments = splittedStatementToken.length > 1 ? splittedStatementToken[1] : "";

      if (statement == "JSCRIPT")
      return cmd;

      cmd = cmd.substr(braceEndPosition + 1, cmd.length).replace(/^\s+/, "");

      switch(statement) 
      { 
       case 'OS': 
         var supportedOSes = statementArguments.split('||');
         var uppercaseCurrentOS = getOSver().toUpperCase();
            for (var supportedOSNum = 0; supportedOSNum < supportedOSes.length;
            supportedOSNum ++ )
         if (uppercaseCurrentOS == supportedOSes[supportedOSNum].replace(/^\s+|\s+$/g, "").toUpperCase())
            return handleCommand(cmd, item, cmdNum);
            cmd = "SKIP0";
            fsoCmd = false;
            break;

         case 'X86' :
            if (getBits() == 32)
            return handleCommand(cmd, item, cmdNum);
            cmd = "SKIP0";
            fsoCmd = false;
            break;

         case 'X64' :
            if (getBits() == 64)
            return handleCommand(cmd, item, cmdNum);
            cmd = "SKIP0";
            fsoCmd = false;
            break;

         case 'WEB' :
            document.getElementById("InstallItem").innerHTML = getText(lblViewing) + " " + cmd;
            cmd = '"'+ReplacePath(" % programfiles % \\Internet Explorer\\iexplore.exe")+'" ' + cmd;
            UpdateInstallList(("div" + item + "_" + cmdNum + "_" + FailNum), getText(txtInstallViewing));
            isIE = true;
            fsoCmd = false;
            break;

         case 'DOWNLOAD' :
            cmd = DownloadFile(cmd, item, cmdNum);
            fsoCmd = false;
            break;

         case 'NETSH' :
            cmd = "CMD /C NETSH " + cmd;
            cmd = ReplacePath(cmd);
            fsoCmd = true;
            break;

         case 'REGDLL' :
            cmd = "CMD /C REGSVR32 /S " + cmd;
            fsoCmd = true;
            break;

         case 'UNREGDLL' :
            cmd = "CMD /C REGSVR32 /U /S " + cmd;
            fsoCmd = true;
            break;

         case 'CMD' :
            cmd = "CMD /C " + cmd;
            fsoCmd = true;
            break;

         case 'INSTINF' :
            cmd = "CMD /C RUNDLL32 setupapi.dll,InstallHinfSection DefaultInstall 132 " + cmd;
            fsoCmd = true;
            break;

         case 'LAUNCHINF' :
            cmd = "CMD /C RUNDLL32 advpack.dll,LaunchINFSection " + cmd;
            fsoCmd = true;
            break;

         case 'REGEDIT' :
            if (FileExists(cmd))
            {
               if (cmd.indexOf(" ") != - 1 && cmd.substr(0, 1) != '"')
               cmd = '"'+cmd+'"';
               cmd = '"'+sysPath32+'RegEdit" /S ' + cmd;
               fsoCmd = true;
            }
            else
            cmd = getText(txtErrorRegEditFileExists);
            break;

         case 'EXTRACT' :
            var src, dst, splits;

            src = dst = cmd;
            if (cmd.indexOf('" "') != - 1)
            {
               splits = cmd.split('" "');
               src = splits[0];
               dst = splits[1];
            }
            else
            {
               if (src.substr(0, 1) == '"')
               {
                  splits = cmd.split('" ');
                  src = splits[0];
                  dst = splits[1];
               }
               else
               {
                  splits = cmd.split(' ');
                  src = splits[0];
                  dst = splits[1];
               }
            }
            src = src.replace(/\"/g,"");
            dst = dst.replace(/\"/g,"");
            cmd = '"'+wpipath+'\\Tools\\7z\\7z.exe" x "'+src+'" -aoa -o"'+dst+'"';
            fsoCmd = true;
            if (src.indexOf("*") == - 1)
            {
               if ( ! FileExists(src))
               cmd = getText(txtErrorExtractFileExists);
            }
            break;

         case 'FILECOPY' :
            cmd = "CMD /C COPY /Y " + cmd;
            fsoCmd = true;
            break;

         case 'FILEMOVE' :
            cmd = "CMD /C MOVE /Y " + cmd;
            fsoCmd = true;
            break;

         case 'RENAME' :
            cmd = "CMD /C REN " + cmd;
            fsoCmd = true;
            break;

         case 'DELETE' :
            cmd = "CMD /C DEL /F /Q " + cmd;
            fsoCmd = true;
            break;

         case 'MAKEDIR' :
            cmd = "CMD /C MD " + cmd;
            fsoCmd = true;
            break;

         case 'DIRCOPY' :
            cmd = "CMD /C XCOPY " + cmd + " /C /I /E /Y /H /R";
            fsoCmd = true;
            break;

         case 'DIRMOVE' :
            cmd = "{JSCRIPT}=MoveDirectory(\'" + cmd + "\')";
            break;

         case 'DELDIR' :
            cmd = "CMD /C RMDIR /S /Q " + cmd;
            fsoCmd = true;
            break;

         case 'RUNBG' :
            waitForIt = false;
            break;

         case 'TASKKILL' :
            cmd = "{JSCRIPT}=TerminateProcess(\"" + cmd + "\")";
            break;
		
		case 'CLOSEWINDOW':
				cmd="\"" + wpipath + "\\Tools\\WPI Tool.exe\" /Action=CloseWindow /WindowName=\"" + cmd + "\"";
				fsoCmd=true;
				break;
				
         case 'SLEEP' :
            cmd = "\"" + wpipath + "\\Tools\\Sleep.exe\"" + cmd;
            fsoCmd = true;
            break;

         case 'REBOOT' :
            cmd = "\"" + sysdir + "\\shutdown.exe\" /r /f /t " + (cmd.length > 0 ? cmd : "0");
            fsoCmd = true;
            break;

         case 'START' :
            cmd = "CMD /C START " + cmd;
            fsoCmd = true;
            break;
            
         case 'MSI': 
           var src, splits; 
                                
           src=cmd;
           if (cmd.indexOf('" "') != -1) 
           { 
             splits=cmd.split('" "'); 
             src=splits[0];   
            } 
            else 
            { 
            if (src.substr(0,1)=='"') 
            { 
               splits=cmd.split('" '); 
               src=splits[0];   
               } 
               else 
               { 
               splits=cmd.split(' '); 
               src=splits[0]; 
                      } 
                   } 
                                 
                   src=src.replace(/\"/g,""); 
                   cmd='"'+sysdir+'\\msiexec.exe" /i "'+src+'" /qn"';  
                   fsoCmd=true; 
                   break;                                
                } 
      return cmd;
   }

   if (cmd.indexOf(".cmd") != - 1 || cmd.indexOf(".bat") != - 1)
   {
      if (cmd.indexOf(" ") != - 1 && cmd.substr(0, 1) != '"')
      cmd = '"'+cmd+'"';
      cmd = '"'+sysPath32+'cmd.exe" /C ' + cmd;

      return cmd;
   }
   if (cmd.indexOf(" ") == - 1 && cmd.substr(0, 1) != '"' && cmd.indexOf(" > ")==-1)     // > needed for stdout.  "d : \program.exe" "param1" >c:\app.txt
   cmd = '"'+cmd+'"';

   return cmd;
}

function AddToInstallList(box)
{
   position = "installer.js";
   whatfunc = "AddToInstallList()";

   var newDiv = document.createElement("div");
   var objDiv = document.getElementById("Install_prog");

   newDiv.innerHTML = box;

   objDiv.appendChild(newDiv);
   divScroll.activeScroll();
}

function UpdateInstallList(div, SuccessFail)
{
   position = "installer.js";
   whatfunc = "UpdateInstallList()";

   document.getElementById(div).innerHTML = SuccessFail;
}

function ClearProgressBar()
{
   position = "installer.js";
   whatfunc = "ClearProgressBar()";
   document.getElementById("PB_Mask").style.left = "0px";
   document.getElementById("PB_Mask").style.width = "400px";
   document.getElementById("PB_Value").style.zIndex = 10;
   document.getElementById("PB_Mask").style.display = "block";
   if (ShowPercentValue)
   document.getElementById("PB_Value").innerHTML = "0%";
}

function UpdateProgressBar(value)
{
   position = "installer.js";
   whatfunc = "UpdateProgressBar()";
   value = Math.round(value);

   if (value < 0)
   value = 0;
   if (value > 100)
   value = 100;

   document.getElementById("PB_Mask").style.left = (value * 4) + "px";
   document.getElementById("PB_Mask").style.width = 400 - (value * 4) + "px";

   if (ShowPercentValue)
   document.getElementById("PB_Value").innerHTML = value + "%";
}

function SetRestartShutDown()
{
   position = "installer.js";
   whatfunc = "SetRestartShutDown()";

   if (RestartComputer)
   {
      if ( ! RestartType)
      document.getElementById("RestartShutDown").value = 1;
      else
      document.getElementById("RestartShutDown").value = 2;
   }
}

function HandleRestartShutDown()
{
   position = "installer.js";
   whatfunc = "HandleRestartShutDown()";

   RestartComputer = true;
   RestartType = 0;

   if (document.getElementById("RestartShutDown").value == 0)
   RestartComputer = false;
   if (document.getElementById("RestartShutDown").value == 1)
   RestartType = 0;
   if (document.getElementById("RestartShutDown").value == 2)
   RestartType = 1;

   WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\RestartComputer", RestartComputer == true ? 1 : 0, "REG_DWORD");
   WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\RestartType", RestartType, "REG_DWORD");
}

function DownloadFile(cmd, i, j)
{
   position = "installer.js";
   whatfunc = "DownloadFile()";

   var BAcmd = cmd, URL = "", Filename = "", Args, cmdLine = "";
   var splits;
   var lastSlash;
   var cmdName = "cmd" + j;
   var ReturnCode;

   if ( ! ConnToNet)
   {
      document.getElementById("InstallItem").innerHTML = getText(lblDownloading) + " " + URL;
      UpdateInstallList(("div" + i + "_" + j + "_" + FailNum), getText(txtInstallFailed));
      WriteLogLine(cmdName + ' ' + getText(InstallDownloadFail) + ': ' + getText(txtNoInternetConnection));

      return "";
   }

   BAcmd = cmd.replace(/{DOWNLOAD} /gi, '');
   splits = BAcmd.split(' ');
   URL = splits[0];

   splits.splice(0, 1);
   Args = splits.join(" ");

   lastSlash = URL.lastIndexOf("/");
   Filename = URL.substring(lastSlash + 1, URL.length);

   document.getElementById("InstallItem").innerHTML = getText(lblDownloading) + " " + URL;
   UpdateInstallList(("div" + i + "_" + j + "_" + FailNum), getText(txtInstallDownloading));

   if (getOSver() == "Win7" || getOSver() == "Win8" || getOSver() == "Win8.1")
   cmdLine = 'Powershell Start-BitsTransfer -Source ' + URL + ' -Destination "%TEMP%\\'+Filename+'" -TransferType Download';
   fsoCmd = true;

   if (getOSver() == "2K" || getOSver() == "XP" || getOSver() == "Vista")

   cmdLine = '"'+wpipath+'\\Tools\\BitsAdmin.exe" /transfer WPI /download /priority high ' + URL + ' "%TEMP%\\'+Filename+'"';
   fsoCmd = true;

   if (AlwaysShowOutputWindow || ShowDownloadOutput)
   fsoCmd = false;
   ReturnCode = WshShell.Run(ReplacePath(cmdLine), fsoCmd ? 0 : 1, true);
   if (ReturnCode == 0)
   WriteLogLine(cmdName + ' ' + getText(InstallDownloadSuccess) + ' (' + getText(ReturnedCode) + ' ' + ReturnCode + '): ' + URL);
   else
   WriteLogLine(cmdName + ' ' + getText(InstallDownloadFail) + ' (' + getText(ReturnedCode) + ' ' + ReturnCode + '): ' + URL);

   UpdateInstallList(("div" + i + "_" + j + "_" + FailNum), "");

   cmd = ReplacePath('"%TEMP%\\'+Filename+'" ' + Args);

   return cmd;
}

function CheckAutoLogonCount()
{
   position = "installer.js";
   whatfunc = "CheckAutoLogonCount()";

   var Count = 0;

   if ( ! MaintainAutoLogonCount)
   return;

   try
   {
      Count = RegKeyValue("HKEY_LOCAL_MACHINE\\Software\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon\\AutoLogonCount");
      Count ++ ;
      WriteRegKey("HKEY_LOCAL_MACHINE\\Software\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon\\AutoLogonCount", Count, "REG_DWORD");
   }
   catch (ex)
   {
   }

}
