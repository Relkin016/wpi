//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// Windows Post - Install Wizard
// installer_history.js
//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

function OpenHistoryFile()
{
   position = "installer_history.js";
   whatfunc = "OpenHistoryFile()";

   strFile = ReplacePath(historyDefault);
   if (ResumeInstall)
   {
      try
      {
         historyHandle = fso.OpenTextFile(strFile, 8, 0, - 2);
      }
      catch(ex)
      {
         alert(getText(CouldNotOpenHistoryFile) + "\n\n" + getText(lblFile) + ": " + strFile + "\n" + getText(lblErrorNumber) + ": " + (ex.number & 0xffff) + "\n" + getText(lblErrorDescription) + ": " + ex.description);
         ExitWPI();
      }
   }
   else
   {
      try
      {
         historyHandle = fso.CreateTextFile(strFile, true, true);
         historyHandle.WriteLine("// WPI Installation History File");
      }
      catch(ex)
      {
         alert(getText(CouldNotCreateHistoryFile) + "\n\n" + getText(lblFile) + ": " + strFile + "\n" + getText(lblErrorNumber) + ": " + (ex.number & 0xffff) + "\n" + getText(lblErrorDescription) + ": " + ex.description);

         return;
      }
   }
}

function AddHistoryEntry(box)
{
   position = "installer_history.js";
   whatfunc = "AddHistoryEntry()";

   var txt;

   if (historyHandle)
   historyHandle.Write(box);
}

function ReadHistoryEntries()
{
   position = "installer_history.js";
   whatfunc = "ReadHistoryEntries()";

   var line = new String();

   strFile = ReplacePath(historyDefault);
   if (FileExists(strFile))
   {
      try
      {
         tf = fso.OpenTextFile(strFile, 1, 0, - 2);
         line = tf.ReadLine();
         // Header line
         while(true)
         {
            line = tf.ReadLine();

            AddToInstallList(line);
         }
      }
      catch(ex)
      {
         ;

      }
      finally
      {
         try
         {
            tf.Close();
         }
         catch (ex0)
         {
            ;

         }
      }
   }
}

function DeleteHistoryFile()
{
   position = "installer_history.js"
   whatfunc = "DeleteHistoryFile()";

   strFile = ReplacePath(historyDefault);
   if (FileExists(strFile))
   {
      cmdLine = 'cmd /c del /f /q "'+strFile+'"';
      try
      {
         WshShell.Run(cmdLine, 0, true);
      }
      catch(ex)
      {
         alert(getText(CouldNotDeleteFile) + "\n\n" + getText(lblFile) + ": " + strFile + "\n" + getText(lblErrorNumber) + ": " + (ex.number & 0xffff) + "\n" + getText(lblErrorDescription) + ": " + ex.description);
      }
   }
}

function CloseHistoryFile()
{
   position = "installer_history.js";
   whatfunc = "CloseHistoryFile()";

   if (historyHandle != null)
   historyHandle.Close();
}
