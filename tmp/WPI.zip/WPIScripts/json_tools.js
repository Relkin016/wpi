//************************************************
// Windows Post-Install Wizard
// json_tools.js
//************************************************

function NewConfigEntry_JSON()
{
	position="json_tools.js";
	whatfunc="NewConfigEntry_JSON()";

}

function CopyConfigEntry_JSON()
{
	position="json_tools.js";
	whatfunc="CopyConfigEntry_JSON()";

}

function CloneConfigEntry_JSON()
{
	position="json_tools.js";
	whatfunc="CloneConfigEntry_JSON()";

}

function NewInstallerEntry_JSON()
{
	position="json_tools.js";
	whatfunc="NewInstallerEntry_JSON()";

}
