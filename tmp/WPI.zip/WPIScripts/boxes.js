//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// Windows Post - Install Wizard
// boxes.js
//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

var ShowableItems;

function preFlight()
{
   position = "boxes.js";
   whatfunc = "preFlight()";

   ShowableItems = [];
   for (var i = 1; prog[i] != null; i ++ )
   {
      ShowableItems[i] = true;
      if (cond[i] && cond[i][0])
      {
         try
         {
            if ( ! eval(unescape(ReplacePath(cond[i][0]).replace(/\\/g, "\\\\"))))
            ShowableItems[i] = false;
         }
         catch(ex)
         {
            Alert("", getText(ErrorInCondStatement) + "\n\n" + prog[i] + "\n" + cond[i] + "\n\n" + getText(TreatingAsFalseCond), getText(lblOK), "", 2, 0, 0, 0);
            ShowableItems[i] = false;
         }
      }
   }
}

function fillBoxes_1()
{
   position = "boxes.js";
   whatfunc = "fillBoxes_1()";

   var oldcat = "";
   var col = 1, pages = 1, pi = 0, winheight = screen.height;
   var DoGray;
   var lh;
   var firstCat = true;
   var TableWidth;

   if (CatsDefined())
   SortPrograms();

   if (top.status != "")
   winheight = top.status;
   Cols = Math.round((document.getElementById("layerboxes").offsetHeight / 3 * 4) / 320, 0);
   if (winheight == 600)
   Cols = ((NumCols != null) ? Math.min(NumCols, 2) : 2);
   if (winheight >= 768 && NumCols != null)
   Cols = NumCols;
   ColWidth = (Math.round(document.getElementById("layerboxes").offsetWidth / Cols, 0)) - 20;
   TableWidth = Math.floor(document.getElementById("layerboxes").offsetWidth);

   if (FontHeight < 14)
   lh = 20;
   else if (FontHeight == 14)
   lh = 22;
   else if (FontHeight == 15 || FontHeight == 16)
   lh = 24;
   else if (FontHeight == 17)
   lh = 27;
   else if (FontHeight == 18)
   lh = 29;
   else if (FontHeight == 19)
   lh = 30;
   else if (FontHeight == 20)
   lh = 32;
   else
   lh = 32;
   maxentries += Math.round(document.getElementById("layerboxes").offsetHeight / (lh + 2), 0);

   tabs ++ ;
   boxTxt = "";
   boxTxt += '<a name="#pg1"></a>';
   boxTxt += '<table border="0" width="'+TableWidth+'" height="100%" cellspacing="10" cellpadding="0"><tr><td width="'+ColWidth+'px" height="100%" valign="top" nowrap>';

   preFlight();

   for (var i = 1; prog[i] != null; i ++ )
   {
      if ( ! ShowableItems[i])
      continue;

      DoGray = false;
      if (gcond[i] && gcond[i][0])
      {
         var d = unescape(ReplacePath(gcond[i][0]).replace(/\\/g, "\\\\"));

         try
         {
            DoGray = eval(d) ? 1 : 0;
         }
         catch(ex)
         {
            Alert("", getText(ErrorInCondStatement) + "\n\n" + prog[i] + "\n" + gcond[i] + "\n\n" + getText(TreatingAsFalseCond), getText(lblOK), "", 2, 0, 0, 0);
            continue;
         }
      }

      if (cat[i] && cat[i][0] != oldcat) // insert new category header
      {
         if (DontSplitCats && winheight >= 600)
         {
            var ProgsInCat = 0;

            for (var j = 1; prog[j]; j ++ )
            if (cat[j] && cat[j] == cat[i][0] && ShowableItems[j])
            ProgsInCat ++ ;

            if ((pi + catheight + ProgsInCat) > maxentries)
            {
               if (col < Cols)
               {
                  boxTxt += '</td><td width="'+ColWidth+'px" height="100%" valign="top" nowrap>';
                  col ++ ;
                  firstCat = true;
               }
               else
               {
                  boxTxt += backNext(lasti, true, Cols);
                  pages ++ ;
                  col = 1;
                  firstCat = true;
               }
               pi = 1;
            }
         }
         // insert category and label
         if ( ! firstCat)
         boxTxt += '<img src="../Common/imgs/spacer.gif" border="0" width="10" height="15">';
         else
         firstCat = false;

         boxTxt += '<table border="0" width="100%" cellpadding="0" cellspacing="0" class="categoryBg">';
         boxTxt += '<tr><td>';
         // -- checkbox --
         boxTxt += '<input type="checkbox" id="Cat'+cat[i]+'" ';
         boxTxt += 'name="'+cat[i]+'" ';
         if (DisableCatCheckBoxes)
         boxTxt += 'style="display:none;" ';
         boxTxt += 'onClick="checkCategory(\''+cat[i]+'\');" />';
         // -- label --
         boxTxt += '</td><td style="width:6px;">';
         boxTxt += '<img src="../Common/imgs/spacer.gif" border="0" width="6" height="1">';
         boxTxt += '</td><td style="width:100%; height:100%;">';
         boxTxt += '<div style="width:'+(ColWidth-25)+'px; text-align:left; white-space:nowrap; text-overflow:ellipsis; overflow:hidden;">';
         boxTxt += '<label class="category" ';
         boxTxt += 'for="'+cat[i][0]+'" ';
         boxTxt += 'onClick="toggleChecked(\''+cat[i]+'\'); checkCategory(\''+cat[i]+'\');" ';
         boxTxt += '>' + GetCategoryTranslation(cat[i]) + '</label>';
         boxTxt += '</div>';
         // ellipsis
         boxTxt += '</td></tr><tr><td colspan="3" style="height:5px;">';
         boxTxt += '<hr class="hruleCategory" align="left">';
         boxTxt += '</td></tr></table>';
         oldcat = cat[i][0];
         pi += catheight;
      }

      if (CatsDefined() && pi == 1)
      {
         boxTxt += '<div id="'+cat[i]+'" class="category">' + (col == 1 ? oldcat + '\n<hr class="hruleCategory" align="left">' : '<img src="../Common/imgs/spacer.gif" border="0" width="10" height="1">') + '</div>';
         pi += catheight;
      }

      // insert checkbox and label
      // -- checkbox --
      boxTxt += '<div style="width:'+ColWidth+'px;">';
      // wrapper
      boxTxt += '<div style="width:'+ColWidth+'px; white-space:nowrap; text-overflow:ellipsis; overflow:hidden;">';
      boxTxt += '<input type="checkbox" id="chkbox'+i+'"';
      boxTxt += 'onClick="checkDeps('+i+'); checkCategory('+i+');"';
      boxTxt += 'onMouseOver="qdh(prog['+i+'],desc['+i+'],Style[0]);" ';
      boxTxt += 'onMouseOut="htm();"';
      if ( ! DoGray && forc[i] != null && forc[i] == 'yes')
      boxTxt += ' checked';
      if ((DoGray && DisableIfDoGray) || (forc[i] != null && forc[i] == 'yes'))
      boxTxt += ' disabled';
      boxTxt += ' />';
      // -- label --
      boxTxt += '<img src="../Common/imgs/spacer.gif" border="0" width="7" height="1">';
      boxTxt += '<label id="lbl'+i+'" ';
      if (forc[i] != null && forc[i] == 'yes')
      boxTxt += 'class="forceTxt" value="Forced"';
      else if (DoGray)
      boxTxt += 'class="grayTxt" value="IsGray"';
      else
      boxTxt += 'class="txt" value="Normal"';
      boxTxt += ' for="'+uid[i]+'" ';
      boxTxt += 'onClick="toggleChecked('+i+'); checkDeps('+i+'); checkCategory('+i+');" ';
      boxTxt += 'onMouseOver="qdh(prog['+i+'],desc['+i+'],Style[0]);" ';
      boxTxt += 'onMouseOut="htm();"';
      boxTxt += '>' + prog[i] + '</label>';
      boxTxt += '</div>';
      // ellipsis
      boxTxt += '</div>';
      // wrapper

      // 		prog[i][0] = noTags(prog[i][0]); // remove HTML tag from program defintion

      if (prog[i + 1] != null) // new column ? , handle different resolutions
      {
         pi ++ ;
         if ((winheight >= 600) && pi > maxentries)
         {
            if (col < Cols)
            {
               boxTxt += '</td><td width="'+ColWidth+'px" height="100%" valign="top" nowrap>';
               col ++ ;
               firstCat = false;
            }
            else
            {
               boxTxt += backNext(lasti, true, Cols);
               pages ++ ;
               col = 1;
               firstCat = false;
               // pi = 0;
            }
            pi = 1;
         }
      }
   }

   if (lasti > 1) // insert scroll buttons on last page
   {
      previ = lasti - 1;
      if (previ != 0)
      boxTxt += backNext(lasti, false, Cols);
   }
   boxTxt += '</td></tr></table>';
   tabs -- ;

   document.getElementById("layerboxes").innerHTML = boxTxt;

   if (lasti > 1)
   {
      for (i = 2; i < lasti; i ++ )
      document.getElementById("last" + i).href = "#pg" + (lasti - 1);
   }
}

function fillBoxes_2()
{
   position = "boxes.js";
   whatfunc = "fillBoxes_2()";

   var oldcat = "";
   var col = 1, pages = 1, pi = 0, winheight = screen.height;
   var DoGray;
   var firstCat = true;
   var TableWidth;

   if (CatsDefined())
   SortPrograms();

   if (top.status != "")
   winheight = top.status;
   Cols = Math.round((document.getElementById("layerboxes").offsetHeight / 3 * 4) / 320, 0);
   if (winheight == 600)
   Cols = ((NumCols != null) ? Math.min(NumCols, 2) : 2);
   if (winheight >= 768 && NumCols != null)
   Cols = NumCols;
   ColWidth = (Math.round(document.getElementById("layerboxes").offsetWidth / Cols, 0)) - 20;
   TableWidth = Math.floor(document.getElementById("layerboxes").offsetWidth);
   maxentries = Math.round(document.getElementById("layerboxes").offsetHeight / 50, 0);

   tabs ++ ;
   boxTxt = "";
   boxTxt += '<a name="#pg1"></a>';
   boxTxt += '<table border="0" width="'+TableWidth+'" height="100%" cellspacing="10" cellpadding="0"><tr><td width="'+ColWidth+'px" height="100%" valign="top" nowrap>';

   preFlight();

   for (var i = 1; prog[i] != null; i ++ )
   {
      if ( ! ShowableItems[i])
      continue;

      DoGray = false;
      if (gcond[i] && gcond[i][0])
      {
         var d = unescape(ReplacePath(gcond[i][0]).replace(/\\/g, "\\\\"));

         try
         {
            DoGray = eval(d) ? 1 : 0;
         }
         catch(ex)
         {
            Alert("", getText(ErrorInCondStatement) + "\n\n" + prog[i] + "\n" + gcond[i] + "\n\n" + getText(TreatingAsFalseCond), getText(lblOK), "", 2, 0, 0, 0);
            continue;
         }
      }

      if (cat[i] && cat[i][0] != oldcat) // insert new category header
      {
         if (DontSplitCats && winheight >= 600)
         {
            var ProgsInCat = 0;

            for (var j = 1; prog[j]; j ++ )
            if (cat[j] && cat[j] == cat[i][0] && ShowableItems[j])
            ProgsInCat ++ ;

            if ((pi + catheight + ProgsInCat) > maxentries)
            {
               if (col < Cols)
               {
                  boxTxt += '</td><td width="'+ColWidth+'px" height="100%" valign="top" nowrap>';
                  col ++ ;
                  firstCat = true;
               }
               else
               {
                  boxTxt += backNext(lasti, true, Cols);
                  pages ++ ;
                  col = 1;
                  firstCat = true;
               }
               pi = 1;
            }
         }
         // insert category and label
         if ( ! firstCat)
         boxTxt += '<img src="../Common/imgs/spacer.gif" border="0" width="10" height="15">';
         else
         firstCat = false;

         boxTxt += '<table border="0" width="100%" cellpadding="0" cellspacing="0" class="categoryBg">';
         boxTxt += '<tr><td>';
         // -- checkbox --
         boxTxt += '<input type="checkbox" id="Cat'+cat[i]+'" ';
         boxTxt += 'name="'+cat[i]+'" ';
         if (DisableCatCheckBoxes)
         boxTxt += 'style="display:none;" ';
         boxTxt += 'onClick="checkCategory(\''+cat[i]+'\');" />';
         // -- label --
         boxTxt += '</td><td style="width:6px;">';
         boxTxt += '<img src="../Common/imgs/spacer.gif" border="0" width="6" height="1">';
         boxTxt += '</td><td style="width:100%; height:100%;">';
         boxTxt += '<div style="width:'+(ColWidth-25)+'px; text-align:left; white-space:nowrap; text-overflow:ellipsis; overflow:hidden;">';
         boxTxt += '<label class="category" ';
         boxTxt += 'for="'+cat[i][0]+'" ';
         boxTxt += 'onClick="toggleChecked(\''+cat[i]+'\'); checkCategory(\''+cat[i]+'\');" ';
         boxTxt += '>' + GetCategoryTranslation(cat[i]) + '</label>';
         boxTxt += '</div>';
         // ellipsis
         boxTxt += '</td></tr><tr><td colspan="3" style="height:5px;">';
         boxTxt += '<hr class="hruleCategory" align="left">';
         boxTxt += '</td></tr></table>';
         oldcat = cat[i][0];
         pi += catheight;
      }

      if (CatsDefined() && pi == 1)
      {
         boxTxt += '<div id="'+cat[i]+'" class="category">' + (col == 1 ? oldcat + '\n<hr class="hruleCategory" align="left">' : '<img src="../Common/imgs/spacer.gif" border="0" width="10" height="1">') + '</div>';
         pi += catheight;
      }

      // insert checkbox and label
      // -- checkbox --
      boxTxt += '<div style="width:'+ColWidth+'px;">';
      // wrapper
      boxTxt += '<table border="0" height="50" cellpadding="0" cellspacing="0"><tr><td rowspan="2">';
      boxTxt += '<input type="checkbox" id="chkbox'+i+'"';
      boxTxt += 'onClick="checkDeps('+i+'); checkCategory('+i+');"';
      boxTxt += 'onMouseOver="qdh(prog['+i+'],desc['+i+'],Style[0]);" ';
      boxTxt += 'onMouseOut="htm();"';
      if ( ! DoGray && forc[i] != null && forc[i] == 'yes')
      boxTxt += ' checked';
      if ((DoGray && DisableIfDoGray) || (forc[i] != null && forc[i] == 'yes'))
      boxTxt += ' disabled';
      boxTxt += ' />';
      boxTxt += '</td><td rowspan="2" style="height:100%;">';
      // -- logo --
      boxTxt += '<img src="../Common/imgs/spacer.gif" border="0" width="7" height="1">';
      boxTxt += '<a href; ';
      boxTxt += 'onClick="toggleChecked('+i+'); checkDeps('+i+'); checkCategory('+i+');" ';
      boxTxt += 'onMouseOver="qdh(prog['+i+'],desc['+i+'],Style[0]);" ';
      boxTxt += 'onMouseOut="htm();">';
      if (picf[i] != null)
      {
         var pp = ReplacePath(picf[i]);
         pp = pp.replace(wpipath, "..").replace(/\\/gi,"/").replace(/\"/gi,'');
         boxTxt += '<img src="'+pp+'" border="0" width="32" height="32">';
      }
      else
      {
         boxTxt += '<img src="../Graphics/Logos/InstallPackage.png" border="0" width="32" height="32">';
      }
      boxTxt += '</a>';
      boxTxt += '<img src="../Common/imgs/spacer.gif" border="0" width="10" height="1">';
      boxTxt += '</td><td height="55%" valign="bottom"><div style="width:'+(ColWidth-70)+'px; white-space:nowrap; text-overflow:ellipsis; overflow:hidden;">';
      // -- label --
      boxTxt += '<label id="lbl'+i+'" ';
      if (forc[i] != null && forc[i] == 'yes')
      boxTxt += 'class="forceTxt_logo" value="Forced"';
      else if (DoGray)
      boxTxt += 'class="grayTxt_logo" value="IsGray"';
      else
      boxTxt += 'class="txt_logo" value="Normal"';
      boxTxt += ' for="'+uid[i]+'" ';
      boxTxt += 'onClick="toggleChecked('+i+'); checkDeps('+i+'); checkCategory('+i+');" ';
      boxTxt += 'onMouseOver="qdh(prog['+i+'],desc['+i+'],Style[0]);" ';
      boxTxt += 'onMouseOut="htm();" ';
      boxTxt += '>' + prog[i] + '</label>';
      boxTxt += '</div></td></tr><tr><td height="45%" valign="top"><div style="width:'+(ColWidth-70)+'px; white-space:nowrap; text-overflow:ellipsis; overflow:hidden;">';
      boxTxt += '<span class="shortDescTxt_logo">' + (shortdesc[i] != null ? shortdesc[i] : '&nbsp;') + '</span>';
      boxTxt += '</div></td></tr></table>';
      boxTxt += '</div>';
      // wrapper

      if (prog[i + 1] != null) // new column ? , handle different resolutions
      {
         pi ++ ;
         if ((winheight >= 600) && pi > maxentries)
         {
            if (col < Cols)
            {
               boxTxt += '</td><td width="'+ColWidth+'px" height="100%" valign="top" nowrap>';
               col ++ ;
               firstCat = false;
            }
            else
            {
               boxTxt += backNext(lasti, true, Cols);
               pages ++ ;
               col = 1;
               firstCat = false;
               // pi = 0;
            }
            pi = 1;
         }
      }
   }

   if (lasti > 1) // insert scroll buttons on last page
   {
      previ = lasti - 1;
      if (previ != 0)
      boxTxt += backNext(lasti, false, Cols);
   }
   boxTxt += '</td></tr></table>';
   tabs -- ;

   document.getElementById("layerboxes").innerHTML = boxTxt;

   if (lasti > 1)
   {
      for (i = 2; i < lasti; i ++ )
      document.getElementById("last" + i).href = "#pg" + (lasti - 1);
   }
}

function backNext(li, next, Cols)
{
   position = "boxes.js";
   whatfunc = "backNext()";

   var txt = new String();
   txt = "";
   var txtLen = 0, text;
   var colwidth = Math.round(100 / Cols, 0);

   var previ = li - 1;
   var nexti = li + 1;

   txt += '</td></tr><tr><td colspan="'+Cols+'" style="height:1em;">';
   // match 1

   txt += '<table border="0" width="100%" height="100%" cellspacing="0" cellpadding="0">';
   // match 2
   txt += '<tr><td><hr class="hruleBackNext"></td>';

   txtLen = getText(lblFirst)[0].length;
   if (previ != 0)
   txt += '<td class="backNext" align="center" style="width:'+txtLen+'em;"><a class="backNext" href="#pg1">' + getText(lblFirst) + '</a></td>';
   else
   txt += '<td class="backNext" style="width:'+txtLen+'em;"><hr class="hruleBackNext"></td>';

   txt += '<td width=50><hr class="hruleBackNext"></td>';

   txtLen = getText(lblFirst)[0].length;
   if (previ != 0)
   txt += '<td class="backNext" align="center" style="width:'+txtLen+'em;"><a class="backNext" href="#pg'+previ+'">' + getText(boxPrevious) + '</a></td>';
   else
   txt += '<td class="backNext" style="width:'+txtLen+'em;"><hr class="hruleBackNext"></td>';

   txt += '<td width=50><hr class="hruleBackNext"></td>';

   txtLen = getText(boxNext)[0].length;
   if (next)
   txt += '<td class="backNext" align="center" style="width:'+txtLen+'em;"><a class="backNext" href="#pg'+nexti+'">' + getText(boxNext) + '</a></td>';
   else
   txt += '<td class="backNext" style="width:'+txtLen+'em;"><hr class="hruleBackNext"></td>';

   txt += '<td width=50><hr class="hruleBackNext"></td>';

   txtLen = getText(lblLast)[0].length;
   if (next)
   txt += '<td class="backNext" align="center" style="width:'+txtLen+'em;"><a id="last'+ nexti +'" class="backNext" href="#pgX">' + getText(lblLast) + '</a></td>';
   else
   txt += '<td class="backNext" style="width:'+txtLen+'em;"><hr class="hruleBackNext"></td>';

   txt += '<td width=50><hr class="hruleBackNext"></td>';

   txt += '<td><hr class="hruleBackNext"></td>';
   // center
   txt += '</tr></table>';
   // match 2

   txt += '</td></tr></table>';
   // match 1

   if (next)
   {
      txt += '<a name="#pg'+nexti+'"></a>';
      txt += '<table border="0" width="100%" height="100%" cellspacing="10" cellpadding="0"><tr><td width="'+colwidth+'%" height="100%" valign="top" nowrap>';
   }
   lasti = nexti;

   return txt;
}

function fillBoxes_3()
{
   position = "boxes.js";
   whatfunc = "fillBoxes_3()";

   var DoGray;
   var NewCat = false;
   var TableWidth;

   if (CatsDefined())
   SortPrograms();

   CurrentCat = "***";
   ColWidth = 225;

   boxTxt = "";
   boxTxt += '<table border="0" width="100%" cellspacing="10" cellpadding="10"><tr><td id="test0"></td></tr></table>';
   document.getElementById("layerboxes").innerHTML = boxTxt;
   TableWidth = Math.floor(document.getElementById("test0").offsetWidth - 20);
   numCols = Math.floor((document.getElementById("test0").offsetWidth - 20) / ColWidth);
   document.getElementById("layerboxes").innerHTML = "";

   boxTxt = "";
   boxTxt += '<table border="0" width="'+TableWidth+'" cellspacing="0" cellpadding="10"><tr><td>';
   // padding
   boxTxt += '<table border="0" width="100%" cellspacing="0" cellpadding="0">';

   preFlight();

   for (var i = 1; prog[i] != null; i ++ )
   {
      if ( ! ShowableItems[i])
      {
         CheckForLastItem(i);
         continue;
      }

      DoGray = false;
      if (gcond[i] && gcond[i][0])
      {
         var d = unescape(ReplacePath(gcond[i][0]).replace(/\\/g, "\\\\"));

         try
         {
            DoGray = eval(d) ? 1 : 0;
         }
         catch(ex)
         {
            Alert("", getText(ErrorInCondStatement) + "\n\n" + prog[i] + "\n" + gcond[i] + "\n\n" + getText(TreatingAsFalseCond), getText(lblOK), "", 2, 0, 0, 0);
            CheckForLastItem(i);
            continue;
         }
      }

      if (cat[i][0] != CurrentCat)
      {
         boxTxt += '<tr>';
         boxTxt += '<td style="width:'+TableWidth+'px;">';
         boxTxt += '<div class="categoryBox">';
         boxTxt += '<b class="b1"></b><b class="b2"></b><b class="b3"></b><b class="b4"></b>';
         boxTxt += '<div class="boxcontent">';
         boxTxt += '<table border="0" width="'+TableWidth+'" cellspacing="0" cellpadding="0">';
         boxTxt += '<tr>';
         boxTxt += '<td>';
         boxTxt += '<input type="checkbox" id="Cat'+cat[i]+'" ';
         if (DisableCatCheckBoxes)
         boxTxt += 'style="display:none;" ';
         boxTxt += 'name="'+cat[i]+'" ';
         boxTxt += 'onClick="checkCategory(\''+cat[i]+'\');" />';
         boxTxt += '</td>';
         boxTxt += '<td style="width:100%;">';
         boxTxt += '<div style="width:100%; text-align:left; white-space:nowrap; text-overflow:ellipsis; overflow:hidden;">';
         if (DisableCatCheckBoxes)
         boxTxt += '<img src="../Common/imgs/spacer.gif" border="0" width="4" height="1">';
         boxTxt += '<label class="category" ';
         boxTxt += 'for="'+cat[i]+'" ';
         if ( ! DisableCatCheckBoxes)
         boxTxt += 'onClick="toggleChecked(\''+cat[i]+'\'); checkCategory(\''+cat[i]+'\');" ';
         boxTxt += '>' + GetCategoryTranslation(cat[i]) + '</label>';
         boxTxt += '</div>';
         // ellipsis
         boxTxt += '</td>';
         boxTxt += '</tr>';
         boxTxt += '</table>';
         boxTxt += '</div>';
         boxTxt += '<b class="b4b"></b><b class="b3b"></b><b class="b2b"></b><b class="b1b"></b>';
         boxTxt += '</td>';
         boxTxt += '</tr>';

         CurrentCat = cat[i];
         NewCat = true;
         i -- ;
      }
      else
      {
         if (NewCat)
         {

            boxTxt += '<tr>';
            boxTxt += '<td style="width:'+TableWidth+'px;">';
            boxTxt += '<table border="0" width="100%" cellspacing="5" cellpadding="0">';
            boxTxt += '<tr>';
            NewCat = false;
            Cols = 1;
         }

         if (Cols > numCols)
         {
            boxTxt += '</tr><tr>';
            Cols = 1;
         }
         boxTxt += '<td style="width:'+ColWidth+'px;">';


         boxTxt += '<div style="width:'+ColWidth+'px;">';
         // wrapper
         boxTxt += '<div style="width:'+ColWidth+'px; white-space:nowrap; text-overflow:ellipsis; overflow:hidden;">';
         boxTxt += '<input type="checkbox" id="chkbox'+i+'"';
         boxTxt += 'onClick="checkDeps('+i+'); checkCategory('+i+');"';
         boxTxt += 'onMouseOver="qdh(prog['+i+'],desc['+i+'],Style[0]);" ';
         boxTxt += 'onMouseOut="htm();"';
         if ( ! DoGray && forc[i] != null && forc[i] == 'yes')
         boxTxt += ' checked';
         if ((DoGray && DisableIfDoGray) || (forc[i] != null && forc[i] == 'yes'))
         boxTxt += ' disabled';
         boxTxt += ' />';
         // -- label --
         boxTxt += '<img src="../Common/imgs/spacer.gif" border="0" width="7" height="1">';
         boxTxt += '<label id="lbl'+i+'" ';
         if (forc[i] != null && forc[i] == 'yes')
         boxTxt += 'class="forceTxt" value="Forced"';
         else if (DoGray)
         boxTxt += 'class="grayTxt" value="IsGray"';
         else
         boxTxt += 'class="txt" value="Normal"';
         boxTxt += ' for="'+uid[i]+'" ';
         boxTxt += 'onClick="toggleChecked('+i+'); checkDeps('+i+'); checkCategory('+i+');" ';
         boxTxt += 'onMouseOver="qdh(prog['+i+'],desc['+i+'],Style[0]);" ';
         boxTxt += 'onMouseOut="htm();" ';
         boxTxt += '>' + prog[i] + '</label>';
         boxTxt += '</div>';
         // ellipsis
         boxTxt += '</div>';
         // wrapper

         boxTxt += '</td>';
         Cols ++ ;

         CheckForLastItem(i);
      }
   }
   boxTxt += '</table>';
   boxTxt += '</td></tr></table>';
   // padding

   document.getElementById("layerboxes").innerHTML = boxTxt;
}

function fillBoxes_4()
{
   position = "boxes.js";
   whatfunc = "fillBoxes_4()";

   var DoGray;
   var NewCat = false;
   var TableWidth;

   if (CatsDefined())
   SortPrograms();

   CurrentCat = "***";
   ColWidth = 225;

   boxTxt = "";
   boxTxt += '<table border="0" width="100%" cellspacing="10" cellpadding="10"><tr><td id="test0"></td></tr></table>';
   document.getElementById("layerboxes").innerHTML = boxTxt;
   TableWidth = Math.floor(document.getElementById("test0").offsetWidth - 20);
   numCols = Math.floor((document.getElementById("test0").offsetWidth - 20) / ColWidth);
   document.getElementById("layerboxes").innerHTML = "";

   boxTxt = "";
   boxTxt += '<table border="0" width="'+TableWidth+'" cellspacing="0" cellpadding="10"><tr><td>';
   // padding
   boxTxt += '<table border="0" width="100%" cellspacing="0" cellpadding="0">';

   preFlight();

   for (var i = 1; prog[i] != null; i ++ )
   {
      if ( ! ShowableItems[i])
      {
         CheckForLastItem(i);
         continue;
      }

      SkipCheck = false;

      DoGray = false;
      if (gcond[i] && gcond[i][0])
      {
         var d = unescape(ReplacePath(gcond[i][0]).replace(/\\/g, "\\\\"));

         try
         {
            DoGray = eval(d) ? 1 : 0;
         }
         catch(ex)
         {
            Alert("", getText(ErrorInCondStatement) + "\n\n" + prog[i] + "\n" + gcond[i] + "\n\n" + getText(TreatingAsFalseCond), getText(lblOK), "", 2, 0, 0, 0);
            CheckForLastItem(i);
            continue;
         }
      }

      if (cat[i][0] != CurrentCat)
      {
         boxTxt += '<tr>';
         boxTxt += '<td style="width:'+TableWidth+'px;">';
         boxTxt += '<div class="categoryBox">';
         boxTxt += '<b class="b1"></b><b class="b2"></b><b class="b3"></b><b class="b4"></b>';
         boxTxt += '<div class="boxcontent">';

         boxTxt += '<table border="0" width="'+TableWidth+'" cellspacing="0" cellpadding="0">';
         boxTxt += '<tr>';
         boxTxt += '<td>';
         boxTxt += '<input type="checkbox" id="Cat'+cat[i]+'" ';
         if (DisableCatCheckBoxes)
         boxTxt += 'style="display:none;" ';
         boxTxt += 'name="'+cat[i]+'" ';
         boxTxt += 'onClick="checkCategory(\''+cat[i]+'\');" />';
         boxTxt += '</td>';
         boxTxt += '<td style="width:100%;">';
         boxTxt += '<div style="width:100%; text-align:left; white-space:nowrap; text-overflow:ellipsis; overflow:hidden;">';
         if (DisableCatCheckBoxes)
         boxTxt += '<img src="../Common/imgs/spacer.gif" border="0" width="4" height="1">';
         boxTxt += '<label class="category_logo" ';
         boxTxt += 'for="'+cat[i]+'" ';
         if ( ! DisableCatCheckBoxes)
         boxTxt += 'onClick="toggleChecked(\''+cat[i]+'\'); checkCategory(\''+cat[i]+'\');" ';
         boxTxt += '>' + GetCategoryTranslation(cat[i]) + '</label>';
         boxTxt += '</div>';
         // ellipsis
         boxTxt += '</td>';
         boxTxt += '</tr>';
         boxTxt += '</table>';

         boxTxt += '</div>';
         boxTxt += '<b class="b4b"></b><b class="b3b"></b><b class="b2b"></b><b class="b1b"></b>';
         boxTxt += '</td>';
         boxTxt += '</tr>';

         CurrentCat = cat[i];
         NewCat = true;
         i -- ;
      }
      else
      {
         if (NewCat)
         {

            boxTxt += '<tr>';
            boxTxt += '<td style="width:'+TableWidth+'px;">';
            boxTxt += '<table border="0" width="100%" cellspacing="10" cellpadding="0">';
            boxTxt += '<tr>';
            NewCat = false;
            Cols = 1;
         }

         if (Cols > numCols)
         {
            boxTxt += '</tr><tr>';
            Cols = 1;
         }
         boxTxt += '<td style="width:'+ColWidth+'px;">';


         boxTxt += '<div id="box'+i+'" style="width:'+ColWidth+'px;">';
         // wrapper

         if (forc[i] != null && forc[i] == 'yes')
         boxTxt += '<div class="forcedBox">';
         else if (DoGray && ! DisableIfDoGray)
         boxTxt += '<div class="selectedBox">';
         // not grayedBox......got me stumped.
         else if (DoGray && DisableIfDoGray)
         boxTxt += '<div class="disabledBox">';
         else
         boxTxt += '<div class="normalBox">';
         boxTxt += '<b class="b1"></b><b class="b2"></b><b class="b3"></b><b class="b4"></b>';
         boxTxt += '<div class="boxcontent">';
         boxTxt += '<a href; ';
         boxTxt += 'onMouseOut="htm();" ';
         boxTxt += 'onMouseOver="qdh(prog['+i+'],desc['+i+'],Style[0]);" ';
         boxTxt += 'onClick="toggleChecked('+i+'); checkDeps('+i+'); checkCategory('+i+');"';
         boxTxt += '>';
         boxTxt += '<table border="0" width="218" cellpadding="0" cellspacing="0"><tr><td rowspan="2">';
         boxTxt += '<input type="checkbox" id="chkbox'+i+'"';
         boxTxt += ' style="display:none;"';
         if ( ! DoGray && forc[i] != null && forc[i] == 'yes')
         boxTxt += ' checked';
         if ((DoGray && DisableIfDoGray) || (forc[i] != null && forc[i] == 'yes'))
         boxTxt += ' disabled';
         boxTxt += ' />';
         boxTxt += '</td><td rowspan="2" style="height:100%;">';
         // -- logo --
         boxTxt += '<img src="../Common/imgs/spacer.gif" border="0" width="4" height="1">';
         if (picf[i] != null)
         {
            var pp = ReplacePath(picf[i]);
            pp = pp.replace(wpipath, "..").replace(/\\/gi,"/").replace(/\"/gi,'');
            boxTxt += '<img src="'+pp+'" border="0" width="32" height="32">';
         }
         else
         {
            boxTxt += '<img src="../Graphics/Logos/InstallPackage.png" border="0" width="32" height="32">';
         }
         boxTxt += '<img src="../Common/imgs/spacer.gif" border="0" width="5" height="1">';
         boxTxt += '</td><td valign="bottom"><div style="width:'+(ColWidth-50)+'px; white-space:nowrap; text-overflow:ellipsis; overflow:hidden;">';
         // -- label --
         boxTxt += '<label id="lbl'+i+'" ';
         if (forc[i] != null && forc[i] == 'yes')
         boxTxt += 'class="forceTxt_logo" value="Forced"';
         else if (DoGray)
         boxTxt += 'class="grayTxt_logo" value="IsGray"';
         else
         boxTxt += 'class="txt_logo" value="Normal"';
         boxTxt += '>' + prog[i] + '</label>';
         boxTxt += '</div></td></tr><tr><td valign="top"><div style="width:'+(ColWidth-50)+'px; white-space:nowrap; text-overflow:ellipsis; overflow:hidden;">';
         boxTxt += '<span class="shortDescTxt_logo">' + (shortdesc[i] != null ? shortdesc[i] : '&nbsp;') + '</span>';
         boxTxt += '</div></td></tr></table>';
         boxTxt += '</a>';
         boxTxt += '</div>';
         boxTxt += '<b class="b4b"></b><b class="b3b"></b><b class="b2b"></b><b class="b1b"></b>';
         boxTxt += '</div>';

         boxTxt += '</div>';
         // wrapper

         boxTxt += '</td>';
         Cols ++ ;

         CheckForLastItem(i);
      }
   }
   boxTxt += '</table>';
   boxTxt += '</td></tr></table>';
   // padding

   document.getElementById("layerboxes").innerHTML = boxTxt;
}

function CheckForLastItem(i)
{
   position = "boxes.js";
   whatfunc = "CheckForLastItem()";

   if (cat[i + 1] != null && cat[i + 1][0] != CurrentCat)
   {
      if (Cols <= numCols)
      {
         for (var k = Cols; k <= numCols; k ++ )
         {
            boxTxt += '<td style="width:'+ColWidth+'px;"></td>';
         }
      }

      boxTxt += '</tr>';
      boxTxt += '</table>';
      boxTxt += '</td>';
      boxTxt += '</tr>';
   }

   if (cat[i + 1] == null)
   {
      if (Cols <= numCols)
      {
         for (var k = Cols; k <= numCols; k ++ )
         {
            boxTxt += '<td style="width:'+ColWidth+'px;"></td>';
         }
      }

      boxTxt += '</tr>';
      boxTxt += '</table>';
      boxTxt += '</td>';
      boxTxt += '</tr>';
   }
}
