//************************************************
// Windows Post-Install Wizard
// api.js
//************************************************

function WPIReady()
{
	position="api.js";
	whatfunc="WPIReady()";

// Globals
	SetupWPI();

// ReadMe
	strFile=wpipath+"\\ReadMe.txt";
	if (FileExists(strFile) && !isCorporate && !iseuDock)
		document.getElementById("ReadMeBtn").style.display="block";

// Manual Button
    strFile=wpipath+"\\Manual\\Manual.txt";
	if (FileExists(strFile) && !isCorporate && !iseuDock)
		document.getElementById("ManualBtn").style.display="block";
		
// Main
	ShowMain();

	if (Timer)
	{
		if (FileExists(wpipath+"\\Themes\\"+Theme+"\\ProgressBar.png"))
			document.getElementById("Timer_bar").style.backgroundImage="url('"+wpipath+"\\Themes\\"+Theme+"\\ProgressBar.png')";
		else
			document.getElementById("Timer_bar").style.backgroundImage="url('../Common/imgs/ProgressBars/"+ProgBarsSkin+".png')";
		startInterval();
	}
	else
		stopInterval();

	if (WindowStartingState != "minimize")
		window.focus();

// Show theme
	if (ThemeType=="Windows" || ThemeType=="WindowsFramed" || ThemeType=="euDock")
		document.getElementById("wrapper").style.visibility="visible";

	if (RegKeyValue("HKEY_CURRENT_USER\\Software\\WPI\\SndWPIStartCB"))
		PlaySound(RegKeyValue("HKEY_CURRENT_USER\\Software\\WPI\\SndWPIStart"));

// Updates
	CheckForNeededUpdates();
}

function SetupWPI()
{
	position="api.js";
	whatfunc="SetupWPI()";

	if (checkOL)						// This has to go here!
		CheckOnLoad=checkOL;

	WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\ShowPercentValue",ShowPercentValue==true ? 1 : 0,"REG_DWORD");	// This has to go here!

	if (DoCleanUp)
		CleanUpAbort();

//	CheckIfUsingActiveDirectory();
	if (AllowCheckForInternet)
		CheckForInternet();

	if (WindowStartingState=="normal")
		sizer();
	FontHeight=CheckTxtHeight();

	GetUserInfo();

// Theme
	SetupTheme();
	HandleSelectMultiDefaults();
	HandleShowExtraButtons();

// Layout items
	if (LayoutStyle==4)
		fillBoxes_4();
	else if (LayoutStyle==3)
		fillBoxes_3();
	else if (LayoutStyle==2)
		fillBoxes_2();
	else
		fillBoxes_1();
	FirstCount=true;
	check(CheckOnLoad);
	FirstCount=false;
	CountChecks();

// Color Picker language
	dhtmlxColorPickerLangModules["custom"] = {
		langname: "custom",
		labelHue : getText(cpHue),
		labelSat : getText(cpSat),
		labelLum : getText(cpLum),
		labelRed : getText(cpRed),
		labelGreen : getText(cpGreen),
		labelBlue : getText(cpBlue),
		btnAddColor : getText(cpAddColor),
		btnSelect : getText(cpSelect),
		btnCancel : getText(cpCancel)
	};

	dhxWins=new dhtmlXWindows();
	dhxWins.enableAutoViewport(true);
	dhxWins.setImagePath("../common/codebase/imgs/");
	dhxWins.setSkin(dhxSkin);
	dhxWins.attachEvent("onFocus",SetActiveWindow);

	dhtmlx.image_path="../common/codebase/imgs/";
}

function onClickHandler(itemId,itemValue)
{
	position="api.js";
	whatfunc="onClickHandler()";

	stopInterval();
	switch(itemId)
	{
		case 'file_properties':
		case '0_properties':
			ToggleInformation();
			break;

		case 'file_exit':
			checkInstall('exit');
			break;

		case 'default':
		MainToolBar.setListOptionSelected('0_configs','select_default');
			check('default');
			break;

		case 'all':
		MainToolBar.setListOptionSelected('0_configs','select_all');
			check('all');
			break;

		case 'none':
		MainToolBar.setListOptionSelected('0_configs','select_none');
			check('none');
			break;

		case 'tools_install':
		case '0_install':
			checkInstall('install');
			break;

		case 'tools_options':
		case '0_options':
			ToggleOptions();
			break;

		case 'tools_config':
		case '0_config':
			ToggleConfig();
			break;

		case 'tools_network':
		case '0_network':
			ToggleNetwork();
			break;

		case 'tools_theme':
		case '0_theme':
			ToggleTheme();
			break;

		case 'help_manual':
		case '0_manual':
			ToggleManual();
			break;

		case 'help_homepage':
			document.getElementById("HomePageLink").click();
			break;

		case 'help_forum':
			document.getElementById("ForumLink").click();
			break;

		case 'help_update':
			CheckForUpdate();
			break;

		case 'help_about':
			ToggleAboutWPI();
			break;

		case '2_add':
			AddEntry();
			break;

		case '2_clone':
		case 'context_clone':
			CloneEntry();
			break;

		case '2_delete':
		case 'context_delete':
			DeleteEntry();
			break;

		case '0_configs':
			break;

		case 'select_default':
		case 'select_all':
		case 'select_none':
			itemId=itemId.replace("select_","");
			check(itemId);
			break;

		case '0_readme':
			ToggleReadMe();
			break;

		default:
			check(itemId);
			break;
	}
}

function LayoutMenuBar()
{
	position="api.js";
	whatfunc="LayoutMenuBar()";

	if (!isCorporate)
		return;

	MenuBar=new dhtmlXMenuObject("MenuBar");
	MenuBar.setImagePath("../common/codebase/imgs/");
	MenuBar.setIconsPath("../Themes/"+Theme+"/imgs/");
	MenuBar.setOpenMode("win");
	MenuBar.attachEvent("onClick",onClickHandler);
	MenuBar.addNewSibling(null, "main_file", getText(lblFile), false);
	MenuBar.addNewChild("main_file", 0, "file_new", getText(lblNew), false, "New.png", "New_Disabled.png");
	MenuBar.addNewChild("main_file", 1, "file_open", getText(lblOpen), false, "Open.png", "Open_Disabled.png");
	MenuBar.setHotKey("file_open", "Alt+O");
	MenuBar.addNewSeparator("file_open", 2);
	MenuBar.addNewChild("main_file", 3, "file_save", getText(lblSave), false, "Save.png", "Save_Disabled.png");
	MenuBar.setHotKey("file_save", "Alt+S");
	MenuBar.addNewChild("main_file", 4, "file_saveas", getText(lblSaveAs), false, "SaveAs.png", "SaveAs_Disabled.png");
	MenuBar.addNewSeparator("file_saveas", 5);
	MenuBar.addNewChild("main_file", 6, "file_properties", getText(lblProperties), false, "Properties.png", "Properties_Disabled.png");
	MenuBar.setHotKey("file_properties", "Alt+G");
	MenuBar.addNewSeparator("file_properties", 7);
	MenuBar.addNewChild("main_file", 8, "file_exit", getText(lblExit), false, "Exit.png");
	MenuBar.setHotKey("file_exit", "Esc");
	MenuBar.addNewSibling("main_file", "main_select", getText(lblSelect), false);
	MenuBar.addRadioButton("child", "main_select", 0, "default", getText(lblSelectDefaults), "SelectConfig", false, false);
	MenuBar.setHotKey("default", "Alt+D");
	MenuBar.addRadioButton("child", "main_select", 1, "all", getText(lblSelectAll), "SelectConfig", false, false);
	MenuBar.setHotKey("all", "Alt+A");
	MenuBar.addRadioButton("child", "main_select", 2, "none", getText(lblSelectNone), "SelectConfig", false, false);
	MenuBar.setHotKey("none", "Alt+N");
	MenuBar.addNewSeparator("none", 3);
	MenuBar.addNewSibling("main_select", "main_tools", getText(lblTools), false);
	MenuBar.addNewChild("main_tools", 0, "tools_install", getText(lblInstall), false, "Install.png", "Install_Disabled.png");
	MenuBar.setHotKey("tools_install", "Alt+Enter");
	MenuBar.addNewSeparator("tools_install", 1);
	MenuBar.addNewChild("main_tools", 2, "tools_options", getText(lblOptionsWizard), false, "Options.png", "Options_Disabled.png");
	MenuBar.setHotKey("tools_options", "Alt+O");
	MenuBar.addNewChild("main_tools", 3, "tools_config", getText(lblConfigWizard), false, "Config.png", "Config_Disabled.png");
	MenuBar.setHotKey("tools_config", "Alt+C");
	MenuBar.addNewChild("main_tools", 4, "tools_network", getText(lblNetworkWizard), false, "Network.png", "Network_Disabled.png");
	MenuBar.setHotKey("tools_network", "Alt+K");
	MenuBar.addNewChild("main_tools", 5, "tools_theme", getText(lblThemeWizard), false, "Theme.png", "Theme_Disabled.png");
	MenuBar.setHotKey("tools_theme", "Alt+H");
	MenuBar.addNewSibling("main_tools", "main_help", getText(lblHelp), false);
	MenuBar.addNewChild("main_help", 0, "help_manual", getText(lblManual), false, "Help.png", "Help_Disabled.png");
	MenuBar.setHotKey("help_manual", "Alt+M");
	MenuBar.addNewSeparator("help_manual", 1);
	MenuBar.addNewChild("main_help", 2, "help_homepage", getText(lblHomePage), false);
	MenuBar.addNewChild("main_help", 3, "help_forum", getText(lblForum), false);
	MenuBar.addNewSeparator("help_forum", 4);
	MenuBar.addNewChild("main_help", 5, "help_update", getText(txtCheckForUpdate), false);
	MenuBar.addNewSeparator("help_update", 6);
	MenuBar.addNewChild("main_help", 7, "help_about", getText(lblAboutWPI), false, "About.png", "About_Disabled.png");
	MenuBar.setHotKey("help_about", "F12");
}

function LayoutMenuBarConfigs()
{
	position="api.js";
	whatfunc="LayoutMenuBarConfigs()";

	if (!isCorporate)
		return;

	if (Configurations.length>0 && Configurations[0] != "")
	{
		for (var i=0; i<Configurations.length; i++)
		{
			var id=Configurations[i];
			var name=Configurations[i];

		MenuBar.addRadioButton("child", "main_select", i+4, id, name, "SelectConfig", false, false);
		}
	}

	MenuBar.setRadioChecked("SelectConfig",CheckOnLoad);
}

function LayoutMainToolBar()
{
	position="api.js";
	whatfunc="LayoutMainToolBar()";

	if (!isCorporate)
		return;

	MainToolBar=new dhtmlXToolbarObject("MainToolBar");
	MainToolBar.setIconsPath("../Themes/"+Theme+"/imgs/");
	MainToolBar.attachEvent("onClick",onClickHandler);
	MainToolBar.attachEvent("onStateChange",onClickHandler);
	MainToolBar.addButton("0_new", 0, "", "New.png", "New_Disabled.png");
	MainToolBar.setItemToolTip("0_new",getText(lblNew));
	MainToolBar.addButton("0_open", 1, "", "Open.png", "Open_Disabled.png");
	MainToolBar.setItemToolTip("0_open",getText(lblOpen));
	MainToolBar.addButton("0_save", 2, "", "Save.png", "Save_Disabled.png");
	MainToolBar.setItemToolTip("0_save",getText(lblSave));
	MainToolBar.addButton("0_saveas", 3, "", "SaveAs.png", "SaveAs_Disabled.png");
	MainToolBar.setItemToolTip("0_saveas",getText(lblSaveAs));
	MainToolBar.addSeparator("sep0", 4);
	MainToolBar.addButton("0_install", 5, "", "Install.png", "Install_Disabled.png");
	MainToolBar.setItemToolTip("0_install",getText(lblInstall));
	MainToolBar.addSeparator("sep1", 6);
	MainToolBar.addButton("0_options", 7, "", "Options.png", "Options_Disabled.png");
	MainToolBar.setItemToolTip("0_options",getText(lblOptionsWizard));
	MainToolBar.addButton("0_config", 8, "", "Config.png", "Config_Disabled.png");
	MainToolBar.setItemToolTip("0_config",getText(lblConfigWizard));
	MainToolBar.addButton("0_network", 9, "", "Network.png", "Network_Disabled.png");
	MainToolBar.setItemToolTip("0_network",getText(lblNetworkWizard));
	MainToolBar.addButton("0_theme", 10, "", "Theme.png", "Theme_Disabled.png");
	MainToolBar.setItemToolTip("0_theme",getText(lblThemeWizard));
	MainToolBar.addSeparator("sep2", 11);
	MainToolBar.addButton("0_manual", 12, "", "Help.png", "Help_Disabled.png");
	MainToolBar.setItemToolTip("0_manual",getText(lblHelp));
	MainToolBar.addSeparator("sep3", 13);
	
	var IDs=Array(Array('select_default', 'obj', getText(lblSelectDefaults)),
				Array('select_all', 'obj', getText(lblSelectAll)),
				Array('select_none', 'obj', getText(lblSelectNone)),
				Array('sep0', 'sep'));
	MainToolBar.addButtonSelect("0_configs", 14, getText(lblConfigurations), IDs);

	var pre="";
	if (CheckOnLoad=="default" || CheckOnLoad=="all" || CheckOnLoad=="none")
		pre="select_";
	MainToolBar.setListOptionSelected('0_configs',pre+CheckOnLoad);

	strFile=wpipath+"\\ReadMe.txt";
	if (FileExists(strFile))
	{
	MainToolBar.addSeparator("sep9", 98);
	MainToolBar.addButton("0_readme", 99, "", "ReadMe.png", "ReadMe_Disabled.png");
	MainToolBar.setItemToolTip("0_readme",getText(lblReadMe));
	}
}

function LayoutMainToolBarConfigs()
{
	position="api.js";
	whatfunc="LayoutMainToolBarConfigs()";

	if (!isCorporate)
		return;

	if (Configurations.length>0 && Configurations[0] != "")
	{
		for (var i=0; i<Configurations.length; i++)
		{
			var id=Configurations[i];
			var name=Configurations[i];

		MainToolBar.addListOption('0_configs', id, i+5, 'button', name, null);
		}
	}
}

function SetNOSSAState(state)	// New, Open, Save, Save As
{
    position="api.js";
    whatfunc="SetNOSSAState()";

	if (!isCorporate)
		return;

	if (state)
	{
	MenuBar.setItemDisabled('file_new');
	MainToolBar.disableItem('0_new');
	MenuBar.setItemDisabled('file_open');
	MainToolBar.disableItem('0_open');
	MenuBar.setItemDisabled('file_save');
	MainToolBar.disableItem('0_save');
	MenuBar.setItemDisabled('file_saveas');
	MainToolBar.disableItem('0_saveas');
	}
	else
	{
	MenuBar.setItemEnabled('file_new');
	MainToolBar.enableItem('0_new');
	MenuBar.setItemEnabled('file_open');
	MainToolBar.enableItem('0_open');
	MenuBar.setItemEnabled('file_save');
	MainToolBar.enableItem('0_save');
	MenuBar.setItemEnabled('file_saveas');
	MainToolBar.enableItem('0_saveas');
	}
}

function CheckKey(e)   //Remember the (e)
{
	position="api.js";
	whatfunc="CheckKey()";

if (window.event.keyCode==116) 
                SetNotExitingFlag();

	if (DisableHotKeys)
		return;

	if (window.event.altKey)
	{
		switch(window.event.keyCode)
		{
			case 13: // Enter - "Begin Install"
				checkInstall('install');
				break;

			case 79: // O - toggle Options Wizard
				ToggleOptions();
			    break;

			case 67: // C - toggle Config Wizard
				ToggleConfig();
			    break;

			case 75: // K - toggle Network Wizard
				ToggleNetwork();
			    break;

			case 72: // H - toggle Theme Wizard
				ToggleTheme();
			    break;

			case 77: // M - toggle Manual
				ToggleManual();
			    break;

			case 87: // W - toggle About WPI
				ToggleAboutWPI();
			    break;

			case 66: // B - "Show Extra Buttons"
				ToggleExtraButtons();
			    break;

			case 71: // G - "Global Variables"
				ToggleInformation();
			    break;

			case 84: // T - Toggle "ShowToolTips"
				if (ShowToolTips==0)
					ShowToolTips=1;
				else
					ShowToolTips=0;
			    break;

			case 65: // A - "Select All"
				check('all');
			    break;

			case 68: // D - "Select Defaults"
				check('default');
			    break;

			case 78: // N - "Select None"
				check('none');
			    break;
		}
	}
	else
	{
		switch(window.event.keyCode)
		{
			case 13: // Enter
				if (ActiveWindow=="SubWizardWindow" && dhxWins.isWindow("SubWizardWindow"))
				{
					document.getElementById("Btn_OK").click();

					return;
					break;
				}
				if (ActiveWindow=="SubWizardWindow2" && dhxWins.isWindow("SubWizardWindow"))
				{
					return;
					break;
				}
				if (ActiveWindow==alertTitle && dhxWins.isWindow("AlertWindow"))
				{
					CloseAlert(1);

					return;
					break;
				}
				break;

			case 27: // Esc - If the screen is not the main install screen, "Toggle screen" else you want to "Exit"
				if (ActiveWindow=="SubWizardWindow" && dhxWins.isWindow("SubWizardWindow"))
				{
					document.getElementById("Btn_Cancel").click();

					return;
					break;
				}
				if (ActiveWindow==alertTitle && dhxWins.isWindow("AlertWindow"))
				{
					CloseAlert(0);

					return;
					break;
				}
				if (ActiveWindow==getText(lblUpdateWPI) && dhxWins.isWindow("UpdateWindow"))
				{
					HideUpdate();

					return;
					break;
				}
				if (ActiveWindow==getText(lblAboutWPI) && dhxWins.isWindow("AboutWindow"))
				{
					HideAboutWPI();

					return;
					break;
				}
				if (ActiveWindow==getText(txtWPIManual) && dhxWins.isWindow("ManualWindow"))
				{
				ManualWindow.close();
				ManualWindow=null;
					break;
				}
				if (ActiveWindow==getText(lblReadMe) && dhxWins.isWindow("ReadMeWindow"))
				{
					ReadMeWindow.close();
					ReadMeWindow=null;
					break;
				}
				if (ActiveWindow==getText(lblOptionsWizard) && dhxWins.isWindow("OptionsWindow"))
				{
					ToggleOptions();

					return;
					break;
				}
				if (ActiveWindow==getText(lblConfigWizard) && dhxWins.isWindow("ConfigWindow"))
				{
					ToggleConfig();

					return;
					break;
				}
				if (ActiveWindow==getText(lblNetworkWizard) && dhxWins.isWindow("NetworkWindow"))
				{
					ToggleNetwork();

					return;
					break;
				}
				if (ActiveWindow==getText(lblThemeWizard) && dhxWins.isWindow("ThemeWindow"))
				{
					ToggleTheme();

					return;
					break;
				}
				if (document.getElementById("layerboxes").style.display != 'block')
					ShowMain();
				else
				{
					if (dhxWins.isWindow("InfoWindow"))
						return;

					checkInstall('exit');
				}
			    break;

			case 112: // F1 - toggle Manual
				ToggleManual();
			    break;

			case 113: // F2 - toggle Options Wizard
				ToggleOptions();
			    break;

			case 114: // F3 - toggle Config Wizard
				ToggleConfig();
			    break;

			case 115: // F4 - toggle Network Wizard
				ToggleNetwork();
			    break;

			case 117: // F6 - toggle Theme Wizard
				ToggleTheme();
			    break;

			case 123: // F12 - toggle About WPI
				ToggleAboutWPI();
			    break;
		}
	}
}

function sizer()
{
	position="api.js";
	whatfunc="sizer()";

	var fW, fH=0;

	fW=Resolution;
	switch (fW)
	{
// Standard
		case 800:
			fW=800;
			fH=600;
			break;

		case 1024:
			fW=1024;
			fH=768;
			break;

		case 1280:
			fW=1280;
			fH=1024;
			break;

		case 1400:
			fW=1400;
			fH=1050;
			break;

		case 1600:
			fW=1600;
			fH=1200;
			break;

		case 1920:
			fW=1920;
			fH=1400;
			break;

// Widescreen
		case 12802:
			fW=1280;
			fH=720;
			break;

		case 12803:
			fW=1280;
			fH=768;
			break;

		case 12804:
			fW=1280;
			fH=800;
			break;

		case 1440:
			fW=1440;
			fH=900;
			break;

		case 16002:
			fW=1600;
			fH=1024;
			break;

		case 1680:
			fW=1680;
			fH=1050;
			break;

		case 19202:
			fW=1920;
			fH=1080;
			break;

		case 1:
			fW=MainWindowWidth;
			fH=MainWindowHeight;
	}

	if (screen.height<=600)
	{
		self.moveTo(0,0);
		self.resizeTo(screen.width,screen.height);
		top.status=screen.height;

		return;
	}
	if (fW>0 && fH != 0)
	{
		var XCoord=((screen.width/2)-(fW/2));
		var YCoord=((screen.height/2)-(fH/2));

		if (MainWindowX != -1)
			XCoord=MainWindowX;
		if (MainWindowY != -1)
			YCoord=MainWindowY;

		self.moveTo(XCoord,YCoord);
		self.resizeTo(fW,fH);
		top.status=fH;
	}
	else
	{
		self.moveTo(0,0);
		self.resizeTo(screen.width,screen.height);
		top.status=screen.height;
	}
}

function getElementsByClassName(classname)
{
	position="api.js";
	whatfunc="getElementsByClassName()";

	var rl=new Array();
	var re=new RegExp('(^| )'+classname+'( |$)');
	var ael=document.getElementsByTagName('*');
	var op=(navigator.userAgent.indexOf("Opera") != -1) ? true : false;

	if (document.all && !op)
		ael=document.all;
	for (var i=0, j=0; i<ael.length; i++)
	{
		if (re.test(ael[i].className))
		{
			rl[j]=ael[i];
			j++;
		}
	}

	return rl;
}

function noTags(a)
{
	position="api.js";
	whatfunc="noTags()";

	var sprg=new String();
	var lines=new Array();

	sprg=a;
	lines=sprg.split(/< *(p.|br[ \/]*)>/i);
	multi=lines.length-1;
	sprg=sprg.replace(/<[^>]*>/gi,"");

	return sprg;
}

function CheckLanguageFile(lang, file)
{
	position="api.js";
	whatfunc="CheckLanguageFile";

	var found=false;
	var count=0;

	try
	{
		// Verify if it's a language file
		tf=fso.OpenTextFile(wpipath+file,1,0,-2);

		// search Language string identifier lang='xx' ?
		while (!tf.AtEndOfStream && !found)
		{
			count++;
			line=tf.ReadLine();
			var reg=new RegExp("^lang[ \\t]*=[ \\t]*'"+lang+"'[ \\t]*;*","");
			found=line.search(reg)==0;
		}
		if (!found)
		{
			lang='';
			if (getText(BadLanguageFile)) // error in lang_en
				alert("'"+file+"'"+ getText(NotALanguageFile));
			else
				alert("'"+file+"' is not a language file.\n\nPlease, re-install language file.");
		}
		else
		{
			while (!tf.AtEndOfStream)
			{
				count++;
				line=tf.ReadLine();
				if (line.search(/^(\s*$)|( *\/\/)/)==0)
					continue;  // empty line or comments
				// syntax regexp for myvariable[lang]=['text1',['text2']...] | ["text1",["text2"]...] ;
				if (line.search(/^[A-Za-z][\w]*[ \t]*(\[lang\]){1,1}[ \t]*=[ \t]*\[(((,?'{1,1}(\\'|[^'])*')*)|((,?"{1,1}(\\"|[^"])*")*))+\];?/)==-1)
				{ // Syntax error, prompt user with line number
					lang='';
					if (getText(BadLanguageFile)) // error in lang_en
						alert("'"+file+"'"+getText(BadLanguageFile)+count.toString());
					else
						alert("'"+file+"'  language file. Syntax error at line: "+count.toString()); // don't getText translation

					break;
				}
			}
		}
	}
	catch(ex)
	{ ; }
	finally
	{
		try
		{
			tf.Close();
		}
		catch (ex0)
		{ ; }
	}

	return lang;
}

function CheckTxtHeight()
{
	position="api.js";
	whatfunc="CheckTxtHeight()";

	var line=new String();
	var txt1, txt2;
	var foundtxt=false, start=0, end=0, height=8;

	if (!FileExists(wpipath+"\\Themes\\"+Theme+"\\wpi.css"))
	{
		alert("'"+Theme+"\\wpi.css' does not exist.\n\nAssuming text height of 8pt.");

		return height;
	}

	try
	{
		tf=fso.OpenTextFile(wpipath+"\\Themes\\"+Theme+"\\wpi.css",1,0,-2);
		while (!tf.AtEndOfStream)
		{
			line=tf.ReadLine();
			if (line=='.txt' && !foundtxt)
				foundtxt=true;
			if (foundtxt)
			{
				if (line.search("font-size:")>0)
				{
					start=line.lastIndexOf(":")+1;
					end=line.lastIndexOf("pt;")-1;
					if (line.charCodeAt(start)==32)
						start++;
					txt1=line.charAt(start);
					txt2=line.charAt(end);
					if (end>start)
						txt1 += txt2;
					height=parseInt(txt1);
				}
				break;
			}
		}
	}
	catch(ex)
	{ ; }
	finally
	{
		try
		{
			tf.Close();
		}
		catch (ex0)
		{ ; }
	}

	return height;
}

function CreateTab(file,tabid)
{
	position="api.js";
	whatfunc="CreateTab()";

	var txt=new String(); txt="";

	strFile=wpipath+file;
	if (!FileExists(strFile))
	{
		Alert("",getText(errCouldNotOpenFile)+" '"+strFile+"'.",getText(lblOK),2,0,0,0);
		RefreshWPI();
	}
	try
	{
		tf=fso.OpenTextFile(strFile,1,0,-2);
		while (!tf.AtEndOfStream)
			txt=tf.ReadAll();
	}
	catch(ex)
	{ ; }
	finally
	{
		try
		{
			tf.Close();
		}
		catch (ex0)
		{ ; }
	}

	document.getElementById(tabid).innerHTML=txt;
}

function isNumberKey(evt)
{
	position="api.js";
	whatfunc="isNumberKey()";

	var charCode=(evt.which) ? evt.which : event.keyCode;

	if (charCode > 31 && (charCode < 48 || charCode > 57))
		return false;

	return true;
}

function insertAtCaret(control, text) 
{ 
        position="api.js"; 
        whatfunc="insertAtCaret()"; 
 
        if (control.setSelectionRange) 
                control.value = control.value.substring(0,control.selectionStart) + text + control.value.substring(control.selectionStart,control.selectionEnd) + control.value.substring(control.selectionEnd,control.value.length); 
        else if (document.selection && document.selection.createRange) { 
                control.focus(); 
                var range = document.selection.createRange(); 
                range.text = text + range.text; 
        } 
}

function moveCaretToEnd(control)
{
	position="api.js";
	whatfunc="moveCaretToEnd()";

	if (control.createTextRange)
	{
		var range=control.createTextRange();

		range.collapse(false);
		range.select();
	}
	else if (control.setSelectionRange)
	{
		control.focus();

		var length=control.value.length;

		control.setSelectionRange(length,length);
	}
}

function selectText(control,txt) 
{ 
        position="api.js"; 
        whatfunc="selectText()";

	if (control.createTextRange)
	{
		var range=control.createTextRange();

		range.findText(txt);
		range.select();
	}
}

function HandleSpecialCharacters(txt,space)
{
	position="api.js";
	whatfunc="HandleSpecialCharacters()";

	if (space)
		return txt=txt.replace(/[^a-zA-Z0-9 ]/g,'');
	else
		return txt=txt.replace(/[^a-zA-Z0-9]/g,'');
}

function __parseBorderWidth(width)
{
    var res = 0;
    if (typeof(width) == "string" && width != null && width != "" ) {
        var p = width.indexOf("px");
        if (p >= 0) {
            res = parseInt(width.substring(0, p));
        }
        else {
            res = 1;
        }
    }

	return res;
}

//returns border width for some element
function __getBorderWidth(element) {
	var res = new Object();
	res.left = 0; res.top = 0; res.right = 0; res.bottom = 0;
	if (window.getComputedStyle) {
		//for Firefox
		var elStyle = window.getComputedStyle(element, null);
		res.left = parseInt(elStyle.borderLeftWidth.slice(0, -2));
		res.top = parseInt(elStyle.borderTopWidth.slice(0, -2));
		res.right = parseInt(elStyle.borderRightWidth.slice(0, -2));
		res.bottom = parseInt(elStyle.borderBottomWidth.slice(0, -2));
	}
	else {
		//for other browsers
		res.left = __parseBorderWidth(element.style.borderLeftWidth);
		res.top = __parseBorderWidth(element.style.borderTopWidth);
		res.right = __parseBorderWidth(element.style.borderRightWidth);
		res.bottom = __parseBorderWidth(element.style.borderBottomWidth);
	}

	return res;
}

//returns absolute position of some element within document
function getAbsolutePos(element) {
	var res = new Object();
	res.x = 0; res.y = 0;
	if (element !== null) {
		res.x = element.offsetLeft;
		res.y = element.offsetTop;

		var offsetParent = element.offsetParent;
		var parentNode = element.parentNode;
		var borderWidth = null;

		while (offsetParent != null) {
			res.x += offsetParent.offsetLeft;
			res.y += offsetParent.offsetTop;

			var parentTagName = offsetParent.tagName.toLowerCase();

			if ((__isIE && parentTagName != "table") || (__isFireFoxNew && parentTagName == "td")) {
				borderWidth = __getBorderWidth(offsetParent);
				res.x += borderWidth.left;
				res.y += borderWidth.top;
			}

			if (offsetParent != document.body && offsetParent != document.documentElement) {
				res.x -= offsetParent.scrollLeft;
				res.y -= offsetParent.scrollTop;
			}

			//next lines are necessary to support FireFox problem with offsetParent
   			if (!__isIE) {
    			while (offsetParent != parentNode && parentNode !== null) {
					res.x -= parentNode.scrollLeft;
					res.y -= parentNode.scrollTop;

					if (__isFireFoxOld) {
						borderWidth = kGetBorderWidth(parentNode);
						res.x += borderWidth.left;
						res.y += borderWidth.top;
					}
    				parentNode = parentNode.parentNode;
    			}
			}

   			parentNode = offsetParent.parentNode;
    		offsetParent = offsetParent.offsetParent;
		}
	}

	return res;
}
