//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// Windows Post - Install Wizard
// globals.js
//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

var position = "globals.js";
var whatfunc = "Setting Up";
var ReleaseDate = "Feb 2nd, 2014";
var ShortVersion = "8.7.2", ReallyLongVersion = "Windows Post-Install Wizard v" + ShortVersion, LongVersion = "WPI v" + ShortVersion, MediumVersion = "v" + ShortVersion;
var minimumTheme = "WPI Theme 8.0.0", minTheme = "v8.0.0";
var OptionsWizardOpen = false, ConfigWizardOpen = false, NetworkWizardOpen = false, ThemeWizardOpen = false;

// themes.js
var DefaultTheme = "Win7", DefaultSkin = 'SkyBlue', DefaultType = "Windows", ThemeType;

//
// System predefined options
//

// Window tab
var WindowShowBorder = false;
var WindowBorderType = 'thick';
var WindowBorderStyle = 'normal';
var WindowInnerBorder = false;
var WindowCaption = true;
var WindowSysMenu = true;
var WindowMinimizeButton = true;
var WindowMaximizeButton = true;
var WindowStartingState = 'normal';
var WindowShowInTaskBar = true;
var Resolution = 0;
var MainWindowWidth = 800;
var MainWindowHeight = 600;
var MainWindowX = - 1;
var MainWindowY = - 1;
var InstallerWindowX = 25;
var InstallerWindowY = 25;

// General tab
var NumCols = 3;
var Timer = true;
var Seconds = 60;
var StartBeepAtSecs = 10;
var Language = 'zz';
var ShowExtraButtons = true;
var DoNotShowIfCD = true;
var USSFSilentMode = false;
var VerifyInstallHDD = false;
var AllowCheckForInternet = false;
var LoadDesktopBeforeInstall = false;
var ReOpenAfterInstall = false;
var DisableCatCheckBoxes = false;
var SortWithinCats = false;
var DisableOnDepsNotMet = true;
var AlwaysUseScrollBar = true;
var DontSplitCats = true;
var InstallByCategory = true;
var ReallyForce = false;
var DisableIfDoGray = false;
var InstallFonts = false;
var ShowCommandInInstaller = true;
var ShowInstallerImages = false;
var AlwaysShowOutputWindow = false;
var EjectCDWhenDone = false;
var DoNotShowIfUSB = false;
var DisableHotKeys = false;
var ShowDownloadOutput = false;
var DisableInstallCombobox = false;
var MaintainAutoLogonCount = false;
var DefaultInstallPath = ['default'];
var CustomInstallPath = [''];
var AbortInstallIfFailure = false;
var ExecuteCommandIfFailure = [''];
var ContinueWhereFailed = false;

// Tools tab
var MonitorResolution = 0;
var MonitorDepth = 0;
var MonitorRefresh = 0;
var ExecuteBeforeEnabled = false;
var ExecuteBefore = [''];
var ExecuteAfterEnabled = false;
var ExecuteAfter = [''];
var RestartComputer = false;
var RestartType = 0;
var RestartSeconds = 30;
var DoNotLoadDesktop = true;
var LogInstallation = true;
var LogPath = [''];
var TimeStampLogFile = false;
var DefaultLogPath = ['%systemdrive%\\WPI_Log.txt'];

// Audio Player tab
var PlayAudioInInstaller = false;
var InstallAudio = [];
var Volume = 75;
var Shuffle = false;
var CopyAudioFolder = false;
var CopyAudioPath = ['C:\\Audio'];
var DeleteAudioFolder = false;

// Sounds tab
var SndWPIStartCB = false;
var SndWPIStart = ['"%wpipath%\\Audio\\SoundsScheme\\Alert.wav"'];
var SndInstallStartCB = false;
var SndInstallStart = ['"%wpipath%\\Audio\\SoundsScheme\\AtBeginning.wav"'];
var SndInstallSuccessCB = false;
var SndInstallSuccess = ['"%wpipath%\\Audio\\SoundsScheme\\Yes.wav"'];
var SndInstallWarningCB = false;
var SndInstallWarning = ['"%wpipath%\\Audio\\SoundsScheme\\Warning.wav"'];
var SndInstallFailCB = false;
var SndInstallFail = ['"%wpipath%\\Audio\\SoundsScheme\\No.wav"'];
var SndInstallFinishCB = false;
var SndInstallFinish = ['"%wpipath%\\Audio\\SoundsScheme\\AtEnd.wav"'];
var SndWPIExitCB = false;
var SndWPIExit = ['"%wpipath%\\Audio\\SoundsScheme\\Exit.wav"'];

// Configurations tab
var Configurations = [];
var ShowMultiDefault = true;
var CheckOnLoad = 'default';
var SortOrder = [];

// Style tab
var Theme = DefaultTheme;
var ThemeSkin = 'SkyBlue';
var BgPicture = '';
var InstallBgsSkin = 'None';
var ProgBarsSkin = 'Vista_03';
var LayoutStyle = 1;

// Tool Tips
var ShowToolTips = true;
var TipShadowStrength = 3;
var AtStartUp = true;

// options files globals
var WshShell = new ActiveXObject("WScript.Shell");
var WshEnv = WshShell.Environment("PROCESS");
var strSpecialFolders, oShellLink;
var tf, ex, strFile, oldFile;
var fso = new ActiveXObject("Scripting.FileSystemObject");
var shell = new ActiveXObject("Shell.Application");
var fontsFolder = shell.Namespace(0x14);
var optionsFile = "", windowFile = "", configFile = "", networkFile = "", themeFile = "";
var optionsDefault, windowDefault, configDefault, networkDefault, themeDefault;
var USSFcmd;
var numChecked = 0;

// comand line args
var checkOL = "", timerSecs = null, clTheme = "", clRes = null, forceInstall = false, clLanguage = "", clContinue = false;
var usedLauncher = false;

// themes.js
var dhxSkin = "dhx_skyblue";
var isReadMeImage = true, isInstallImage = true;
var isDefaultsImage = true, isAllImage = true, isNoneImage = true;
var isOptionsImage = true, isConfigImage = true, isNetworkImage = true, isThemeImage = true;
var isInformationImage = true, isManualImage = true, isAboutImage = true;
var isExitImage = true;

// At top of file
var Theme_BGColor = "";
var Theme_BackgroundRepeat = "stretch", Theme_BackgroundPosition = "";
var Theme_TextBoxBGColor = "";
var Theme_TitleBGHeight = 50, Theme_TitleBGColor = "#0000FF", Theme_TitleBGImageRepeat = "repeat";
var Theme_TitleImageWidth, Theme_TitleImageHeight, Theme_TitleImageAlign = "center";
var Theme_TitleTextFont = "Arial", Theme_TitleTextSize = "1.5em", Theme_TitleTextColor = "#000000", Theme_TitleTextWeight = "bold", Theme_TitleTextStyle = "", Theme_TitleTextAlign = "center";
var Theme_SmallBarTHeight = "2", Theme_SmallBarBHeight = "2";
var Theme_FrameColor = "#ffffff";
var Theme_SidePanelBGColor = "", Theme_SidePanelWidth = 200, Theme_SidePanelBGImageRepeat = "repeat";
var Theme_MainPanelBGColor = "", Theme_MainPanelBGImageRepeat = "repeat";
var Theme_LogoImageWidth = 0, Theme_LogoImageHeight = 0, Theme_LogoImageRight = 25, Theme_LogoImageBottom = 25;
var Theme_BottomBGHeight = 50, Theme_BottomBGColor = "#0000FF", Theme_BottomBGImageRepeat = "repeat";
var Theme_BottomImageWidth, Theme_BottomImageHeight, Theme_BottomImageAlign = "center";
var Theme_BottomTextFont = "Arial", Theme_BottomTextSize = "1.5em", Theme_BottomTextColor = "#ff0000", Theme_BottomTextWeight = "bold", Theme_BottomTextStyle = "", Theme_BottomTextAlign = "center", Theme_BottomText = "";
var Theme_ExitButtonLocation = "right", Theme_ShowExitButtonText = true;
var Theme_ShowButtonText = true;
var Installer_BackgroundRepeat = "";
var isStatusBox = false;
var isCorporate = false;
var isAccordion = false;
var iseuDock = false;

// registry_dos.js
var fontDir;

// wmi.js
var KeyboardLayout;
var OSProps, winMgts;
var BIOSManufacturer, BIOSVersion, SMBIOSVerison, BIOSCaption;
var BaseBoardManufacturer, BaseBoardModel;
var ChipsetManufacturer, ChipsetModel;
var VideoControllerName, SoundDeviceName, NetworkAdapterName, WirelessNetworkAdapterName, ModemName, HDDControllerName = [];
var CDROMName, CDBurnerName, KeyboardName, PointingDeviceName, FirewallProductName, AVProduct;
var PNPDID_VideoController, PNPDID_SoundDevice, PNPDID_NetworkAdapter, PNPDID_WirelessNetworkAdapter, PNPDID_Modem, PNPDID_HDDController = [];
var PNPDID_CDROM, PNPDID_CDBurner, PNPDID_Keyboard, PNPDID_PointingDevice;
var SystemEnclosureType, ProductKey;
var sysManufacturer, sysModel, sysPCType, sysType;
var sysArch;
var OSBits = 32;
var sysPath64, sysPath32;
var TotalRAM, FreeRAM;
var NumberOfProcessors, NumberOfCores, NumberOfLogicalProcessors;
var IEver;
var hasDVDROMDrive = false, hasDVDBurnerDrive = false;
var DesktopLoaded;
var objWMIService, SWBemlocator, colItems, objItem, enumItems;
var OSProps, winMgts;
var wbemFlagReturnImmediately = 0x10, wbemFlagForwardOnly = 0x20;
var NOT_FOUND = "Not found";
var szOSVerCache = NOT_FOUND, szEditionIDCache = NOT_FOUND, szServicePackCache = NOT_FOUND;
var PF_Drive, PF_InitialSize, PF_MaximumSize;

// core.js
var hdd = new String();
var cddrv = new String();
var usbdrv = new String();
var wpipath = new String();
var root = new String();
var dospath = new String();
var sysdrv = WshEnv("SYSTEMDRIVE");
var windir = WshEnv("WINDIR");
var programfiles = WshEnv("PROGRAMFILES");
var temp = WshEnv("TEMP");
var sysdir = WshEnv("WINDIR") + "\\System32";
var allusersprofile = WshEnv("ALLUSERSPROFILE");
var userprofile = WshEnv("USERPROFILE");
var userprofileroot = WshEnv("USERPROFILE").substring(0, WshEnv("USERPROFILE").lastIndexOf("\\"));
var appdata = WshEnv("APPDATA");
var commonprogramfiles = WshEnv("COMMONPROGRAMFILES");
var oslang = new String();
var oslocale = new String();
var arrOSLang = new Array();
var driveTypes = ["UNKNOWN", "REMOVABLE", "FIXED", "NETWORK", "CDROM", "RAMDISK"];
var SleepShell = new ActiveXObject("WScript.Shell");
var RunCmdShell = new ActiveXObject("WScript.Shell");
var sleepCmd = '';
var fromHardDrive = false, fromCDDrive = false, fromUSBDrive = false, fromNetworkShare;

// installer.js
var InstallArg;
var DoCleanUp = false;
var ResumeCount = 0, ExitBeforeInstall = false;
var programs = new Array();
var cmdLine, cmdArgs, tempCmd, tempArgs;
var numCommands = 0, curCommand = 0, ShowPercentValue = false;
var CurrentCategory = "";
var NumFailed = 0;
var fsoCmd = false, waitForIt = true;
var UserPaused = false, UserAborted = false, UserAbortedReopen = false;
var isInstaller = false;
var InstallAudioPath;
var FailNum = 0;
var isIE = false;
var Count=0;

// installer_log.js
var logHandle = null;

// installer_history.js
var historyHandle = null;
var historyDefault = '%systemdrive%\\history.js';

// installer_reboot.js
var prb = 0;
var rbfHandle = null;
var rebootDefault = '%systemdrive%\\rb_config.js';
var ResumeInstall = false, CurrentInstall = null, LastExec = null;
var RebootInstallationLog = true, RebootEntryFound = false;

// tips.js
var TipId = "TipLayer";
var MI_OPR = 0, MI_IE = 0, MI_IE4 = 0, MI_NN4 = 0, MI_ONN = 0, MI_NN = 0, MI_pSub = 0, MI_sNav = 0;
var ua = navigator.userAgent.toLowerCase();
var Style = [], Count = 0, move = 0, fl = 0, isOK = 1, hs, e_d, tb, PX = MI_pSub ? "px" : "";
var d_r = (MI_IE && document.compatMode == "CSS1Compat") ? "document.documentElement" : "document.body";
var ww = window.innerWidth;
var wh = window.innerHeight;
var sbw = MI_ONN ? 15 : 0;
var titCol, titBgCol, titBgImg, titTxtAli;
var txtCol, txtBgCol, txtBgImg, txtTxtAli;
var tipHeight, brdCol;

MI_pSub = navigator.productSub;
MI_OPR = ua.indexOf("opera") > - 1 ? parseInt(ua.substring(ua.indexOf("opera") + 6, ua.length)) : 0;
MI_IE = document.all && ! MI_OPR ? parseFloat(ua.substring(ua.indexOf("msie") + 5, ua.length)) : 0;
MI_IE4 = parseInt(MI_IE) == 4;
MI_NN4 = navigator.appName.toLowerCase() == "netscape" && ! document.getElementById;
MI_NN = MI_NN4 || document.getElementById && ! document.all;
MI_ONN = MI_NN4 || MI_pSub < 20020823;
MI_sNav = MI_NN || MI_IE || MI_OPR >= 7;

Style[0] = ["#ffffff", "#000099", "", "left", "Arial", 10, "#000000", "#e8e8ff", "", "left", "Arial", 8, , , 2, "#000099", 2, 51, 0.4, 0, 2, "#738da2", 0, 0, , ];

// api.js
var __isIE =  navigator.appVersion.match(/MSIE/);
var __userAgent = navigator.userAgent;
var __isFireFox = __userAgent.match(/firefox/i);
var __isFireFoxOld = __isFireFox && (__userAgent.match(/firefox\/2./i) || __userAgent.match(/firefox\/1./i));
var __isFireFoxNew = __isFireFox && ! __isFireFoxOld;

// program.js
var pn = 1;
// program count variable

// Each application has some parameters. These are :
var prog = [];
// Program Name
var shortdesc = [];
// Short description for logos
var uid = [];
// unique identifier, used for dependency checking
var desc = [];
// A description
var ordr = [];
// [number], install order by definition in config, if not set same order position is possible. if 2 progs have the same order position, they'll be sorted by name
var dflt = [];
// Whether it's a default option. If it's not yes, then it will assume no
var forc = [];            // Force installation of application even if not Checked
var cat = [];
// category
var configs = [];
// List of configs this program will be selected from automatically

// For updating old config files
var regb = [];
// registry entry before installing the application
var cmd1 = [];
// Command Line 1
var cmd2 = [];
// Command Line 2
var cmd3 = [];
// Command Line 3
var cmd4 = [];
// Command Line 4
var cmd5 = [];
// Command Line 5
var cmd6 = [];
// Command Line 6
var cmd7 = [];
// Command Line 7
var cmd8 = [];
// Command Line 8
var cmd9 = [];
// Command Line 9
var cmd10 = [];
// Command Line 10
var rega = [];
// registry entry after installing the application

// Otherwise not needed anymore
var rebootcode = [];
// Return code value to specify a reboot is required
var repeatcommand = [];
// Repeat the command until code returned in not the rebootcode
var pfro = [];
// Check for any pending reboots
var cmds = [];
var deps = [];
// dependency, fill in uids of progs, this one is dependent of, if a dependent program is selected, its 'parent' gets selected too, if 'parent' is deselected, program is also deselected
var excl = [];
// exclusions, fill in uids of progs, that will be disabled, if this prog is selected.
var cond = [];
// Javascript conditional statement to check if this will be installed.
var gcond = [];
// Bill Add
var picf = [];
// Name of picture
var picw = [];
// Width of picture
var pich = [];
// Hight of picture
var textl = [];
// textlocation
var texti = [];
// textindent - Now in Options.  Here for backwards compatibilty only
var success = [];
// Success or fail of installation
var fail = [];
// Success or fail of installation
var imagelocationlr = [];
var imagepart2lr = [];
var imagepart3lr = [];
var imagepart4lr = [];
var imagepart5lr = [];
var imagelocationtb = [];
var imagepart2tb = [];
var imagepart3tb = [];
var imagepart4tb = [];
var imagepart1t = [];
var imagepart1b = [];
var imageparteb = [];

// Used for left and right text
imagelocationlr = '<img src="../Graphics/';
imagelocationlr2 = '<img src="';
imagepart2lr = '" width="';
imagepart3lr = '" height="';
imagepart4lr = '" align="';
imagepart5lr = '">';

// Used for top and bottom text
imagelocationtb = '<center><img src="../Graphics/';
imagelocationtb2 = '<center><img src="';
imagepart1t = '<br>';
imagepart2tb = '" width="';
imagepart3tb = '" height="';
imagepart4tb = '"';
imagepart1b = '<br>';
imageparteb = '<br></center>';

// optionswizard.js
var isOptionsSaved = true;
var GeneralOptionsArray = new Array();
var Songs = [];

// configwizard.js
var isConfigSaved = true;
var configList = new Array();
var cpos = 0;
var BrowseName, tempName, theStart;
var Commands = [];
var WhichCond, InsertCondValues = true;
var CatFilter = "all";
var CatInstallOrder = [], CatSortOrder = [];
var WriteRegType;
var ConfigSortBy = 0, ConfigSortAscDes = "asc";
var SortingState = [];
SortingState[0] = "1";
SortingState[1] = "asc";

// configwizard_ussf.js
var USSF_FileName, USSF_Type;

// networkwizard.js
var isNetworkSaved = true;
var networkUser = "", NetworkOptions =
{
}
;
var AddEdit, UserPos = - 1, ippos, dgpos, dnspos, winspos;

// themewizard.js
var isThemeSaved = true;

// boxes.js
var tabs = 0;
var FontHeight, maxentries = 0, catheight = 2.0;
var IsGray = false;
var lasti = 1;
var boxTxt = new String();
var ColWidth, numCols, Cols = 1;
var CurrentCat = new String();

// check.js
var rekArray = [];
var FirstCount = true;

// timers.js
var interval = "";
var m, passed = 0, startSecs;
var TimerWidth = 150, TimerHeight = 16;
var ins_startSecs = 0;

// network.js
var WshNetwork = new ActiveXObject("WScript.Network");
var LogOnServer, UserDomain, ComputerName, UserName;
var XMLreq, isIE = false, HandleReqChange;
var ConnToNet = false;
var xmlFile;
var ADSysInfo, IsUsingAD = false;

// alerts.js
var alertButton, alertText, alertTitle, alertTimer;
var alertSound = "%wpipath%\\Audio\\SoundsScheme\\Warning.wav";
var DoCancelPause;

// updatewizard.js
var NeedUpdateWizard = 0;

// Manual
var ManualTree;
var ManualSection = "Main";
var ManualLang;

// Menu bar
var MenuBar;
var CommandsMenuBar, ConditionsMenuBar, GrayedConditionsMenuBar;

// Tool bars
var MainToolBar, OptionsToolBar;

// Windows
var dhxWins, ActiveWindow, OldActiveWindow, BlockWindow;
var AlertWindow;
var OptionsWindow, ConfigWindow, NetworkWindow, ThemeWindow;
var ReadMeWindow, InfoWindow, ManualWindow, AboutWindow, UpdateWindow;
var SubWizardWindow;
var StatusBar;

// Tabs
var optionsTabs, configTabs, networkTabs, themeTabs;
var informationTabs, AboutTabs;
var powerTabs;

// ComboBox
var InstallBgsSkinCombo, ProgBarsSkinCombo;
var LanguageCombo;

// Grids
var ConfigurationsGrid, SortOrderGrid, AudioGrid;
var NavGrid, CommandsGrid;
var UsersGrid, IPAddressesGrid, DefaultGatewaysGrid, DNSServersGrid, WINSServersGrid;
var ArchitectureGrid, HardwareGrid, MyComputerGrid, VariablesGrid, ConditionsGrid, JScriptGrid;
var SortingState = [];
SortingState[0] = "1";
SortingState[1] = "asc";

// Sliders
var VolumeSlider;
var LowBatterySlider, CriticalBatterySlider;
var TitleFontSizeSlider, BodyFontSizeSlider, BorderSizeSlider, TransitionDurationSlider, TextPaddingSlider, TransparencySlider, ShadowStrengthSlider;

// Accordions
var MainNavAccordion;

// Editors
var DescriptionEditor;

// Color Pickers
var dhtmlxColorPickerLangModules =
{
}
;
var ColorPicker;

var PowerSchemes =
{
   "Scheme" : [

   // XP
   {
      // Desktop
      "MonitorAC" : 20,
      "MonitorDC" : 10,
      "HardDiskAC" : 0,
      "HardDiskDC" : 10,
      "StandbyAC" : 0,
      "StandbyDC" : 0,
      "HibernateAC" : 0,
      "HibernateDC" : 0,
      "Icon" : false,
      "Prompt" : true,
      "CloseLid" : 1,
      "PowerButton" : 3,
      "SleepButton" : 1,
      "Hibernate" : true
   }
   ,
   {
      // Laptop
      "MonitorAC" : 15,
      "MonitorDC" : 5,
      "HardDiskAC" : 30,
      "HardDiskDC" : 5,
      "StandbyAC" : 20,
      "StandbyDC" : 0,
      "HibernateAC" : 180,
      "HibernateDC" : 0,
      "Icon" : true,
      "Prompt" : true,
      "CloseLid" : 1,
      "PowerButton" : 3,
      "SleepButton" : 1,
      "Hibernate" : true
   }
   ,
   {
      // Presentation
      "MonitorAC" : 0,
      "MonitorDC" : 0,
      "HardDiskAC" : 0,
      "HardDiskDC" : 5,
      "StandbyAC" : 0,
      "StandbyDC" : 15,
      "HibernateAC" : 0,
      "HibernateDC" : 120,
      "Icon" : false,
      "Prompt" : true,
      "CloseLid" : 1,
      "PowerButton" : 3,
      "SleepButton" : 1,
      "Hibernate" : true
   }
   ,
   {
      // Always On
      "MonitorAC" : 20,
      "MonitorDC" : 15,
      "HardDiskAC" : 0,
      "HardDiskDC" : 30,
      "StandbyAC" : 0,
      "StandbyDC" : 0,
      "HibernateAC" : 0,
      "HibernateDC" : 0,
      "Icon" : false,
      "Prompt" : true,
      "CloseLid" : 1,
      "PowerButton" : 3,
      "SleepButton" : 1,
      "Hibernate" : true
   }
   ,
   {
      // Minimum Power Management
      "MonitorAC" : 15,
      "MonitorDC" : 5,
      "HardDiskAC" : 0,
      "HardDiskDC" : 15,
      "StandbyAC" : 0,
      "StandbyDC" : 5,
      "HibernateAC" : 180,
      "HibernateDC" : 0,
      "Icon" : false,
      "Prompt" : true,
      "CloseLid" : 1,
      "PowerButton" : 3,
      "SleepButton" : 1,
      "Hibernate" : true
   }
   ,
   {
      // Max Battery
      "MonitorAC" : 15,
      "MonitorDC" : 1,
      "HardDiskAC" : 0,
      "HardDiskDC" : 3,
      "StandbyAC" : 20,
      "StandbyDC" : 2,
      "HibernateAC" : 45,
      "HibernateDC" : 60,
      "Icon" : false,
      "Prompt" : true,
      "CloseLid" : 1,
      "PowerButton" : 3,
      "SleepButton" : 1,
      "Hibernate" : true
   }
   ,

   // Vista / Win7
   {
      // Balanced
      "MonitorAC" : 20,
      "MonitorDC" : 10,
      "HardDiskAC" : 20,
      "HardDiskDC" : 10,
      "StandbyAC" : 60,
      "StandbyDC" : 0,
      "HibernateAC" : 0,
      "HibernateDC" : 0,
      "Icon" : false,
      "Prompt" : true,
      "CloseLid" : 1,
      "PowerButton" : 3,
      "SleepButton" : 1,
      "Hibernate" : true
   }
   ,
   {
      // Power Saver
      "MonitorAC" : 20,
      "MonitorDC" : 10,
      "HardDiskAC" : 20,
      "HardDiskDC" : 10,
      "StandbyAC" : 60,
      "StandbyDC" : 0,
      "HibernateAC" : 0,
      "HibernateDC" : 0,
      "Icon" : false,
      "Prompt" : true,
      "CloseLid" : 1,
      "PowerButton" : 3,
      "SleepButton" : 1,
      "Hibernate" : true
   }
   ,
   {
      // High Performance
      "MonitorAC" : 20,
      "MonitorDC" : 10,
      "HardDiskAC" : 20,
      "HardDiskDC" : 10,
      "StandbyAC" : 0,
      "StandbyDC" : 0,
      "HibernateAC" : 0,
      "HibernateDC" : 0,
      "Icon" : false,
      "Prompt" : true,
      "CloseLid" : 1,
      "PowerButton" : 3,
      "SleepButton" : 1,
      "Hibernate" : true
   }
   ]
}
;
