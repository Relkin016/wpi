//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// Windows Post - Install Wizard
// main.js
//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

function HideLayers()
{
   position = "main.js";
   whatfunc = "HideLayers()";

   try
   {
      for (var i = 0; i < document.all.layergroup.childNodes.length;
      i ++ )
      {
         var node = document.all.layergroup.childNodes[i];

         if ( ! node.id || node.id.substr(0, 5) != "layer")
         continue;
         node.style.display = 'none';
      }
   }
   catch(de)
   {
      ;

   }
}

function ShowMain()
{
   position = "main.js";
   whatfunc = "ShowMain()";

   var isSaved;

   isSaved = false;
   if (isOptionsSaved && isConfigSaved)
   isSaved = true;
   else
   {
      if ( ! isOptionsSaved && Alert("", getText(txtDiscardChanges), getText(lblOK) + "|" + getText(lblCancel), "", 5, 0, 0, 0))
      isOptionsSaved = true;
      if ( ! isConfigSaved && Alert("", getText(txtDiscardChanges), getText(lblOK) + "|" + getText(lblCancel), "", 5, 0, 0, 0))
      isConfigSaved = true;
      if ( ! isThemeSaved && Alert("", getText(txtDiscardChanges), getText(lblOK) + "|" + getText(lblCancel), "", 5, 0, 0, 0))
      isThemeSaved = true;
      isSaved = (isOptionsSaved && isConfigSaved && isThemeSaved);
   }

   if (isSaved)
   {
      if (dhxWins.isWindow("OptionsWindow") || dhxWins.isWindow("ConfigWindow") || dhxWins.isWindow("ThemeWindow"))
      RefreshWPI();
   }
}

function ToggleManual()
{
   position = "main.js";
   whatfunc = "ToggleManual()";

   if ( ! dhxWins.isWindow("ManualWindow"))
   ShowManual();
   else
   ManualWindow.bringToTop();
}

function ShowManual()
{
   position = "main.js";
   whatfunc = "ShowManual()";

   var manLang = Language;

   if ( ! FileExists(wpipath + "/manual/" + Language + "/index.html"))
   manLang = "en";

   ManualWindow = dhxWins.createWindow("ManualWindow", 25, 25, 720, document.getElementById("bgpiclayer").offsetHeight - 50);
   ManualWindow.setText(getText(txtWPIManual));
   ManualWindow.center();
   ActiveWindow = ManualWindow.getText();
   dhxWins.window("ManualWindow").attachURL("file://" + wpipath + "\\manual\\" + manLang + "\\index.html");
}

function HideManual()
{
 position="main.js";
 whatfunc="HideManual()";

   if (dhxWins.isWindow("ManualWindow"))
   {
      ManualWindow.close();
      ManualWindow = null;
   }
}

function SetActiveWindow(win)
{
   position = "main.js";
   whatfunc = "SetActiveWindow()";
}

function ToggleExtraButtons()
{
   position = "main.js";
   whatfunc = "ToggleExtraButtons()";

   if (isCorporate)
   return;

   if (iseuDock)
   return;

   if (document.getElementById("ExtraButtons").style.display == 'none')
   document.getElementById("ExtraButtons").style.display = (fromHardDrive ? 'block' : 'none');
   else
   document.getElementById("ExtraButtons").style.display = 'none';
}

function ToggleGenUIDImage(id, state)
{
   position = "main.js";
   whatfunc = "ToggleGenUIDImage()";

   switch (state)
   {
      case 0 :
         document.getElementById(id).src = "../Common/imgs/ConfigButtons/GenUID_Out.jpg";
         break;

      case 1 :
         document.getElementById(id).src = "../Common/imgs/ConfigButtons/GenUID_Over.jpg";
         break;

      case 2 :
         document.getElementById(id).src = "../Common/imgs/ConfigButtons/GenUID_Down.jpg";
         break;

      case 3 :
         document.getElementById(id).src = "../Common/imgs/ConfigButtons/GenUID_Disabled.jpg";
         break;
   }
}

function ToggleFolderImage(id, state)
{
   position = "main.js";
   whatfunc = "ToggleFolderImage()";

   switch (state)
   {
      case 0 :
      document.getElementById(id).src = "../Common/imgs/ConfigButtons/Folder_Out.jpg";
      break;

      case 1 :
      document.getElementById(id).src = "../Common/imgs/ConfigButtons/Folder_Over.jpg";
      break;

      case 2 :
      document.getElementById(id).src = "../Common/imgs/ConfigButtons/Folder_Down.jpg";
      break;

      case 3 :
      document.getElementById(id).src = "../Common/imgs/ConfigButtons/Folder_Disabled.jpg";
      break;
   }
}

function ToggleUSSFImage(id, state)
{
   position = "main.js";
   whatfunc = "ToggleUSSFImage()";

   switch (state)
   {
      case 0 :
      document.getElementById(id).src = "../Common/imgs/ConfigButtons/USSF_Out.jpg";
      break;

      case 1 :
      document.getElementById(id).src = "../Common/imgs/ConfigButtons/USSF_Over.jpg";
      break;

      case 2 :
      document.getElementById(id).src = "../Common/imgs/ConfigButtons/USSF_Down.jpg";
      break;

      case 3 :
      document.getElementById(id).src = "../Common/imgs/ConfigButtons/USSF_Disabled.jpg";
      break;
   }
}

function ToggleDefaultImage(id, state)
{
   position = "main.js";
   whatfunc = "ToggleDefaultImage()";

   switch (state)
   {
      case 0 :
      document.getElementById(id).src = "../Common/imgs/ConfigButtons/DefaultImage_Out.jpg";
      break;

      case 1 :
      document.getElementById(id).src = "../Common/imgs/ConfigButtons/DefaultImage_Over.jpg";
      break;

      case 2 :
      document.getElementById(id).src = "../Common/imgs/ConfigButtons/DefaultImage_Down.jpg";
      break;

      case 3 :
      document.getElementById(id).src = "../Common/imgs/ConfigButtons/DefaultImage_Disabled.jpg";
      break;
   }
}

function TogglePlayImage(id, state)
{
   position = "main.js";
   whatfunc = "TogglePlayImage()";

   switch (state)
   {
      case 0 :
      document.getElementById(id).src = "../Common/imgs/ConfigButtons/Play_Out.jpg";
      break;

      case 1 :
      document.getElementById(id).src = "../Common/imgs/ConfigButtons/Play_Over.jpg";
      break;

      case 2 :
      document.getElementById(id).src = "../Common/imgs/ConfigButtons/Play_Down.jpg";
      break;

      case 3 :
      document.getElementById(id).src = "../Common/imgs/ConfigButtons/Play_Disabled.jpg";
      break;
   }
}

function ToggleStopImage(id, state)
{
   position = "main.js";
   whatfunc = "ToggleStopImage()";

   switch (state)
   {
      case 0 :
      document.getElementById(id).src = "../Common/imgs/ConfigButtons/Stop_Out.jpg";
      break;

      case 1 :
      document.getElementById(id).src = "../Common/imgs/ConfigButtons/Stop_Over.jpg";
      break;

      case 2 :
      document.getElementById(id).src = "../Common/imgs/ConfigButtons/Stop_Down.jpg";
      break;

      case 3 :
      document.getElementById(id).src = "../Common/imgs/ConfigButtons/Stop_Disabled.jpg";
      break;
   }
}

function ToggleColorPickerImage(id, state)
{
   position = "main.js";
   whatfunc = "ToggleColorPickerImage()";

   switch (state)
   {
      case 0 :
      document.getElementById(id).src = "../Common/imgs/ConfigButtons/ColorPicker_Out.jpg";
      break;

      case 1 :
      document.getElementById(id).src = "../Common/imgs/ConfigButtons/ColorPicker_Over.jpg";
      break;

      case 2 :
      document.getElementById(id).src = "../Common/imgs/ConfigButtons/ColorPicker_Down.jpg";
      break;

      case 3 :
      document.getElementById(id).src = "../Common/imgs/ConfigButtons/ColorPicker_Disabled.jpg";
      break;
   }
}

function FillInPathBox(path)
{
   position = "main.js";
   whatfunc = "FillInPathBox()";

   if (document.getElementById("PathBox"))
   document.getElementById("PathBox").innerHTML = path;
}

function FillInNumItems()
{
   position = "main.js";
   whatfunc = "FillInNumItems()";

   if (document.getElementById("NumItems"))
   document.getElementById("NumItems").innerHTML = "" + numChecked + "/" + (prog.length == 0 ? "0" : (prog.length - 2));
}
