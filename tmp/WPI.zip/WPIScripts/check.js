//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// Windows Post - Install Wizard
// check.js
//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

function isChecked(i)
{
   position = "check.js";
   whatfunc = "isChecked()";

   var elem;

   if (isCategory(i))
   elem = document.getElementById("Cat" + i);
   else
   elem = document.getElementById("chkbox" + i);

   if (elem == null)
   return false;

   if (elem.checked)
   return true;
   else
   return false;
}

function isCategory(i)
{
   position = "check.js";
   whatfunc = "isCategory()";

   var numbers = " 0123456789.";
   var isString = false;
   var j, char;

   if (typeof(i) == "number")
   return false;

   for (j = 0; j < i.length && ! isString; j ++ )
   {
      char = i.charAt(j);
      if (numbers.indexOf(char) == - 1)
      isString = true;
   }

   return isString;
}

function setEnabled(i)
{
   position = "check.js";
   whatfunc = "setEnabled()";

   var elem = document.getElementById("chkbox" + i);

   if (elem == null)
   return;
   if (deps[i] && DisableOnDepsNotMet && ! parentsAreChecked(i))
   return;
   if (excludorIsChecked(i))
   return;
   elem.disabled = false;
   if (LayoutStyle == 4)
   RefreshElement4(i);
   tabs ++ ;
   enableChildren(i);
   tabs -- ;
}

function setDisabled(i)
{
   position = "check.js";
   whatfunc = "setDisabled()";

   var elem = document.getElementById("chkbox" + i);

   if (elem == null)
   return;
   elem.disabled = true;
   if (LayoutStyle == 4)
   RefreshElement4(i);
   tabs ++ ;
   disableChildren(i);
   tabs -- ;
}

function setChecked(i)
{
   position = "check.js";
   whatfunc = "setChecked()";

   var elem, lbl;

   if (isCategory(i))
   {
      elem = document.getElementById("Cat" + i);

      if (elem == null)
      return;
      if (elem.disabled)
      return;
      elem.checked = true;
      numChecked ++ ;
   }
   else
   {
      elem = document.getElementById("chkbox" + i);
      lbl = document.getElementById("lbl" + i);

      if (elem == null)
      return;
      if (elem.disabled)
      return;
      elem.checked = true;
      numChecked ++ ;
      if (LayoutStyle == 4)
      RefreshElement4(i);
      if (lbl.value == "Forced")
      lbl.className = ((LayoutStyle == 1 || LayoutStyle == 3) ? 'forcedTxt' : 'forcedTxt_logo');
      else if (lbl.value == "IsGray")
      lbl.className = ((LayoutStyle == 1 || LayoutStyle == 3) ? 'grayTxt' : 'grayTxt_logo');
      else
      lbl.className = ((LayoutStyle == 1 || LayoutStyle == 3) ? 'checkedTxt' : 'checkedTxt_logo');
      tabs ++ ;
      checkParent(i);
      if (DisableOnDepsNotMet)
      enableChildren(i);
      checkExclusions(i);
      tabs -- ;
   }
}

function setUnchecked(i)
{
   position = "check.js";
   whatfunc = "setUnchecked()";

   var elem, lbl;

   if (isCategory(i))
   {
      elem = document.getElementById("Cat" + i);

      if (elem == null)
      return;
      elem.checked = false;
   }
   else
   {
      elem = document.getElementById("chkbox" + i);
      lbl = document.getElementById("lbl" + i);

      if (elem == null)
      return;
      if (forc[i] != null && forc[i] == 'yes')
      return;
      elem.checked = false;
      if (LayoutStyle == 4)
      RefreshElement4(i);
      if (lbl.value == "Forced")
      lbl.className = ((LayoutStyle == 1 || LayoutStyle == 3) ? 'forcedTxt' : 'forcedTxt_logo');
      else if (lbl.value == "IsGray")
      lbl.className = ((LayoutStyle == 1 || LayoutStyle == 3) ? 'grayTxt' : 'grayTxt_logo');
      else
      lbl.className = ((LayoutStyle == 1 || LayoutStyle == 3) ? 'txt' : 'txt_logo');
      tabs ++ ;
      uncheckChildren(i);
      if (DisableOnDepsNotMet)
      disableChildren(i);
      checkExclusions(i);
      tabs -- ;
   }
}

function toggleChecked(i)
{
   position = "check.js";
   whatfunc = "toggleChecked()";

   var elem;

   if (isCategory(i))
   elem = document.getElementById("Cat" + i);
   else
   elem = document.getElementById("chkbox" + i);

   if (elem == null)
   return;
   if (elem.disabled)
   return;

   if (elem.checked)
   setUnchecked(i);
   else
   setChecked(i);

   CountChecks();
}

function check(se)
{
   position = "check.js";
   whatfunc = "check()";

   var elem, i, DoGray;
   var splits;

   tabs = 0;
   tabs ++ ;
   for (i = 1; prog[i] != null; i ++ )
   {
      elem = document.getElementById("chkbox" + i);

      if (elem == null)
      continue;
      if (elem.disabled)
      continue;

      tabs ++ ;
      if (forc[i] != null && forc[i] == "yes")
      {
         setChecked(i);
         checkDeps(i);
      }
      else if (se == "all")
      {
         setChecked(i);
         checkDeps(i);
      }
      else if (se == "none")
      setUnchecked(i);
      else if (se == "default")
      {
         if (dflt[i] && dflt[i][0] == 'yes')
         {
            DoGray = 0;
            if (gcond[i] && gcond[i][0])
            {
               var d = unescape(ReplacePath(gcond[i][0]).replace(/\\/g, "\\\\"));

               DoGray = eval(d) ? 1 : 0;
               if (DoGray)
               setUnchecked(i);
               else
               {
                  setChecked(i);
                  checkDeps(i);
               }
            }
            else
            {
               setChecked(i);
               checkDeps(i);
            }
         }
         else
         setUnchecked(i);
      }
      else
      {
         // specified category
         setUnchecked(i);

         splits = configs[i][0].split(",");
         for (var j = 0; j < splits.length; j ++ )
         {
            if (splits[j] == se)
            {
               setChecked(i);
               checkDeps(i);
            }
         }
      }

      tabs -- ;
   }
   tabs -- ;
   initialization = false;

   CheckCatIfAllChecked();
}

function remChecks()
{
   position = "check.js";
   whatfunc = "remChecks()";

   var i, elem;

   for (i = 1; prog[i] != null; i ++ )
   {
      elem = document.getElementById("chkbox" + i);

      if (elem == null || forc[i] == "yes")
      continue;

      elem.checked = false;
      if (LayoutStyle == 4)
      RefreshElement4(i);
   }
}

function checkDeps(i)
{
   position = "check.js";
   whatfunc = "checkDeps()";

   var elem;

   tabs ++ ;

   elem = document.getElementById("chkbox" + i);

   if (elem == null)
   return;
   if (elem.disabled)
   {
      if (forc[i] != null && forc[i] == 'yes')
      return;
      elem.checked = false;
      if (LayoutStyle == 4)
      RefreshElement4(i);

      return 0;
   }

   rekArray = [];
   if (elem.checked)
   setChecked(i);
   else
   setUnchecked(i);
   rekArray = [];
   tabs -- ;

   CountChecks();
}

function checkAllDeps()
{
   position = "check.js";
   whatfunc = "checkAllDeps()";

   var elem, i;

   for (i = 1; prog[i] != null && deps[i] != null;
   i ++ )
   {
      elem = document.getElementById("chkbox" + i);

      if (elem == null)
      continue;
      if (elem.disabled)
      continue;

      checkDeps(i);
   }

   CheckCatIfAllChecked();
}

function checkParent(i)
{
   position = "check.js";
   whatfunc = "checkParent()";

   var j, k, DoGray;

   if ( ! uid[i])
   return;

   tabs ++ ;
   if (deps[i] != null)
   {
      for (j = 0; deps[i][j] != null; j ++ )
      {
         k = 1;
         while (prog[k] != null && (uid[k] == null || uid[k] != deps[i][j]))
         k ++ ;

         if (prog[k] != null)
         {
            DoGray = 0;
            if (gcond[k] && gcond[k][0])
            {
               var d = unescape(ReplacePath(gcond[k][0]).replace(/\\/g, "\\\\"));

               DoGray = eval(d) ? 1 : 0;
               if (DoGray)
               continue;
               // do nothing... dependency is already installed
               else
               setChecked(k);
            }
            else
            setChecked(k);
         }
      }
   }
   tabs -- ;
}

function uncheckChildren(i)
{
   position = "check.js";
   whatfunc = "uncheckChildren()";

   var j, k;

   if ( ! uid[i])
   return;

   tabs ++ ;
   for (j = 1; prog[j] != null; j ++ ) // run through all progs
   {
      for (k = 0; deps[j] != null && deps[j][k] != null;
      k ++ ) // run through 'parent' defines
      {
         if (deps[j][k] == uid[i])
         setUnchecked(j);
      }
   }
   tabs -- ;
}

function enableChildren(i)
{
   position = "check.js";
   whatfunc = "enableChildren()";

   var j, k;

   if ( ! uid[i])
   return;

   tabs ++ ;
   for (j = 1; prog[j] != null; j ++ ) // run through all progs
   {
      for (k = 0; deps[j] != null && deps[j][k] != null;
      k ++ ) // run through 'parent' defines
      {
         if (deps[j][k] == uid[i] && parentsAreChecked(j))
         setEnabled(j);
      }
   }
   tabs -- ;
}

function parentsAreChecked(i)
{
   position = "check.js";
   whatfunc = "parentsAreChecked()";

   for (var j = 0; deps[i] && j < deps[i].length;
   j ++ ) // run through all dependencies of prog[i]
   {
      var itemIndex = findProgByUID(deps[i][j]);

      if (itemIndex > 0)
      {
         var itemCheckbox = document.getElementById("chkbox" + itemIndex);

         if ( ! itemCheckbox.checked || itemCheckbox.disabled)
         return false;
      }
   }

   return true;
}

function parentsAreEnabled(i)
{
   position = "check.js";
   whatfunc = "parentsAreEnabled()";

   var j, elem;

   for (j = 0; deps[i] && j < deps[i].length; j ++ ) // run through all dependencies of prog[i]
   {
      var itemIndex = findProgByUID(deps[i][j]);

      if (itemIndex > 0 && document.getElementById("chkbox" + itemIndex).disabled)
      return false;
   }

   return true;
}

function excludorIsChecked(i)
{
   position = "check.js";
   whatfunc = "excludorIsChecked()";

   var j, k, elem;

   for (j = 1; prog[j]; j ++ ) // run through all progs
   {
      for (k = 0; excl[j] && k < excl[j].length; k ++ ) // run through all exclusions of prog[j]
      {
         if (uid[i] && uid[i] == excl[j][k])
         {
            // find parent's checkbox
            try
            {
               elem = document.getElementById("chkbox" + j);

               if (elem.checked)
               return true;
            }
            catch(ex)
            {
               return false;
            }
         }
      }
   }

   return false;
}

function disableChildren(i)
{
   position = "check.js";
   whatfunc = "disableChildren()";

   var j, k;

   if ( ! uid[i])
   return;

   tabs ++ ;
   for (j = 1; prog[j]; j ++ ) // run through all progs
   {
      for (k = 0; deps[j] && deps[j][k]; k ++ ) // run through 'parent' defines
      {
         if (deps[j][k] == uid[i])
         setDisabled(j);
      }
   }
   tabs -- ;
}

function checkExclusions(i)
{
   position = "check.js";
   whatfunc = "checkExclusions()";

   var n, k;
   // 	var nArray = new Array();
   var elem = document.getElementById("chkbox" + i);

   if (elem == null)
   return;

   if ( ! excl[i])
   return;
   tabs ++ ;

   for (k = 0; k < rekArray.length; k ++ )
   {
      if (rekArray[k] == i)
      return;
   }

   rekArray.push(i);

   if (elem.checked) // ... disable excluded programs
   {
      for (n = 0; excl[i][n]; n ++ )
      {
         tabs ++ ;
         k = findProgByUID(excl[i][n]);
         if (k <= 0)
         continue;
         setUnchecked(k);
         setDisabled(k);
         tabs -- ;
      }
   }
   else // ... enable excluded programs, if possible
   {
      for (n = 0; excl[i][n] != null; n ++ )
      {
         tabs ++ ;
         k = findProgByUID(excl[i][n]);
         if (k <= 0)
         continue;
         setEnabled(k);
         tabs -- ;
      }

   }
   tabs -- ;
}

function checkCategory(thisChk)
{
   position = "check.js";
   whatfunc = "checkCategory()";

   var allChked = true;
   var state = isChecked(thisChk);
   var i, thisCat;

   if (isCategory(thisChk)) // If category checkbox was checked
   {
      thisCat = thisChk;

      for (i = 1; cat[i] != null; i ++ )
      {
         if (cat[i] == thisCat)
         {
            if (state)
            {
               setChecked(i);
               checkDeps(i);
            }
            else
            {
               setUnchecked(i);
               checkDeps(i);
            }
         }
      }
   }

   else // If program checkbox was checked
   {
      if ( ! prog[thisChk] || document.getElementById("chkbox" + thisChk) == null)
      return;
      // Ensure checkbox exists
      thisCat = cat[thisChk].toString();
   }

   if (state)
   {
      for (i = 1; cat[i] != null; i ++ )
      {
         if (cat[i] == thisCat && document.getElementById("chkbox" + i) != null)
         {
            if ( ! isChecked(i))
            {
               allChked = false;
               break;
            }
         }
      }
   }

   if (state && allChked)
   setChecked(thisCat);
   else
   setUnchecked(thisCat);

   CountChecks();
}

function findProgByUID(s_uid)
{
   position = "check.js";
   whatfunc = "findProgByUID()";

   var i;

   for (i = 1; prog[i] != null; i ++ )
   {
      if (uid[i] && uid[i] == s_uid)
      return i;
   }

   return 0;
}

function CountChecks()
{
   position = "check.js";
   whatfunc = "CountChecks()";

   var i, elem;

   if (FirstCount)
   return;

   numChecked = 0;
   for (i = 1; prog[i] != null; i ++ )
   {
      elem = document.getElementById("chkbox" + i);

      if (elem == null)
      continue;
      if (elem.checked)
      numChecked ++ ;
   }

   FillInNumItems();
}
