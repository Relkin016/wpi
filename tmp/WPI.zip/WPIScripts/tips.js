//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// Windows Post - Install Wizard
// tips.js
//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

function SetupTips(s)
{
   position = "tips.js";
   whatfunc = "SetupTips()";

   mig_clay();

   titCol = s[0] ? "COLOR='"+s[0]+"'" : "";
   titBgCol = s[1] && ! s[2] ? "BGCOLOR='"+s[1]+"'" : "";
   titBgImg = s[2] ? "BACKGROUND='"+wpipath+"\\Graphics\\ToolTipsBgs\\"+s[2]+"'" : "";
   if (FileExists(wpipath + "\\Themes\\" + Theme + "\\ToolTipsTitleBg.png"))
   titBgImg = "BACKGROUND='"+wpipath+"\\Themes\\"+Theme+"\\ToolTipsTitleBg.png'";
   titTxtAli = s[3] ? "ALIGN='"+s[3]+"'" : "";
   txtCol = s[6] ? "COLOR='"+s[6]+"'" : "";
   txtBgCol = s[7] && ! s[8] ? "BGCOLOR='"+s[7]+"'" : "";
   txtBgImg = s[8] ? "BACKGROUND='"+wpipath+"\\Graphics\\ToolTipsBgs\\"+s[8]+"'" : "";
   if (FileExists(wpipath + "\\Themes\\" + Theme + "\\ToolTipsBodyBg.png"))
   txtBgImg = "BACKGROUND='"+wpipath+"\\Themes\\"+Theme+"\\ToolTipsBodyBg.png'";
   txtTxtAli = s[9] ? "ALIGN='"+s[9]+"'" : "";
   tipHeight = s[13] ? "HEIGHT='"+s[13]+"'" : "";
   brdCol = s[15] ? "BGCOLOR='"+s[15]+"'" : "";

   if ( ! s[4])
   s[4] = "Arial,Helvetica,Verdana";
   if ( ! s[5])
   s[5] = 1;
   if ( ! s[10])
   s[10] = "Arial,Helvetica,Verdana";
   if ( ! s[11])
   s[11] = 1;
   if ( ! s[12])
   s[12] = 200;
   if ( ! s[14])
   s[14] = 0;
   if ( ! s[16])
   s[16] = 0;
   if ( ! s[24])
   s[24] = 10;
   if ( ! s[25])
   s[25] = 10;
   hs = s[22];
}

function qdh(t, d, s)
{
   position = "tips.js";
   whatfunc = "qdh()";

   if (d == null)
   return;
   else
   stm([t, d], s);
}

function mig_hand()
{
   position = "tips.js";
   whatfunc = "mig_hand()";

   if (MI_sNav)
   {
      window.onresize = mig_re;
      document.onmousemove = mig_mo;
   }
}

function mig_cssf()
{
   position = "tips.js";
   whatfunc = "mig_cssf()";

   if (MI_IE >= 5.5)
   {
      fl = 1;

      var d = " progid:DXImageTransform.Microsoft.";

     mig_layCss().filter="revealTrans()"+d+"Fade(Overlap=1.0 enabled=0)"+d+"Inset(enabled=0)"+d+"Iris(irisstyle=SQUARE,motion=in enabled=0)"+d+"Iris(irisstyle=SQUARE,motion=out enabled=0)"+d+"Iris(irisstyle=PLUS,motion=in enabled=0)"+d+"Iris(irisstyle=PLUS,motion=out enabled=0)"+d+"Iris(irisstyle=DIAMOND,motion=in enabled=0)"+d+"Iris(irisstyle=DIAMOND,motion=out enabled=0)"+d+"Iris(irisstyle=CIRCLE,motion=in enabled=0)"+d+"Iris(irisstyle=CIRCLE,motion=out enabled=0)"+d+"Iris(irisstyle=CROSS,motion=in enabled=0)"+d+"Iris(irisstyle=CROSS,motion=out enabled=0)"+d+"Iris(irisstyle=STAR,motion=in enabled=0)"+d+"Iris(irisstyle=STAR,motion=out enabled=0)"+d+"RadialWipe(wipestyle=CLOCK enabled=0)"+d+"RadialWipe(wipestyle=WEDGE enabled=0)"+d+"RadialWipe(wipestyle=RADIAL enabled=0)"+d+"Pixelate(MaxSquare=35,enabled=0)"+d+"Slide(slidestyle=HIDE,Bands=25 enabled=0)"+d+"Slide(slidestyle=PUSH,Bands=25 enabled=0)"+d+"Slide(slidestyle=SWAP,Bands=25 enabled=0)"+d+"Spiral(GridSizeX=16,GridSizeY=16 enabled=0)"+d+"Stretch(stretchstyle=HIDE enabled=0)"+d+"Stretch(stretchstyle=PUSH enabled=0)"+d+"Stretch(stretchstyle=SPIN enabled=0)"+d+"Wheel(spokes=16 enabled=0)"+d+"GradientWipe(GradientSize=1.0,wipestyle=0,motion=forward enabled=0)"+d+"GradientWipe(GradientSize=1.0,wipestyle=0,motion=reverse enabled=0)"+d+"GradientWipe(GradientSize=1.0,wipestyle=1,motion=forward enabled=0)"+d+"GradientWipe(GradientSize=1.00,wipestyle=1,motion=reverse enabled=0)"+d+"Zigzag(GridSizeX=8,GridSizeY=8 enabled=0)"+d+"Alpha(enabled=0)"+d+"Dropshadow(OffX=3,OffY=3,Positive=true,enabled=0)"+d+"Shadow(strength="+TipShadowStrength+",direction=135,enabled=0)";
   }
}

function stm(t, s)
{
   position = "tips.js";
   whatfunc = "stm()";

   if ( ! ShowToolTips)
   return;

   if (MI_sNav && isOK)
   {
      if (document.onmousemove != mig_mo || window.onresize != mig_re)
      mig_hand();
      if (fl && s[17] > 0 && s[18] > 0)
      mig_layCss().visibility = "hidden";

if (fl && s[23]>0 && s[23]<3)  
     return;
     
      var ab = "", ap = "";

      if (MI_pSub == 20001108)
      {
         if (s[14])
         ab = "STYLE='border:"+s[14]+"px solid"+" "+s[15]+"'";
         ap = "STYLE='padding:"+s[16]+"px "+s[16]+"px "+s[16]+"px "+s[16]+"px'";
      }

      var closeLink = hs == 3 ? "<TD ALIGN='right' style='font-size:"+s[5]+"pt;'><FONT FACE='"+s[4]+"'><A HREF='javascript:void(0)' ONCLICK='mig_hide(0)' STYLE='text-decoration:none;color:"+s[0]+"'><B>" + getText(tipClose) + "</B></A></FONT></TD>" : "";
      var title = t[0] || hs == 3 ? "<TABLE WIDTH='100%' BORDER='0' CELLPADDING='0' CELLSPACING='0' " + titBgCol + " " + titBgImg + "><TR><TD " + titTxtAli + " style='font-size:"+s[5]+"pt;'><FONT FACE='"+s[4]+"' " + titCol + "><B>" + t[0] + "</B></FONT></TD>" + closeLink + "</TR></TABLE>" : "";
      var txt = "<TABLE " + ab + " WIDTH='"+s[12]+"' BORDER='0' CELLSPACING='0' CELLPADDING='"+s[14]+"' " + brdCol + "><TR><TD>" + title + "<TABLE WIDTH='100%' " + tipHeight + " BORDER='0' CELLPADDING='"+s[16]+"' CELLSPACING='0' " + txtBgCol + " " + txtBgImg + "><TR><TD " + txtTxtAli + " " + ap + " VALIGN='top' style='font-size:"+s[11]+"pt;'><FONT FACE='"+s[10]+"' " + txtCol + ">" + t[1] + "</FONT></TD></TR></TABLE></TD></TR></TABLE>";

      mig_wlay(txt);
      tb =
      {
         trans : s[17],
         dur : s[18],
         opac : s[19],
         st : s[20],
         sc : s[21],
         pos : s[23],
         xpos : s[24],
         ypos : s[25]
      }
      ;
      e_d = mig_ed();
      Count = 0;
      move = 1;
   }
}

function htm()
{
   position = "tips.js";
   whatfunc = "htm()";

   if (MI_sNav && isOK)
   {
      if (hs != 4)
      {
         move = 0;
         if (hs != 3 && hs != 2)
         mig_hide(1);
      }
   }
}

function mig_mo(e)
{
   position = "tips.js";
   whatfunc = "mig_mo()";

   if (move)
   {
      var X = 0, Y = 0, s_d = mig_scd(), w_d = mig_wd();
      var mx = event.x + s_d[0];
      var my = event.y + s_d[1];

      switch(tb.pos)
      {
         case 1 :
            X = mx - e_d[0] - tb.xpos + 6;
            Y = my + tb.ypos;
            break;

         case 2 :
            X = mx - (e_d[0] / 2);
            Y = my + tb.ypos;
            break;

         case 3 :
            X = tb.xpos + s_d[0];
            Y = tb.ypos + s_d[1];
            break;

         case 4 :
            X = tb.xpos;
            Y = tb.ypos;
            break;

         case 0 :
         default :
            X = mx + tb.xpos;
            Y = my + tb.ypos;
            break;
      }
      if (w_d[0] + s_d[0] < e_d[0] + X + sbw)
      X = w_d[0] + s_d[0] - e_d[0] - sbw;
      if (w_d[1] + s_d[1] < e_d[1] + Y + sbw)
      {
         if (tb.pos > 2)
         Y = w_d[1] + s_d[1] - e_d[1] - sbw;
         else
         Y = my - e_d[1];
      }
      if (X < s_d[0])
      X = s_d[0];
      with(mig_layCss())
      {
         left = X + PX;
         top = Y + PX;
      }
      mig_dis();
   }
}

function mig_dis()
{
   position = "tips.js";
   whatfunc = "mig_dis()";

   Count ++ ;
   if (Count == 1)
   {
      if (fl)
      {
         if (tb.trans == 50)
         tb.trans = parseInt(Math.random() * 50);

         var at=tb.trans>=0 && tb.trans<24 && tb.dur>0;
         var af = tb.trans > 23 && tb.trans < 51 && tb.dur > 0;
         var t = mig_lay().filters[af ? tb.trans - 23 : 0];

         for(var p = 28; p < 31; p ++ )
         {
            mig_lay().filters[p].enabled = 0;
         }
         for(var s = 0; s < 28; s ++ )
         {
            if (mig_lay().filters[s].status)
            mig_lay().filters[s].stop();
         }
         for(var e = 1; e < 3; e ++ )
         {
            if (tb.sc && tb.st == e)
            {
               with(mig_lay().filters[28 + e])
               {
                  enabled = 1;
                  color = tb.sc;
               }
            }
         }
         if (tb.opac > 0 && tb.opac < 100)
         {
            with(mig_lay().filters[28])
            {
               enabled = 1;
               opacity = tb.opac;
            }
         }
         if (at || af)
         {
            if (at)
            mig_lay().filters[0].transition = tb.trans;
            t.duration = tb.dur;
            t.apply();
         }
      }
      mig_layCss().visibility = "visible";
      if (fl && (at || af))
      t.play();
      if (hs > 0 && hs < 4)
      move = 0;
   }
}

function mig_layCss()
{
   position = "tips.js";
   whatfunc = "mig_layCss()";

   return mig_lay().style;
}

function mig_lay()
{
   position = "tips.js";
   whatfunc = "mig_lay()";

   with(document)
   return getElementById(TipId);
}

function mig_wlay(txt)
{
   position = "tips.js";
   whatfunc = "mig_wlay()";

   mig_lay().innerHTML = txt;
}

function mig_hide(C)
{
   position = "tips.js";
   whatfunc = "mig_hide()";

   if ( ! MI_NN4 || MI_NN4 && C)
   mig_wlay("");
   with(mig_layCss())
   {
      visibility = "hidden";
      left = 0;
      top = - 800;
   }
}

function mig_scd()
{
   position = "tips.js";
   whatfunc = "mig_scd()";

   return [parseInt(MI_IE ? eval(d_r).scrollLeft : window.pageXOffset), parseInt(MI_IE ? eval(d_r).scrollTop : window.pageYOffset)];
}

function mig_re()
{
   position = "tips.js";
   whatfunc = "mig_re()";

   var w_d = mig_wd();

   if (hs == 3 || hs == 2)
   mig_hide(1);
}

function mig_wd()
{
   position = "tips.js";
   whatfunc = "mig_wd()";

   return [parseInt(MI_ONN ? window.innerWidth : eval(d_r).clientWidth), parseInt(MI_ONN ? window.innerHeight : eval(d_r).clientHeight)];
}

function mig_ed()
{
   position = "tips.js";
   whatfunc = "mig_ed()";

   return [parseInt(mig_lay().offsetWidth) + 3, parseInt(mig_lay().offsetHeight) + 5];
}

function mig_clay()
{
   position = "tips.js";
   whatfunc = "mig_clay()";

   if ( ! mig_lay())
   {
      isOK = 0;
      alert("DHTML TIP MESSAGE VERSION 1.5 ERROR NOTICE.\n<DIV ID=\""+TipId+"\"></DIV> tag missing or its ID has been altered");
   }
   else
   {
      mig_hand();
      mig_cssf();
   }
}
