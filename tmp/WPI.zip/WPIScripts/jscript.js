//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// Windows Post - Install Wizard
// jscript.js
//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

function TimedWaitForFile(filename, timeout)
{
   position = "jscript.js";
   whatfunc = "TimedWaitForFile()";

   var count = 0;

   while( ! FileExists(filename) && count < timeout)
   {
      count ++ ;
      Pause(1, 0);
   }
   if (FileExists(filename))
   return false;

   return true;
}

function TimedWaitForDelete(delay, filename, timeout)
{
   position = "jscript.js";
   whatfunc = "TimedWaitForDelete()";

   var count = 0;

   Pause(delay, 0);

   while(FileExists(filename) && count < timeout)
   {
      count ++ ;
      Pause(1, 0);
   }
   if ( ! FileExists(filename))
   return true;

   return false;
}

function TimedWaitForWindow(WindowName,HowLong)
{
 	position="jscript.js";
	whatfunc="TimedWaitForWindow()";
	
	RunCmd('"' + wpipath + '\\Tools\\WPI Tool.exe" /Action=WaitForWindow /WindowName="' + WindowName + '" /Timeout=' + HowLong, false, true);
}

function getEnvVar(envvar)
{
   position = "jscript.js";
   whatfunc = "getEnvVar()";

   return WshEnv(envvar);
}

function SetAppAsDefault(ProgId)
{
	position="jscript.js";
	whatfunc="SetAppAsDefault()";

	RunCmd('"' + wpipath + '\\Tools\\WPI Tool.exe" /Action=SetAppAsDefaultAll /ProgId="' + ProgId + '"', false, true);
}

function setEnvVar(envvar, value, global)
{
   position = "jscript.js";
   whatfunc = "setEnvVar()";

   try
   {
      if (global)
      {
         oSysEnv = WshShell.Environment("SYSTEM");
         oSysEnv(envvar) = value;
      }

      oSysEnv = WshShell.Environment("PROCESS");
      oSysEnv(envvar) = value;
   }
   catch(ex)
   {
      ;

   }
}

function removeEnvVar(envvar)
{
   position = "jscript.js";
   whatfunc = "removeEnvVar()";

   try
   {
      oSysEnv = WshShell.Environment("SYSTEM");
      oSysEnv.Remove(envvar);
   }
   catch(ex)
   {
      ;

   }
}

function FormatDrive(Drive, Label, FileSystem, ClusterSize, QuickFormat, Compress)
{
   position = "jscript.js";
   whatfunc = "FormatDrive()";

   try
   {
      RunCmd('CMD /C "format" ' + Drive + ' /fs:' + FileSystem + ' /v:' + Label + ' /a:' + ClusterSize + (QuickFormat ? ' /q' : '') + (Compress ? ' /c' : '') + ' /x', true, true);
   }
   catch(ex)
   {
      return false;
   }

   return true;
}

function CreateShortcut(Description, IconLocation, Hotkey, TargetPath, Arguments, SpecialFolder, SubFolder)
{
   position = "jscript.js";
   whatfunc = "CreateShortcut()";

   var txt;

   if (SpecialFolder == "QuickLaunch")
   {
      tf = fso.GetFolder(WshShell.SpecialFolders.Item("PrintHood")).ParentFolder
      strSpecialFolders = tf.Path + "\\Application Data\\Microsoft\\Internet Explorer\\Quick Launch";
   }
   else
   strSpecialFolders = WshShell.SpecialFolders(SpecialFolder);
   txt = strSpecialFolders + "\\";
   if (SpecialFolder == "Favorites" || SpecialFolder == "MyDocuments" || SpecialFolder == "StartMenu" || SpecialFolder == "Programs" || SpecialFolder == "AllUsersStartMenu" || SpecialFolder == "AllUsersPrograms")
   {
      if ( ! (fso.FolderExists(strSpecialFolders + "\\" + SubFolder)) && SubFolder.length != 0)
      {
         fso.CreateFolder(strSpecialFolders + "\\" + SubFolder);
      }
      txt += SubFolder + "\\";
   }
   txt += Description + ".lnk";

   try
   {
      oShellLink = WshShell.CreateShortcut(txt);
      oShellLink.Description = Description;
      oShellLink.IconLocation = ReplacePath(IconLocation) + ",0";
      oShellLink.Hotkey = Hotkey;
      oShellLink.TargetPath = ReplacePath(TargetPath);
      oShellLink.Arguments = ReplacePath(Arguments).replace(/#quote#/gi, '"');
      oShellLink.WindowStyle = 1;
      oShellLink.WorkingDirectory = "";
      oShellLink.Save();

      return true;
   }
   catch(ex)
   {
      return false;
   }
}

function RenameComputer(ComputerName)
{
   position = "jscript.js";
   whatfunc = "RenameComputer()";

   try
   {
      objWMIService = GetObject("winmgmts:\\\\" + "." + "\\root\\CIMV2");
      colItems = objWMIService.ExecQuery("SELECT * FROM Win32_ComputerSystem", "WQL", wbemFlagReturnImmediately | wbemFlagForwardOnly);

      enumItems = new Enumerator(colItems);
      for (; ! enumItems.atEnd(); enumItems.moveNext())
      {
         objItem = enumItems.item();
         objItem.rename(ComputerName);
      }
   }
   catch(ex)
   {
      return false;
   }

   return true;
}

function CreateWindowsUser(UserName, UserPassword, Administrator)
{
   position = "jscript.js";
   whatfunc = "CreateWindowsUser()";

   try
   {
      RunCmd('CMD /C net user ' + UserName + ' ' + (UserPassword != '' ? UserPassword : '/Passwordreq:no') + ' /add', false, true);

      if (Administrator)
      RunCmd('CMD /C net localgroup Administrators ' + UserName + ' /add', false, true);
   }
   catch(ex)
   {
      return false;
   }

   return true;
}

function DeleteWindowsUser(UserName, DeleteFiles)
{
   position = "jscript.js";
   whatfunc = "DeleteWindowsUser()";

   var txt;

   try
   {
      RunCmd('CMD /C net user ' + UserName + ' /delete', false, true);

      if (DeleteFiles)
      RunCmd('CMD /C rd /S /Q "%userprofileroot%\\'+UserName+'"', false, true);
   }
   catch(ex)
   {
      return false;
   }

   return true;
}

function JoinWorkgroup(Workgroup)
{
   position = "jscript.js";
   whatfunc = "JoinWorkgroup()";

   try
   {
      objWMIService = GetObject("winmgmts:\\\\" + "." + "\\root\\CIMV2");
      colItems = objWMIService.ExecQuery("SELECT * FROM Win32_ComputerSystem", "WQL", wbemFlagReturnImmediately | wbemFlagForwardOnly);

      enumItems = new Enumerator(colItems);
      for (; ! enumItems.atEnd(); enumItems.moveNext())
      {
         objItem = enumItems.item();
         objItem.JoinDomainOrWorkgroup(Workgroup, "", "");
      }
   }
   catch(ex)
   {
      return false;
   }

   return true;
}

function JoinDomain(Domain, UserName, UserPassword)
{
   position = "jscript.js";
   whatfunc = "JoinDomain()";

   try
   {
      objWMIService = GetObject("winmgmts:\\\\" + "." + "\\root\\CIMV2");
      colItems = objWMIService.ExecQuery("SELECT * FROM Win32_ComputerSystem", "WQL", wbemFlagReturnImmediately | wbemFlagForwardOnly);

      enumItems = new Enumerator(colItems);
      for (; ! enumItems.atEnd(); enumItems.moveNext())
      {
         objItem = enumItems.item();
         objItem.JoinDomainOrWorkgroup(Domain, UserPassword, Domain + "\\" + UserName, null, 3);
      }
   }
   catch(ex)
   {
      return false;
   }

   return true;
}

function GetPageFileInfo()
{
   position = "jscript.js";
   whatfunc = "GetPageFileInfo()";

   try
   {
      objWMIService = GetObject("winmgmts:\\\\" + "." + "\\root\\CIMV2");
      colItems = objWMIService.ExecQuery("SELECT * FROM Win32_PageFileSetting", "WQL", wbemFlagReturnImmediately | wbemFlagForwardOnly);

      enumItems = new Enumerator(colItems);
      for (; ! enumItems.atEnd(); enumItems.moveNext())
      {
         objItem = enumItems.item();
         PF_Drive = objItem.Name;
         if (PF_Drive.indexOf(":") != - 1)
         PF_Drive = PF_Drive.substr(0, 2).toUpperCase();
         PF_InitialSize = objItem.InitialSize;
         PF_MaximumSize = objItem.MaximumSize;
      }
   }
   catch(ex)
   {
      return false;
   }

   return true;
}

function SetPageFileSize(Drive, InitialSize, MaximumSize, NoPageFile)
{
   position = "jscript.js";
   whatfunc = "SetPageFileSize()";

   try
   {
      if (NoPageFile)
      WriteRegKey("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\\PagingFiles", "", "REG_MULTI_SZ");
      else
      {
         if (InitialSize > MaximumSize)
         MaximumSize = InitialSize * 2;
         WriteRegKey("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\\PagingFiles", Drive + "\\pagefile.sys" + " " + InitialSize + " " + MaximumSize + "", "REG_MULTI_SZ");
      }
   }
   catch(ex)
   {
      return false;
   }

   return true;
}

function SetAutoLogonUser(DefaultUserName, DefaultPassword, DefaultDomainName)
{
   position = "jscript.js";
   whatfunc = "SetAutoLogonUser()";

   try
   {
      WriteRegKey("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon\\DefaultUserName", DefaultUserName, "REG_SZ");
      WriteRegKey("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon\\DefaultPassword", DefaultPassword, "REG_SZ");
      WriteRegKey("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon\\DefaultDomainName", DefaultDomainName, "REG_SZ");
	  WriteRegKey("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon\\AutoAdminLogon",1,"REG_SZ");
   }
   catch(ex)
   {
      return false;
   }

   return true;
}

function ClearAutoLogonUser()
{
   position = "jscript.js";
   whatfunc = "ClearAutoLogonUser()";

   try
   {
      WriteRegKey("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon\\DefaultPassword", "", "REG_SZ");
	  WriteRegKey("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon\\AutoAdminLogon",0,"REG_SZ");
   }
   catch(ex)
   {
      return false;
   }

   return true;
}

function SetSecurityCenter_XP(Firewall, AutomaticUpdates, VirusProtection, FirstRunDisabled, DisableSecurityCenter)
{
   position = "jscript.js";
   whatfunc = "SetSecurityCenter_XP()";

   try
   {
      WriteRegKey("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Security Center\\FirewallDisableNotify", (Firewall ? 0 : 1), "REG_DWORD");
      WriteRegKey("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Security Center\\UpdatesDisableNotify", (AutomaticUpdates ? 0 : 1), "REG_DWORD");
      WriteRegKey("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Security Center\\AntiVirusDisableNotify", (VirusProtection ? 0 : 1), "REG_DWORD");
      WriteRegKey("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Security Center\\FirstRunDisabled", (FirstRunDisabled ? 1 : 0), "REG_DWORD");

      if (DisableSecurityCenter)
      {
         RunCmd('CMD /C sc stop wscsvc', false, true);
         RunCmd('CMD /C sc config wscsvc start=disabled', false, true);
      }
      else
      {
         RunCmd('CMD /C sc stop wscsvc', false, true);
         RunCmd('CMD /C sc start wscsvc', false, true);
      }
   }
   catch(ex)
   {
      return false;
   }

   return true;
}

function ScreenSaver(Name, Minutes, IsSecure)
{
   position = "jscript.js";
   whatfunc = "ScreenSaver()";

   try
   {
      if (Name == "(none)")
      {
         DeleteRegKey("HKEY_CURRENT_USER\\Control Panel\\Desktop\\SCRNSAVE.EXE");
         WriteRegKey("HKEY_CURRENT_USER\\Control Panel\\Desktop\\ScreenSaveActive", 0, "REG_SZ");
      }
      else
      {
         WriteRegKey("HKEY_CURRENT_USER\\Control Panel\\Desktop\\SCRNSAVE.EXE", ReplacePath("%sysdir%\\" + Name + ".scr"), "REG_SZ");
         WriteRegKey("HKEY_CURRENT_USER\\Control Panel\\Desktop\\ScreenSaveActive", 1, "REG_SZ");
      }

      if (Minutes < 1)
      Minutes = 1;
      WriteRegKey("HKEY_CURRENT_USER\\Control Panel\\Desktop\\ScreenSaveTimeOut", Minutes * 60, "REG_SZ");
      WriteRegKey("HKEY_CURRENT_USER\\Control Panel\\Desktop\\ScreenSaverIsSecure", (IsSecure ? "1" : "0"), "REG_SZ");
   }
   catch(ex)
   {
      return false;
   }

   return true;
}

function PowerOptions(Scheme, CustomScheme, MonitorAC, MonitorDC, HardDisksAC, HardDisksDC, StandbyAC, StandbyDC, HibernateAC, HibernateDC, LowBatteryAlarm, LowBatteryLevel, LowBatteryAction, CriticalBatteryAlarm, CriticalBatteryLevel, CriticalBatteryAction, ShowIcon, PromptPassword, WhenCloseLid, WhenPressPower, WhenPressSleep, Hibernate)
{
   position = "jscript.js";
   whatfunc = "PowerOptions()";

   try
   {
      if (getOSver() == "XP")
      {
         if (Scheme == "custom")
         {
            RunCmd('CMD /C powercfg -c "'+CustomScheme+'" "'+CustomScheme+'"', false, true);
            Scheme = CustomScheme;
         }
         RunCmd('CMD /C powercfg -s "'+Scheme+'"', false, true);
         RunCmd('CMD /C powercfg -x "'+Scheme+'" -monitor-timeout-ac ' + MonitorAC, false, true);
         RunCmd('CMD /C powercfg -x "'+Scheme+'" -monitor-timeout-dc ' + MonitorDC, false, true);
         RunCmd('CMD /C powercfg -x "'+Scheme+'" -disk-timeout-ac ' + HardDisksAC, false, true);
         RunCmd('CMD /C powercfg -x "'+Scheme+'" -disk-timeout-dc ' + HardDisksDC, false, true);
         RunCmd('CMD /C powercfg -x "'+Scheme+'" -standby-timeout-ac ' + StandbyAC, false, true);
         RunCmd('CMD /C powercfg -x "'+Scheme+'" -standby-timeout-dc ' + StandbyDC, false, true);
         RunCmd('CMD /C powercfg -x "'+Scheme+'" -hibernate-timeout-ac ' + HibernateAC, false, true);
         RunCmd('CMD /C powercfg -x "'+Scheme+'" -hibernate-timeout-dc ' + HibernateDC, false, true);

         var action;

         if (LowBatteryAction == 0)
         action = "none";
         if (LowBatteryAction == 1)
         action = "standby";
         if (LowBatteryAction == 2)
         action = "hibernate";
         if (LowBatteryAction == 3)
         action = "shutdown";
         RunCmd('CMD /C powercfg -b low /activate ' + (LowBatteryAlarm ? 'on' : 'off') + ' /level ' + LowBatteryLevel + ' /action ' + action, false, true);
         if (CriticalBatteryAction == 0)
         action = "none";
         if (CriticalBatteryAction == 1)
         action = "standby";
         if (CriticalBatteryAction == 2)
         action = "hibernate";
         if (CriticalBatteryAction == 3)
         action = "shutdown";

         RunCmd('CMD /C powercfg -b critical /activate ' + (CriticalBatteryAlarm ? 'on' : 'off') + ' /level ' + CriticalBatteryLevel + ' /action ' + action, false, true);
         RunCmd('CMD /C powercfg -g ' + (ShowIcon ? 'on' : 'off') + ' /option batteryicon', false, true);
         RunCmd('CMD /C powercfg -g ' + (PromptPassword ? 'on' : 'off') + ' /option resumepassword', false, true);

         var temp = new String();
         var key = new Array();
         var keyFinal = new Array();

         temp = RegKeyValue("HKEY_CURRENT_USER\\Control Panel\\PowerCfg\\GlobalPowerPolicy\\Policies");
         key = temp.toArray();

         if (WhenCloseLid == 0)
         {
            key[52] = 0;
            key[63] = 128;
            key[64] = 0;
            key[75] = 128;
         }
         if (WhenCloseLid == 1)
         {
            key[52] = 2;
            key[63] = 0;
            key[64] = 2;
            key[75] = 0;
         }
         if (WhenCloseLid == 2)
         {
            key[52] = 3;
            key[63] = 0;
            key[64] = 3;
            key[75] = 0;
         }
         if (WhenCloseLid == 3)
         {
            key[52] = 0;
            key[63] = 16;
            key[64] = 0;
            key[75] = 16;
         }
         if (WhenPressPower == 0)
         {
            key[4] = 0;
            key[12] = 0;
            key[15] = 128;
            key[16] = 0;
            key[24] = 0;
            key[27] = 128;
         }
         if (WhenPressPower == 1)
         {
            key[4] = 2;
            key[12] = 0;
            key[15] = 0;
            key[16] = 2;
            key[24] = 0;
            key[27] = 0;
         }
         if (WhenPressPower == 2)
         {
            key[4] = 3;
            key[12] = 0;
            key[15] = 0;
            key[16] = 3;
            key[24] = 0;
            key[27] = 0;
         }
         if (WhenPressPower == 3)
         {
            key[4] = 0;
            key[12] = 16;
            key[15] = 0;
            key[16] = 0;
            key[24] = 16;
            key[27] = 0;
         }
         if (WhenPressSleep == 0)
         {
            key[28] = 0;
            key[36] = 0;
            key[39] = 128;
            key[40] = 0;
            key[48] = 0;
            key[51] = 128;
         }
         if (WhenPressSleep == 1)
         {
            key[28] = 2;
            key[36] = 0;
            key[39] = 0;
            key[40] = 2;
            key[48] = 0;
            key[51] = 0;
         }
         if (WhenPressSleep == 2)
         {
            key[28] = 3;
            key[36] = 0;
            key[39] = 0;
            key[40] = 3;
            key[48] = 0;
            key[51] = 0;
         }
         if (WhenPressSleep == 3)
         {
            key[28] = 0;
            key[36] = 16;
            key[39] = 0;
            key[40] = 0;
            key[48] = 16;
            key[51] = 0;
         }

         for (var i = 0; i < key.length; i ++ )
         keyFinal[i] = parseInt(key[i]);

         registryToolsWriteValue(".", "HKCU", "Control Panel\\PowerCfg\\GlobalPowerPolicy", "Policies", "REG_BINARY", keyFinal);

         RunCmd('CMD /C powercfg -h ' + (Hibernate ? "on" : "off"), false, true);
      }
      else
      {
         if (Scheme == "custom")
         {
            var d = new Date();
            var GUID;

            GUID = "b219fe88-deea-421a-9e40-" + (d.getTime() - 1000000000000);
            RunCmd('CMD /C powercfg -duplicatescheme 381b4222-f694-41f0-9685-ff5bb260df2e ' + GUID, false, true);
            RunCmd('CMD /C powercfg -changename ' + GUID + ' "'+CustomScheme+'"', false, true);
            Scheme = GUID;
         }
         RunCmd('CMD /C powercfg -s ' + Scheme, false, true);
         RunCmd('CMD /C powercfg -x -monitor-timeout-ac ' + MonitorAC, false, true);
         RunCmd('CMD /C powercfg -x -monitor-timeout-dc ' + MonitorDC, false, true);
         RunCmd('CMD /C powercfg -x -disk-timeout-ac ' + HardDisksAC, false, true);
         RunCmd('CMD /C powercfg -x -disk-timeout-dc ' + HardDisksDC, false, true);
         RunCmd('CMD /C powercfg -x -standby-timeout-ac ' + StandbyAC, false, true);
         RunCmd('CMD /C powercfg -x -standby-timeout-dc ' + StandbyDC, false, true);
         RunCmd('CMD /C powercfg -x -hibernate-timeout-ac ' + HibernateAC, false, true);
         RunCmd('CMD /C powercfg -x -hibernate-timeout-dc ' + HibernateDC, false, true);
         RunCmd('CMD /C powercfg -setacvalueindex "'+Scheme+'" e73a048d-bf27-4f12-9731-8b2076e8891f bcded951-187b-4d05-bccc-f7e51960c258 ' + LowBatteryAlarm, false, true);
         RunCmd('CMD /C powercfg -setacvalueindex "'+Scheme+'" e73a048d-bf27-4f12-9731-8b2076e8891f 8183ba9a-e910-48da-8769-14ae6dc1170a ' + LowBatteryLevel, false, true);
         RunCmd('CMD /C powercfg -setacvalueindex "'+Scheme+'" e73a048d-bf27-4f12-9731-8b2076e8891f d8742dcb-3e6a-4b3c-b3fe-374623cdcf06 ' + LowBatteryAction, false, true);
         RunCmd('CMD /C powercfg -setacvalueindex "'+Scheme+'" e73a048d-bf27-4f12-9731-8b2076e8891f 9a66d8d7-4ff7-4ef9-b5a2-5a326ca2a469 ' + CriticalBatteryLevel, false, true);
         RunCmd('CMD /C powercfg -setacvalueindex "'+Scheme+'" e73a048d-bf27-4f12-9731-8b2076e8891f 637ea02f-bbcb-4015-8e2c-a1c7b9c0b546 ' + CriticalBatteryAction, false, true);
         RunCmd('CMD /C powercfg -setdcvalueindex "'+Scheme+'" e73a048d-bf27-4f12-9731-8b2076e8891f bcded951-187b-4d05-bccc-f7e51960c258 ' + LowBatteryAlarm, false, true);
         RunCmd('CMD /C powercfg -setdcvalueindex "'+Scheme+'" e73a048d-bf27-4f12-9731-8b2076e8891f 8183ba9a-e910-48da-8769-14ae6dc1170a ' + LowBatteryLevel, false, true);
         RunCmd('CMD /C powercfg -setdcvalueindex "'+Scheme+'" e73a048d-bf27-4f12-9731-8b2076e8891f d8742dcb-3e6a-4b3c-b3fe-374623cdcf06 ' + LowBatteryAction, false, true);
         RunCmd('CMD /C powercfg -setdcvalueindex "'+Scheme+'" e73a048d-bf27-4f12-9731-8b2076e8891f 9a66d8d7-4ff7-4ef9-b5a2-5a326ca2a469 ' + CriticalBatteryLevel, false, true);
         RunCmd('CMD /C powercfg -setdcvalueindex "'+Scheme+'" e73a048d-bf27-4f12-9731-8b2076e8891f 637ea02f-bbcb-4015-8e2c-a1c7b9c0b546 ' + CriticalBatteryAction, false, true);
         RunCmd('CMD /C powercfg -setacvalueindex "'+Scheme+'" 4f971e89-eebd-4455-a8de-9e59040e7347 5ca83367-6e45-459f-a27b-476b1d01c936 ' + WhenCloseLid, false, true);
         RunCmd('CMD /C powercfg -setacvalueindex "'+Scheme+'" 4f971e89-eebd-4455-a8de-9e59040e7347 7648efa3-dd9c-4e3e-b566-50f929386280 ' + WhenPressPower, false, true);
         RunCmd('CMD /C powercfg -setacvalueindex "'+Scheme+'" 4f971e89-eebd-4455-a8de-9e59040e7347 96996bc0-ad50-47ec-923b-6f41874dd9eb ' + WhenPressSleep, false, true);
         RunCmd('CMD /C powercfg -setdcvalueindex "'+Scheme+'" 4f971e89-eebd-4455-a8de-9e59040e7347 5ca83367-6e45-459f-a27b-476b1d01c936 ' + WhenCloseLid, false, true);
         RunCmd('CMD /C powercfg -setdcvalueindex "'+Scheme+'" 4f971e89-eebd-4455-a8de-9e59040e7347 7648efa3-dd9c-4e3e-b566-50f929386280 ' + WhenPressPower, false, true);
         RunCmd('CMD /C powercfg -setdcvalueindex "'+Scheme+'" 4f971e89-eebd-4455-a8de-9e59040e7347 96996bc0-ad50-47ec-923b-6f41874dd9eb ' + WhenPressSleep, false, true);
         RunCmd('CMD /C powercfg -h ' + (Hibernate ? "on" : "off"), false, true);
      }
   }
   catch(ex)
   {
      return false;
   }

   return true;
}

function ErrorReporting(EnableErrorReporting, NotifyMe, WindowsOS, Programs)
{
   position = "jscript.js";
   whatfunc = "ErrorReporting()";

   try
   {
      if (getOSver() == "XP")
      {
         if ( ! EnableErrorReporting)
         {
            WriteRegKey("HKEY_LOCAL_MACHINE\\Software\\Microsoft\\PCHealth\\ErrorReporting\\DoReport", 0, "REG_DWORD");
            WriteRegKey("HKEY_LOCAL_MACHINE\\Software\\Microsoft\\PCHealth\\ErrorReporting\\ShowUI", (NotifyMe ? 1 : 0), "REG_DWORD");
         }
         else
         {
            WriteRegKey("HKEY_LOCAL_MACHINE\\Software\\Microsoft\\PCHealth\\ErrorReporting\\DoReport", 1, "REG_DWORD");
            WriteRegKey("HKEY_LOCAL_MACHINE\\Software\\Microsoft\\PCHealth\\ErrorReporting\\ShowUI", 1, "REG_DWORD");
         }

         WriteRegKey("HKEY_LOCAL_MACHINE\\Software\\Microsoft\\PCHealth\\ErrorReporting\\IncludeKernelFaults", (WindowsOS ? 1 : 0), "REG_DWORD");
         WriteRegKey("HKEY_LOCAL_MACHINE\\Software\\Microsoft\\PCHealth\\ErrorReporting\\IncludeMicrosoftApps", (Programs ? 1 : 0), "REG_DWORD");
         WriteRegKey("HKEY_LOCAL_MACHINE\\Software\\Microsoft\\PCHealth\\ErrorReporting\\IncludeWindowsApps", (Programs ? 1 : 0), "REG_DWORD");
         WriteRegKey("HKEY_LOCAL_MACHINE\\Software\\Microsoft\\PCHealth\\ErrorReporting\\AllOrNone", (Programs ? 1 : 3), "REG_DWORD");
      }
      else
      {
         WriteRegKey("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\Windows Error Reporting\\Disabled", (EnableErrorReporting ? 0 : 1), "REG_DWORD");
         WriteRegKey("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\Windows Error Reporting\\DontShowUI", (NotifyMe ? 1 : 0), "REG_DWORD");
         WriteRegKey("HKEY_LOCAL_MACHINE\\System\\ControlSet001\\Control\\Windows\\ErrorMode", (NotifyMe ? 0 : 2), "REG_DWORD");
      }
   }
   catch(ex)
   {
      return false;
   }

   return true;
}

function SetFirewall(state)
{
   position = "jscript.js";
   whatfunc = "SetFirewall()";

   try
   {
      RunCmd('CMD /C netsh firewall set opmode ' + (state ? 'enable' : 'disable'), false, true);
   }
   catch(ex)
   {
      return false;
   }

   return true;
}

function SetFilePrinterSharing(state)
{
   position = "jscript.js";
   whatfunc = "SetFilePrinterSharing()";

   try
   {
      RunCmd('CMD /C netsh firewall set service fileandprint ' + (state ? 'enable' : 'disable'), false, true);
   }
   catch(ex)
   {
      return false;
   }

   return true;
}

function MapNetworkDrive(Letter, Path, Reconnect)
{
   position = "jscript.js";
   whatfunc = "MapNetworkDrive()";

   try
   {
      RunCmd('CMD /C net use ' + Letter + ' ' + Path + ' /persistent:' + (Reconnect ? "yes" : "no"), false, true);
   }
   catch(ex)
   {
      return false;
   }

   return true;
}

function ShareFolder(ShareName, Path)
{
   position = "jscript.js";
   whatfunc = "ShareFolder()";

   try
   {
      RunCmd('CMD /C net share ' + ShareName + '=' + Path + ' /UNLIMITED', false, true);
   }
   catch(ex)
   {
      return false;
   }

   return true;
}
