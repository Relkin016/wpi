//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// Windows Post - Install Wizard
// program.js
//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

function ClearAllArrays()
{
   position = "program.js";
   whatfunc = "ClearAllArrays()";

   prog = [];
   shortdesc = [];
   uid = [];
   ordr = [];
   dflt = [];
   forc = [];
   cat = [];
   configs = [];
   rebootcode = [];
   repeatcommand = [];
   pfro = [];

   cmds = [];

   deps = [];
   excl = [];
   cond = [];
   gcond = [];

   desc = [];
   picf = [];
   picw = [];
   pich = [];
   textl = [];

   texti = [];
}

function program(idx)
{
   position = "program.js";
   whatfunc = "program()";

   var i = '' + ((ordr[idx] == null) ? (idx + 900000) : ordr[idx][0]);

   while (i.length < 6)
   i = "0" + i;

   this.prog = prog[idx];
   this.shortdesc = shortdesc[idx];
   this.uid = uid[idx];
   this.ordr = [i];
   this.dflt = (dflt[idx] == null) ? ['no'] : [dflt[idx][0]];
   this.forc = forc[idx];
   this.cat = cat[idx];
   this.configs = (configs[idx] == null) ? [''] : [configs[idx][0]];
   this.regb = regb[idx];
   this.cmd1 = cmd1[idx];
   this.cmd2 = cmd2[idx];
   this.cmd3 = cmd3[idx];
   this.cmd4 = cmd4[idx];
   this.cmd5 = cmd5[idx];
   this.cmd6 = cmd6[idx];
   this.cmd7 = cmd7[idx];
   this.cmd8 = cmd8[idx];
   this.cmd9 = cmd9[idx];
   this.cmd10 = cmd10[idx];
   this.rega = rega[idx];
   this.rebootcode = rebootcode[idx];
   this.repeatcommand = repeatcommand[idx];
   this.pfro = pfro[idx];
   this.cmds = cmds[idx];
   this.deps = deps[idx];
   this.excl = excl[idx];
   this.cond = cond[idx];
   this.gcond = gcond[idx];
   this.desc = desc[idx];
   this.picf = picf[idx];
   this.picw = picw[idx];
   this.pich = pich[idx];
   this.textl = textl[idx];
}

function WriteBackPrograms(programs)
{
   position = "program.js";
   whatfunc = "WriteBackPrograms()";

   for (var i = 0; i < programs.length; i ++ )
   {
      if (programs[i].picf != null)
      {
         var pfile, pwidth, pheight, textloc;

         if (programs[i].textl != "Top")
         {
            if (programs[i].textl != "Bottom")
            {
               pfile = ReplacePath(programs[i].picf).replace(/\"/g,'');
               pwidth = programs[i].picw;
               pheight = programs[i].pich;
               if (programs[i].textl == "Left")	// They were backwards
               textloc = "Right";
               else
               textloc = "Left";
               if (pfile.indexOf("\\") == - 1)
               desc[i + 1] = imagelocationlr + programs[i].picf + imagepart2lr + pwidth  + imagepart3lr + pheight + imagepart4lr + textloc + imagepart5lr + (programs[i].desc != null ? programs[i].desc : "");
               else
               desc[i + 1] = imagelocationlr2 + pfile + imagepart2lr + pwidth  + imagepart3lr + pheight + imagepart4lr + textloc + imagepart5lr + (programs[i].desc != null ? programs[i].desc : "");
            }
         }

         if (programs[i].textl != "Left")
         {
            if (programs[i].textl != "Right")
            {
               if (programs[i].textl != "Bottom")
               {
                  pfile = ReplacePath(programs[i].picf).replace(/\"/g,'');
                  pwidth = programs[i].picw;
                  pheight = programs[i].pich;
                  textloc = programs[i].textl;
                  if (pfile.indexOf("\\") == - 1)
                  desc[i + 1] = (programs[i].desc != null ? programs[i].desc : "") + imagepart1t + imagelocationtb + programs[i].picf + imagepart2tb + pwidth  + imagepart3tb + pheight + imagepart4tb;
                  else
                  desc[i + 1] = (programs[i].desc != null ? programs[i].desc : "") + imagepart1t + imagelocationtb2 + pfile + imagepart2tb + pwidth  + imagepart3tb + pheight + imagepart4tb;
               }
               else
               {
                  pfile = ReplacePath(programs[i].picf).replace(/\"/g,'');
                  pwidth = programs[i].picw;
                  pheight = programs[i].pich;
                  textloc = programs[i].textl;
                  if (pfile.indexOf("\\") == - 1)
                  desc[i + 1] = imagelocationtb + programs[i].picf + imagepart2tb + pwidth  + imagepart3tb + pheight + imagepart4tb  + imagepart1b + imageparteb + (programs[i].desc != null ? programs[i].desc : "");
                  else
                  desc[i + 1] = imagelocationtb2 + pfile + imagepart2tb + pwidth  + imagepart3tb + pheight + imagepart4tb  + imagepart1b + imageparteb + (programs[i].desc != null ? programs[i].desc : "");
               }
            }
         }

         // check if an absolute path was set
         if (desc[i + 1].match(/img src=".*\\.*"/g) != null)
         {
            // remove .. / Graphics /
            desc[i + 1] = desc[i + 1].replace(/src="..\/Graphics\//gi, 'src="');
            // replace variables (e.g. % ROOT % )
            desc[i + 1] = ReplacePath(desc[i + 1].replace(/src="([^"]*)"/gi, 'src="$1"'));
            // get path to image
            var path_to_image = desc[i + 1].replace(/.*src="([^"]*)".*/i, "$1");
            // replace every "\" with "/"
            path_to_image = path_to_image.replace(/\\/g, '/');
            // build new description
            desc[i + 1] = desc[i + 1].replace(/src="[^"]*"/gi, 'src="file://' + path_to_image + '"');
         }

      }
      else
      desc[i + 1] = (programs[i].desc != null ? programs[i].desc : "");

      prog[i + 1] = programs[i].prog;
      shortdesc[i + 1] = programs[i].shortdesc;
      uid[i + 1] = programs[i].uid;
      ordr[i + 1] = programs[i].ordr;
      dflt[i + 1] = programs[i].dflt;
      forc[i + 1] = programs[i].forc;
      cat[i + 1] = programs[i].cat;
      configs[i + 1] = programs[i].configs;

      regb[i + 1] = programs[i].regb;
      cmd1[i + 1] = programs[i].cmd1;
      cmd2[i + 1] = programs[i].cmd2;
      cmd3[i + 1] = programs[i].cmd3;
      cmd4[i + 1] = programs[i].cmd4;
      cmd5[i + 1] = programs[i].cmd5;
      cmd6[i + 1] = programs[i].cmd6;
      cmd7[i + 1] = programs[i].cmd7;
      cmd8[i + 1] = programs[i].cmd8;
      cmd9[i + 1] = programs[i].cmd9;
      cmd10[i + 1] = programs[i].cmd10;
      rega[i + 1] = programs[i].rega;

      rebootcode[i + 1] = programs[i].rebootcode;
      repeatcommand[i + 1] = programs[i].repeatcommand;
      pfro[i + 1] = programs[i].pfro;

      cmds[i + 1] = programs[i].cmds;

      deps[i + 1] = programs[i].deps;
      excl[i + 1] = programs[i].excl;
      cond[i + 1] = programs[i].cond;
      gcond[i + 1] = programs[i].gcond;
      picf[i + 1] = programs[i].picf;
      picw[i + 1] = programs[i].picw;
      pich[i + 1] = programs[i].pich;
      textl[i + 1] = programs[i].textl;
   }

   prog[programs.length + 1] = null;
}

function byOrder(a, b)
{
   position = "program.js";
   whatfunc = "byOrder()";

   var x = a.ordr;
   var y = b.ordr;

   {
      return x - y;
   }
}

function byName(a, b)
{
   position = "program.js";
   whatfunc = "byName()";

   var x = a.prog.toLowerCase();
   var y = b.prog.toLowerCase();

   return ((x < y) ? - 1 : ((x > y) ? 1 : 0));
}

function SortByCat(a, b)
{
   position = "program.js";
   whatfunc = "SortByCat()";

   var x = a.cat;
   var y = b.cat;

   return ((x < y) ? - 1 : ((x > y) ? 1 : 0));
}

function SortByOrder(a, b)
{
   position = "program.js";
   whatfunc = "SortByOrder()";

   var x = a.ordr;
   var y = b.ordr;

   return ((x < y) ? - 1 : ((x > y) ? 1 : 0));
}

function SortByProg(a, b)
{
   position = "program.js";
   whatfunc = "SortByProg()";

   var x = a.prog[0].toLowerCase();
   var y = b.prog[0].toLowerCase();

   return ((x < y) ? - 1 : ((x > y) ? 1 : 0));
}

function GetCats()
{
   position = "program.js";
   whatfunc = "GetCats()";

   var cats = new Array();
   var oldcat, DefaultCat, i, j;

   if (SortOrder.length)
   cats = String(SortOrder).split(',');

   DefaultCat = 'Applications';
   oldcat = '';

   for (i = 1; prog[i] != null; i ++ )
   {
      if (cat[i] == null)
      cat[i] = [DefaultCat];
      if (cat[i][0] == '')
      cat[i][0] = DefaultCat;
      if (cat[i][0] != oldcat)
      {
         for (j = 0; j < cats.length; j ++ )
         {
            if (cats[j] == cat[i][0])
            break;
         }
         if (j == cats.length)
         cats[cats.length ++ ] = cat[i][0];
      }
      oldcat = cat[i][0];
   }
   UpdateSortOrder();

   return cats;
}

function SortPrograms()
{
   position = "program.js";
   whatfunc = "SortPrograms()";

   var programs = new Array();
   var cats = new Array;
   var i, j, progspercat;

   cats = GetCats();

   // sort inside categories
   if (cats.length == 0) // this is used to sort programs, if not even one category is given
   cats[cats.length ++ ] = '';

   for (j = 0; j < cats.length; j ++ )
   {
      // get a category's apps into temporary array and sort it
      progspercat = new Array();
      for (i = 1; prog[i] != null; i ++ )
      {
         if (cat[i][0] == cats[j])
         progspercat[progspercat.length ++ ] = new program(i);
      }
      progspercat.sort(byOrder);
      // Sort by ascending numerical order
      if (SortWithinCats)
      progspercat.sort(SortByProg);

      // append array to programs array
      for (i = 0; i < progspercat.length; i ++ )
      programs[programs.length ++ ] = progspercat[i];
   }

   WriteBackPrograms(programs);
   programs = null;
   cats = null;
}

function CatsDefined()
{
   position = "program.js";
   whatfunc = "CatsDefined()";

   for (var i = 1; prog[i]; i ++ )
   {
      if (cat[i])
      return true;
   }

   return false;
}

function CheckCatIfAllChecked()
{
 position="program.js";
 whatfunc="CheckCatIfAllChecked()";

   for (var i = 1; i < prog.length; i ++ )
   checkCategory(i);
}
