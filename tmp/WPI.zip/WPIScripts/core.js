//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// Windows Post - Install Wizard
// core.js
//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

function setWPIPath()
{
	position="core.js";
	whatfunc="setWPIPath()";

	// %wpipath%
	wpipath=unescape(document.location);
	wpipath=wpipath.substring(0,wpipath.lastIndexOf("/"));
	wpipath=wpipath.replace("file:///","").replace(/\//g,"\\");
	wpipath=wpipath.replace("file:","").replace(/\//g,"\\");				// For network share
	wpipath=wpipath.substring(0,wpipath.lastIndexOf('\\'));					// Remove the 'Common' folder from wpipath

	var mapped=DriveMappedLetter(wpipath);
	if (mapped != "")
	{
		wpipath=mapped;
		fromNetworkShare=true;
		hdd=wpipath;
		cddrv="";
		usbdrv="";
	}
}

// Set some specific environment variables for WPI
function defaultWPI()
{
	position="core.js";
	whatfunc="defaultWPI()";

	// Architecture
	getArch();
	getBits();
	setArchPaths();				// IMPORTANT!!!!!!!
	getHDDControllerIDs();		// Fill in array
	getCDROMID();				// Determine if has a DVD drive for hasDVDDrive()
	getCDBurnerID();			// Determine if has a CD or DVD burner for hasDVDBurner()
	
	setWPIPath();
	optionsDefault=optionsFile=wpipath+"\\UserFiles\\useroptions.js";
	windowDefault=windowFile=wpipath+"\\UserFiles\\windowoptions.js";
	configDefault=configFile=wpipath+"\\UserFiles\\config.js";
	networkDefault=networkFile=wpipath+"\\UserFiles\\networkoptions.js";
	themeDefault=themeFile=wpipath+"\\UserFiles\\themeoptions.js";

	// sleepCmd
	sleepCmd='cmd /c "'+wpipath+'\\Tools\\Sleep.exe" -m ';

	// fontInstaller
	fontDir=wpipath+"\\Graphics\\Fonts";

	// %root%
	root=fso.GetParentFolderName(wpipath);
	if (root.substr(root.length-1,1)=="\\")
		root=root.substr(0,root.length-1);

	// %dospath%
	if (FileExists(sysdir + "$winnt$.inf"))
	{
		var winntinf=fso.OpenTextFile(sysdir + "$winnt$.inf", 1,0,-2);			// It's recorded in the 'dospath' directive of the [data] section of \system32\$winnt$.inf.
		var matches=winntinf.ReadAll().match(/\ndospath=(.*)/i);
		winntinf.Close();
		if (matches)
		{
			dospath=matches[1];
			if (dospath.substring(dospath.length - 2, dospath.length - 1)=="\\")//dospath may have a trailing slash ... or not (depending on the location)
				dospath=dospath.substring(0, dospath.length - 2);             // So let's remove it if it's there
		}
	}
	
//  FYI: x64 stores this file in system32 but since the app that runs your script (mshta.exe) is only 32-bit it references SysWOW64 instead of system32

	// Network Share
	if (wpipath.substring(0,2)=="\\\\")
	{
		fromNetworkShare=true;
		hdd=wpipath;
		cddrv="";
		usbdrv="";
	}

   // % HDD %
   if (wpipath.indexOf(":") != - 1 && ! ResumeInstall)
   {
      if (DriveType(wpipath.substr(0, 2)) == "FIXED" || DriveType(wpipath.substr(0, 2)) == "NETWORK")
      {
         fromHardDrive = true;
         hdd = wpipath.substr(0, 2).toUpperCase();
      }
   }

   // % CDROM %
   if (wpipath.indexOf(":") != - 1)
   {
      if (DriveType(wpipath.substr(0, 2)) == "CDROM")
      {
         fromCDDrive = true;
         cddrv = wpipath.substr(0, 2).toUpperCase();
         hdd = "";
         usbdrv = "";
      }
   }

   // Removable, ie, USB Key
   if (wpipath.indexOf(":") != - 1)
   {
      if (DriveType(wpipath.substr(0, 2)) == "REMOVABLE")
      {
         fromUSBDrive = true;
         usbdrv = wpipath.substr(0, 2).toUpperCase();
         cddrv = "";
         hdd = "";
      }
   }

   // % OSLANG %
   var LCID;

   CreateLocalArray();
   try
   {
      objWMIService = GetObject("winmgmts:\\\\" + "." + "\\root\\CIMV2");
      colItems = objWMIService.ExecQuery("SELECT * FROM Win32_OperatingSystem", "WQL", wbemFlagReturnImmediately | wbemFlagForwardOnly);

      enumItems = new Enumerator(colItems);
      objItem = enumItems.item();
      LCID = objItem.Locale;

      for (var x = 0; x < arrOSLang.length; x ++ )
      {
         if (arrOSLang[x].LCID == LCID)
         {
            oslang = arrOSLang[x].TLA;
            oslocale = arrOSLang[x].Locale;
            break;
         }
      }
   }
   catch(ex)
   {
      oslang = "ENU";
      oslocale = "English - United States";
   }

   // Environment variable for batch file
   setEnvVar("HDD", hdd, false);
   setEnvVar("CDDRV", cddrv, false);
   setEnvVar("WPIPATH", wpipath, false);
   setEnvVar("ROOT", root, false);
   setEnvVar("OSLANG", oslang, false);
   setEnvVar("OSLOCALE", oslocale, false);
}

function CreateLocalArray()
{
   position = "core.js";
   whatfunc = "CreateLocalArray()";

   var i = 0;

   arrOSLang[i ++ ] = new AddLocal("Afrikaans - South Africa", "AFK", "0436");
   arrOSLang[i ++ ] = new AddLocal("Albanian - Albania", "SQI", "041c");
   arrOSLang[i ++ ] = new AddLocal("Arabic - Algeria", "ARG", "1401");
   arrOSLang[i ++ ] = new AddLocal("Arabic - Bahrain", "ARH", "3c01");
   arrOSLang[i ++ ] = new AddLocal("Arabic - Egypt", "ARE", "0c01");
   arrOSLang[i ++ ] = new AddLocal("Arabic - Iraq", "ARI", "0801");
   arrOSLang[i ++ ] = new AddLocal("Arabic - Jordan", "ARJ", "2c01");
   arrOSLang[i ++ ] = new AddLocal("Arabic - Kuwait", "ARK", "3401");
   arrOSLang[i ++ ] = new AddLocal("Arabic - Lebanon", "ARB", "3001");
   arrOSLang[i ++ ] = new AddLocal("Arabic - Libya", "ARL", "1001");
   arrOSLang[i ++ ] = new AddLocal("Arabic - Morocco", "ARM", "1801");
   arrOSLang[i ++ ] = new AddLocal("Arabic - Oman", "ARO", "2001");
   arrOSLang[i ++ ] = new AddLocal("Arabic - Qatar", "ARQ", "4001");
   arrOSLang[i ++ ] = new AddLocal("Arabic - Saudi Arabia", "ARA", "0401");
   arrOSLang[i ++ ] = new AddLocal("Arabic - Syria", "ARS", "2801");
   arrOSLang[i ++ ] = new AddLocal("Arabic - Tunisia", "ART", "1c01");
   arrOSLang[i ++ ] = new AddLocal("Arabic - U.A.E.", "ARU", "3801");
   arrOSLang[i ++ ] = new AddLocal("Arabic - Yemen", "ARY", "2401");
   arrOSLang[i ++ ] = new AddLocal("Armenian - Armenia", "HYE", "042b");
   arrOSLang[i ++ ] = new AddLocal("Azeri - Azerbaijan (Cyrillic)", "AZE", "082c");
   arrOSLang[i ++ ] = new AddLocal("Azeri - Azerbaijan (Latin)", "AZE", "042c");
   arrOSLang[i ++ ] = new AddLocal("Basque - Spain", "EUQ", "042d");
   arrOSLang[i ++ ] = new AddLocal("Belarusian - Belarus", "BEL", "0423");
   arrOSLang[i ++ ] = new AddLocal("Bulgarian - Bulgaria", "BGR", "0402");
   arrOSLang[i ++ ] = new AddLocal("Catalan - Spain", "CAT", "0403");
   arrOSLang[i ++ ] = new AddLocal("Chinese - Hong Kong SAR", "ZHH", "0c04");
   arrOSLang[i ++ ] = new AddLocal("Chinese - Macau SAR", "ZHM", "1404");
   arrOSLang[i ++ ] = new AddLocal("Chinese - PRC", "CHS", "0804");
   arrOSLang[i ++ ] = new AddLocal("Chinese - Singapore", "ZHI", "1004");
   arrOSLang[i ++ ] = new AddLocal("Chinese - Taiwan", "CHT", "0404");
   arrOSLang[i ++ ] = new AddLocal("Croatian - Croatia", "HRV", "041a");
   arrOSLang[i ++ ] = new AddLocal("Czech - Czech Republic", "CSY", "0405");
   arrOSLang[i ++ ] = new AddLocal("Danish - Denmark", "DAN", "0406");
   arrOSLang[i ++ ] = new AddLocal("Divehi - Maldives", "DIV", "0465");
   arrOSLang[i ++ ] = new AddLocal("Dutch - Belgium", "NLB", "0813");
   arrOSLang[i ++ ] = new AddLocal("Dutch - Netherlands", "NLD", "0413");
   arrOSLang[i ++ ] = new AddLocal("English - Australia", "ENA", "0c09");
   arrOSLang[i ++ ] = new AddLocal("English - Belize", "ENL", "2809");
   arrOSLang[i ++ ] = new AddLocal("English - Canada", "ENC", "1009");
   arrOSLang[i ++ ] = new AddLocal("English - Caribbean", "ENB", "2409");
   arrOSLang[i ++ ] = new AddLocal("English - Ireland", "ENI", "1809");
   arrOSLang[i ++ ] = new AddLocal("English - Jamaica", "ENJ", "2009");
   arrOSLang[i ++ ] = new AddLocal("English - New Zealand", "ENZ", "1409");
   arrOSLang[i ++ ] = new AddLocal("English - Philippines", "ENP", "3409");
   arrOSLang[i ++ ] = new AddLocal("English - South Africa", "ENS", "1c09");
   arrOSLang[i ++ ] = new AddLocal("English - Trinidad", "ENT", "2c09");
   arrOSLang[i ++ ] = new AddLocal("English - United Kingdom", "ENG", "0809");
   arrOSLang[i ++ ] = new AddLocal("English - United States", "ENU", "0409");
   arrOSLang[i ++ ] = new AddLocal("English - Zimbabwe", "ENW", "3009");
   arrOSLang[i ++ ] = new AddLocal("Estonian - Estonia", "ETI", "0425");
   arrOSLang[i ++ ] = new AddLocal("Faeroese - Faeroe Islands", "FOS", "0438");
   arrOSLang[i ++ ] = new AddLocal("Farsi - Iran", "FAR", "0429");
   arrOSLang[i ++ ] = new AddLocal("Finnish - Finland", "FIN", "040b");
   arrOSLang[i ++ ] = new AddLocal("French - Belgium", "FRB", "080c");
   arrOSLang[i ++ ] = new AddLocal("French - Canada", "FRC", "0c0c");
   arrOSLang[i ++ ] = new AddLocal("French - France", "FRA", "040c");
   arrOSLang[i ++ ] = new AddLocal("French - Luxembourg", "FRL", "140c");
   arrOSLang[i ++ ] = new AddLocal("French - Monaco", "FRM", "180c");
   arrOSLang[i ++ ] = new AddLocal("French - Switzerland", "FRS", "100c");
   arrOSLang[i ++ ] = new AddLocal("FYRO Macedonian - FYRO Macedonia", "MKI", "042f");
   arrOSLang[i ++ ] = new AddLocal("Galician - Spain", "GLC", "0456");
   arrOSLang[i ++ ] = new AddLocal("Georgian - Georgia", "KAT", "0437");
   arrOSLang[i ++ ] = new AddLocal("German - Austria", "DEA", "0c07");
   arrOSLang[i ++ ] = new AddLocal("German - Germany", "DEU", "0407");
   arrOSLang[i ++ ] = new AddLocal("German - Liechtenstein", "DEC", "1407");
   arrOSLang[i ++ ] = new AddLocal("German - Luxembourg", "DEL", "1007");
   arrOSLang[i ++ ] = new AddLocal("German - Switzerland", "DES", "0807");
   arrOSLang[i ++ ] = new AddLocal("Greek - Greece", "ELL", "0408");
   arrOSLang[i ++ ] = new AddLocal("Gujarati - India (Gujarati Script)", "GUJ", "0447");
   arrOSLang[i ++ ] = new AddLocal("Hebrew - Israel", "HEB", "040d");
   arrOSLang[i ++ ] = new AddLocal("Hindi - India", "HIN", "0439");
   arrOSLang[i ++ ] = new AddLocal("Hungarian - Hungary", "HUN", "040e");
   arrOSLang[i ++ ] = new AddLocal("Icelandic - Iceland", "ISL", "040f");
   arrOSLang[i ++ ] = new AddLocal("Indonesian - Indonesia", "IND", "0421");
   arrOSLang[i ++ ] = new AddLocal("Italian - Italy", "ITA", "0410");
   arrOSLang[i ++ ] = new AddLocal("Italian - Switzerland", "ITS", "0810");
   arrOSLang[i ++ ] = new AddLocal("Japanese - Japan", "JPN", "0411");
   arrOSLang[i ++ ] = new AddLocal("Kannada - India (Kannada Script)", "KAN", "044b");
   arrOSLang[i ++ ] = new AddLocal("Kazakh - Kazakstan", "KKZ", "043f");
   arrOSLang[i ++ ] = new AddLocal("Konkani - India", "KNK", "0457");
   arrOSLang[i ++ ] = new AddLocal("Korean(Extended Wansung) - Korea", "KOR", "0412");
   arrOSLang[i ++ ] = new AddLocal("Kyrgyz - Kyrgyzstan", "KYR", "0440");
   arrOSLang[i ++ ] = new AddLocal("Latvian - Latvia", "LVI", "0426");
   arrOSLang[i ++ ] = new AddLocal("Lithuanian - Lithuania", "LTH", "0427");
   arrOSLang[i ++ ] = new AddLocal("Malay - Brunei Darussalam", "MSB", "083e");
   arrOSLang[i ++ ] = new AddLocal("Malay - Malaysia", "MSL", "043e");
   arrOSLang[i ++ ] = new AddLocal("Marathi - India", "MAR", "044e");
   arrOSLang[i ++ ] = new AddLocal("Mongolian (Cyrillic) - Mongolia", "MON", "0450");
   arrOSLang[i ++ ] = new AddLocal("Norwegian - Norway (Bokm�l)", "NOR", "0414");
   arrOSLang[i ++ ] = new AddLocal("Norwegian - Norway (Nynorsk)", "NON", "0814");
   arrOSLang[i ++ ] = new AddLocal("Polish - Poland", "PLK", "0415");
   arrOSLang[i ++ ] = new AddLocal("Portuguese - Brazil", "PTB", "0416");
   arrOSLang[i ++ ] = new AddLocal("Portuguese - Portugal", "PTG", "0816");
   arrOSLang[i ++ ] = new AddLocal("Punjabi - India (Gurmukhi Script)", "PAN", "0446");
   arrOSLang[i ++ ] = new AddLocal("Romanian - Romania", "ROM", "0418");
   arrOSLang[i ++ ] = new AddLocal("Russian - Russia", "RUS", "0419");
   arrOSLang[i ++ ] = new AddLocal("Sanskrit - India", "SAN", "044f");
   arrOSLang[i ++ ] = new AddLocal("Serbian - Serbia (Cyrillic)", "SRB", "0c1a");
   arrOSLang[i ++ ] = new AddLocal("Serbian - Serbia (Latin)", "SRL", "081a");
   arrOSLang[i ++ ] = new AddLocal("Slovak - Slovakia", "SKY", "041b");
   arrOSLang[i ++ ] = new AddLocal("Slovenian - Slovenia", "SLV", "0424");
   arrOSLang[i ++ ] = new AddLocal("Spanish - Argentina", "ESS", "2c0a");
   arrOSLang[i ++ ] = new AddLocal("Spanish - Bolivia", "ESB", "400a");
   arrOSLang[i ++ ] = new AddLocal("Spanish - Chile", "ESL", "340a");
   arrOSLang[i ++ ] = new AddLocal("Spanish - Colombia", "ESO", "240a");
   arrOSLang[i ++ ] = new AddLocal("Spanish - Costa Rica", "ESC", "140a");
   arrOSLang[i ++ ] = new AddLocal("Spanish - Dominican Republic", "ESD", "1c0a");
   arrOSLang[i ++ ] = new AddLocal("Spanish - Ecuador", "ESF", "300a");
   arrOSLang[i ++ ] = new AddLocal("Spanish - El Salvador", "ESE", "440a");
   arrOSLang[i ++ ] = new AddLocal("Spanish - Guatemala", "ESG", "100a");
   arrOSLang[i ++ ] = new AddLocal("Spanish - Honduras", "ESH", "480a");
   arrOSLang[i ++ ] = new AddLocal("Spanish - Mexico", "ESM", "080a");
   arrOSLang[i ++ ] = new AddLocal("Spanish - Nicaragua", "ESI", "4c0a");
   arrOSLang[i ++ ] = new AddLocal("Spanish - Panama", "ESA", "180a");
   arrOSLang[i ++ ] = new AddLocal("Spanish - Paraguay", "ESZ", "3c0a");
   arrOSLang[i ++ ] = new AddLocal("Spanish - Peru", "ESR", "280a");
   arrOSLang[i ++ ] = new AddLocal("Spanish - Puerto Rico", "ESU", "500a");
   arrOSLang[i ++ ] = new AddLocal("Spanish - Spain (International Sort)", "ESN", "0c0a");
   arrOSLang[i ++ ] = new AddLocal("Spanish - Spain (Traditional Sort)", "ESP", "040a");
   arrOSLang[i ++ ] = new AddLocal("Spanish - Uruguay", "ESY", "380a");
   arrOSLang[i ++ ] = new AddLocal("Spanish - Venezuela", "ESV", "200a");
   arrOSLang[i ++ ] = new AddLocal("Swahili - Kenya", "SWK", "0441");
   arrOSLang[i ++ ] = new AddLocal("Swedish - Finland", "SVF", "081d");
   arrOSLang[i ++ ] = new AddLocal("Swedish - Sweden", "SVE", "041d");
   arrOSLang[i ++ ] = new AddLocal("Syriac - Syria", "SYR", "045a");
   arrOSLang[i ++ ] = new AddLocal("Tamil - India", "TAM", "0449");
   arrOSLang[i ++ ] = new AddLocal("Tatar - Tatarstan", "TTT", "0444");
   arrOSLang[i ++ ] = new AddLocal("Telugu - India (Telugu Script)", "TEL", "044a");
   arrOSLang[i ++ ] = new AddLocal("Thai - Thailand", "THA", "041e");
   arrOSLang[i ++ ] = new AddLocal("Turkish - Turkey", "TRK", "041f");
   arrOSLang[i ++ ] = new AddLocal("Ukrainian - Ukraine", "UKR", "0422");
   arrOSLang[i ++ ] = new AddLocal("Urdu - Pakistan", "URD", "0420");
   arrOSLang[i ++ ] = new AddLocal("Uzbek - Uzbekistan (Cyrillic)", "UZB", "0843");
   arrOSLang[i ++ ] = new AddLocal("Uzbek - Uzbekistan (Latin)", "UZB", "0443");
   arrOSLang[i ++ ] = new AddLocal("Vietnamese - Viet Nam", "VIT", "042a");
}

function AddLocal(sLocale, sTLA, sLCID)
{
   position = "core.js";
   whatfunc = "AddLocal()";

   this.Locale = sLocale;
   this.TLA = sTLA;
   this.LCID = sLCID;
}

function ReplacePath(v)
{
   position = "core.js";
   whatfunc = "ReplacePath()";

   var i, rs = new String(v);

   rs = rs.replace(/%wpipath%/gi, wpipath);
   // Replace WPI's special environment variables
   rs = rs.replace(/%root%/gi, root);
   // WPI parent folder

   if (fromHardDrive)
   rs = rs.replace(/%cdrom%/gi, hdd);
   // started from harddrive
   if (fromCDDrive)
   rs = rs.replace(/%cdrom%/gi, cddrv);
   // started from cdrom
   if (fromUSBDrive)
   rs = rs.replace(/%cdrom%/gi, usbdrv);
   // started from usb drive
   if (fromNetworkShare)
   rs = rs.replace(/%cdrom%/gi, hdd);
   // started from network share

   rs = rs.replace(/%sysdir%/gi, sysdir);
   // same as before
   rs = rs.replace(/%dospath%/gi, dospath);
   // new variable
   rs = rs.replace(/%oslang%/gi, oslang);
   // operating system language code
   rs = rs.replace(/%userprofileroot%/gi, userprofileroot);
   // root of user folders
   rs = rs.replace(/%comma%/gi, ',');
   // Put a comma in command line
   rs = rs.replace(/&amp;/gi, '&');
   // Put an ampersand in command line
   rs = rs.replace(/&gt;/gi, '>');
   // Put a greater than in command line

   // Replace other (standard) environment variables (either global or defined in the process calling WPI)
   var envarname, envvars = rs.match(/%[^ %\f\n\r\t\v]+%/gi);
   // find ALL substrings enclosed in '%' and not containing '%' itself or a white space character
   if (envvars)																// if any match
   {
      for (i = 0; i < envvars.length; i ++ )										// loop on the matches
      {
         envarname = envvars[i].substring(1, envvars[i].length - 1);
         // strip the match from its enclosing '%'
         rs = rs.replace(envvars[i], WshEnv(envarname));
         // replace it by the corresponding env var
      }
   }

   return rs;
}

function GetCategoryTranslation(cat)
{
   position = "core.js";
   whatfunc = "GetCategoryTranslation()";

   var txt;
   // Categorie's identifiers like 'opt'+'Category' search this !!
   // If category is Other search fail keep original name
   try
   {
      // remove space in cat name ('Registry Tweaks'), add opt at beginning and search
      txt = getText(eval("opt" + String(cat).replace(/[ ]+/g, "")));
   }
   catch(ex)
   {
      txt = cat;
      // If category = 'Other' keep text
   }

   return txt;
}

function getText(par)
{
   position = "core.js";
   whatfunc = "getText()";

   if (par[lang])
   return par[lang];

   return par['en'];
}

function wscript_initialized()
{
   position = "core.js";
   whatfunc = "wscript_initialized()";

   WScript.Sleep(100);
}

function Pause(secs, milli)
{
   position = "core.js";
   whatfunc = "Pause()";

   var duration;

   duration = (secs * 1000) + milli;

   SleepShell.Run(sleepCmd + duration.toString(), 0, true);
}

function PauseNew(secs, milli)
{
   position = "core.js";
   whatfunc = "PauseNew()";

   var duration;

   duration = (secs * 1000) + milli;

   WScript.Sleep(duration);
}

function CancelPause()
{
   position = "core.js";
   whatfunc = "CancelPause()";

   TerminateProcess("Sleep.exe");
}

function RunCmd(cmd, win, wait)
{
   position = "core.js";
   whatfunc = "RunCmd()";

   return RunCmdShell.Run(ReplacePath(cmd), win == false ? 0 : 1, wait == false ? 0 : 1);
}

function CleanUpAbort()
{
   position = "core.js";
   whatfunc = "CleanUpAbort()";

   DeleteRebootFile();
   DeleteHistoryFile();

   WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\ResumeInstall", 0, "REG_DWORD");

   DeleteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\LastExec");
   DeleteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\CurrentInstall");
   DeleteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\curCommand");
   DeleteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\numCommands");

   WriteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\FailNum", 0, "REG_DWORD");
   FailNum = 0;

   DoCleanUp = false;
}

function RestoreRegistryKeys()
{
   position = "core.js";
   whatfunc = "RestoreRegistryKeys()";
   var RegistryKeysBackupKey = "HKEY_CURRENT_USER\\Software\\WPI\\DebuggerValuesBackup";
   if (RegKeyExists(RegistryKeysBackupKey))
   {
      var IE_DisableScriptDebugger_Key = "HKEY_CURRENT_USER\\Software\\Microsoft\\Internet Explorer\\Main\\Disable Script Debugger",
      IE_DisableScriptDebugger_Key_Backup = RegistryKeysBackupKey + "\\Disable Script Debugger";
      if (RegValueExists(IE_DisableScriptDebugger_Key_Backup))
      {
         var PreviousValue = RegKeyValue(IE_DisableScriptDebugger_Key_Backup);
         if (PreviousValue == "DELETE")
         DeleteRegKey(IE_DisableScriptDebugger_Key);
         else
         WriteRegKey(IE_DisableScriptDebugger_Key, PreviousValue, "REG_SZ");
      }

      var IE_DisableScriptDebuggerIE_Key = "HKEY_CURRENT_USER\\Software\\Microsoft\\Internet Explorer\\Main\\DisableScriptDebuggerIE",
      IE_DisableScriptDebuggerIE_Key_Backup = RegistryKeysBackupKey + "\\DisableScriptDebuggerIE";
      if (RegValueExists(IE_DisableScriptDebuggerIE_Key_Backup))
      {
         var PreviousValue = RegKeyValue(IE_DisableScriptDebuggerIE_Key_Backup);
         if (PreviousValue == "DELETE")
         DeleteRegKey(IE_DisableScriptDebuggerIE_Key);
         else
         WriteRegKey(IE_DisableScriptDebuggerIE_Key, PreviousValue, "REG_SZ");
      }

      var IE_ErrorDlgDisplayedOnEveryError_Key = "HKEY_CURRENT_USER\\Software\\Microsoft\\Internet Explorer\\Main\\Error Dlg Displayed On Every Error",
      IE_ErrorDlgDisplayedOnEveryError_Key_Backup = RegistryKeysBackupKey + "\\Error Dlg Displayed On Every Error";

      if (RegValueExists(IE_ErrorDlgDisplayedOnEveryError_Key_Backup))
      {
         var PreviousValue = RegKeyValue(IE_ErrorDlgDisplayedOnEveryError_Key_Backup);
         if (PreviousValue == "DELETE")
         DeleteRegKey(IE_ErrorDlgDisplayedOnEveryError_Key);
         else
         WriteRegKey(IE_ErrorDlgDisplayedOnEveryError_Key, PreviousValue, "REG_SZ");
      }

      var IE_MaxScriptStatements_Key = "HKEY_CURRENT_USER\\Software\\Microsoft\\Internet Explorer\\Styles\\MaxScriptStatements",
      IE_MaxScriptStatements_Key_Backup = RegistryKeysBackupKey + "\\MaxScriptStatements";

      if (RegValueExists(IE_MaxScriptStatements_Key_Backup))
      {
         var PreviousValue = RegKeyValue(IE_MaxScriptStatements_Key_Backup);
         if (PreviousValue == "DELETE")
         DeleteRegKey(IE_MaxScriptStatements_Key);
         else
         WriteRegKey(IE_MaxScriptStatements_Key, PreviousValue, "REG_DWORD");
      }

      DeleteRegKey(RegistryKeysBackupKey + "\\");
   }
}

function DeleteAllRegKeys()
{
   position = "core.js";
   whatfunc = "DeleteAllRegKeys()";

   // Just in case.  Don't want to have a restart of WPI for no reason
   DeleteRegKey("HKEY_LOCAL_MACHINE\\Software\\Microsoft\\Windows\\CurrentVersion\\RunOnce\\WPIresume");
   DeleteRegKey("HKEY_LOCAL_MACHINE\\Software\\Microsoft\\Windows\\CurrentVersion\\RunOnceEx\\001\\1");
   DeleteRegKey("HKEY_LOCAL_MACHINE\\Software\\Microsoft\\Windows\\CurrentVersion\\RunOnceEx\\001\\");
   DeleteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\");
   WriteRegKey("HKEY_CURRENT_USER\\Software\\Microsoft\\Internet Explorer\\Download\\RunInvalidSignatures", 0, "REG_DWORD");

}
var NotExiting = false;

function SetNotExitingFlag() 
{ 
   position="core.js";             
   whatfunc="SetNotExitingFlag()";
   NotExiting = true;
}

function RefreshWPI() 
{ 
   position="core.js";        
   whatfunc="RefreshWPI()";
   SetNotExitingFlag();
   document.location.reload();
}

function WPIUnloading() 
{ 
   position="core.js";       
   whatfunc="WPIUnloading()";
   if ( ! NotExiting)
   ExitWPI();
}

function ExitWPI()
{

   position = "core.js";
   whatfunc = "ExitWPI()";
   SetNotExitingFlag();

   if (RegKeyValue("HKEY_CURRENT_USER\\Software\\WPI\\SndInstallStartCB") && ! isInstaller)
   {
      PlaySound(RegKeyValue("HKEY_CURRENT_USER\\Software\\WPI\\SndWPIExit"));
      Pause(0, 500);
   }

   if ( ! ExitBeforeInstall)
   {
      RestoreRegistryKeys();

      if (getOSver() == "XP" || getOSver() == "Vista" || getOSver() == "Win7" || getOSver() == "Win8" || getOSver() == "Win8.1")
      {
         DeleteRegKey("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Associations\\LowRiskFileTypes");
         DeleteRegKey("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Associations\\");
      }

      if ( ! UserAborted)
      DeleteAllRegKeys();
      DeleteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\OptionsFile");
      DeleteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\ConfigFile");
      DeleteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\NetworkFile");
      DeleteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\NetworkUser");
      DeleteRegKey("HKEY_CURRENT_USER\\Software\\WPI\\ThemeFile");

      removeEnvVar("HDD");
      removeEnvVar("CDDRV");
      removeEnvVar("WPIPATH");
      removeEnvVar("ROOT");
      removeEnvVar("OSLANG");
      removeEnvVar("OSLOCALE");
   }

   if (EjectCDWhenDone && fromCDDrive)
   {
      EjectCD(cddrv);
      Pause(2, 0);
   }

   self.close();
}

function handleErrors(msg,url,line)
{
   position="core.js"; 
   whatfunc="handleErrors()";
   
   var errorString = "WPI JavaScript Error Report:\n\n";

   errorString += " Message: " + msg + "\n";
   errorString += "     Url: " + url + "\n";
   errorString += "    File: " + position + "\n";
   errorString += "Function: " + whatfunc + "\n";
   errorString += "    Line: " + (line - 1);

   alert(errorString);

   return true;
}
