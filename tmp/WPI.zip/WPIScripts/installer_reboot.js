//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// Windows Post - Install Wizard
// installer_reboot.js
//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

function OpenRebootFile()
{
   position = "installer_reboot.js";
   whatfunc = "OpenRebootFile()";

   var rebootFile;

   if (RebootInstallationLog)
   {
      rebootFile = ReplacePath(rebootDefault);
      try
      {
         rbfHandle = fso.CreateTextFile(rebootFile, true, true);
         rbfHandle.WriteLine("// WPI Reboot Configuration File");
         rbfHandle.WriteLine("// Install process started at: " + LogTimeStamp());
         rbfHandle.WriteLine("\r\nprb=0;\r\n");
      }
      catch(ex)
      {
         alert(getText(CouldNotCreateRebootFile) + "\n\n" + getText(lblFile) + ": " + rebootFile + "\n" + getText(lblErrorNumber) + ": " + (ex.number & 0xffff) + "\n" + getText(lblErrorDescription) + ": " + ex.description);
         RebootInstallationLog = false;

         return;
      }
   }
}

function RebootEntry(rbProg)
{
   position = "installer_reboot.js";
   whatfunc = "RebootEntry()";

   if (RebootInstallationLog)
   {
      rbfHandle.WriteLine("programs[prb]=new program(prb);");
      if (rbProg.prog != null)
      rbfHandle.WriteLine("programs[prb].prog=[" + GetConfigValue(rbProg.prog.toString(), 0) + "];");
      if (rbProg.uid != null)
      rbfHandle.WriteLine("programs[prb].uid=[" + GetConfigValue(rbProg.uid.toString(), 0) + "];");
      if (rbProg.ordr != null)
      rbfHandle.WriteLine("programs[prb].ordr=[" + GetConfigValue(rbProg.ordr.toString(), 1) + "];");
      if (rbProg.bit64 != null)
      rbfHandle.WriteLine("programs[prb].bit64=['"+GetConfigValue(rbProg.bit64.toString(),1)+"'];");
      if (rbProg.cat != null)
      rbfHandle.WriteLine("programs[prb].cat=[" + GetConfigValue(rbProg.cat.toString(), 0) + "];");
      if (rbProg.rebootcode != null)
      {
         rbfHandle.WriteLine("programs[prb].rebootcode=[" + GetConfigValue(rbProg.rebootcode.toString(), 1) + "];");
         rbfHandle.WriteLine("programs[prb].repeatcommand=['"+GetConfigValue(rbProg.repeatcommand.toString(),1)+"'];");
      }
      if (rbProg.cmds != null)
      rbfHandle.WriteLine("programs[prb].cmds=[" + GetConfigValue(rbProg.cmds.toString(), 0) + "];");
      rbfHandle.WriteLine("prb++;\r\n");
   }
}

function ScanForEntries(prog)
{
   position = "installer_reboot.js";
   whatfunc = "ScanForEntries()";

   var string = new String(prog.cmds);

   Commands.splice(0, Commands.length);
   Commands = string.split(",");
   numCommands += Commands.length;

   if (RebootEntryFound)
   return;

   for (var i = 0; i < Commands.length; i ++ )
   {
      if (Commands[i].toUpperCase().indexOf("{REBOOT}") == 0)
      RebootEntryFound = true;
   }
}

function DeleteRebootFile()
{
   position = "installer_reboot.js"
   whatfunc = "DeleteRebootFile()";

   var rebootFile;

   rebootFile = ReplacePath(rebootDefault);
   if (FileExists(rebootFile) && ( ! RebootInstallationLog || DoCleanUp))
   {
      cmdLine = 'cmd /c del /f /q "'+rebootFile+'"';
      try
      {
         WshShell.Run(cmdLine, 0, true);
      }
      catch(ex)
      {
         alert(getText(CouldNotDeleteFile) + "\n\n" + getText(lblFile) + ": " + rebootFile + "\n" + getText(lblErrorNumber) + ": " + (ex.number & 0xffff) + "\n" + getText(lblErrorDescription) + ": " + ex.description);
      }
   }
}

function CloseRebootFile()
{
   position = "installer_reboot.js";
   whatfunc = "CloseRebootFile()";

   if (rbfHandle != null)
   rbfHandle.Close();
}
