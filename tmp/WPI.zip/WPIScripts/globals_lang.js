//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// Windows Post - Install Wizard
// globals_lang.js
//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

var lang;

// b:
var btnFirst = [], btnPrevious = [], btnNext = [], btnLast = [], btnAdd = [], btnDelete = [], btnNewOptions = [];
var btnNewConfig = [], btnRead = [], btnTop = [], btnUp = [], btnDown = [], btnBottom = [], btnSave = [], btnClone = [];
var btnNewNetwork = [], btnPause = [], btnResume = [], btnAbort = [], btnAborted = [], btnSaveAs = [], btnExit = [];
var boxPrevious = [], boxNext = [], BadLanguageFile = [];

// c:
var CanNotFindRegEntry = [], CanNotResumeInstall = [], ComputerWillRestart = [], ComputerWillShutdown = [];
var CouldNotCreateHistoryFile = [], CouldNotOpenHistoryFile = [], CouldNotCreateRebootFile = [], ComputerWillRestartPFRO = [];
var cpHue = [], cpSat = [], cpLum = [], cpRed = [], cpGreen = [], cpBlue = [], cpAddColor = [], cpSelect = [], cpCancel = [];
var CouldNotOpenLogFile = [], CouldNotCreateLogFile = [], CouldNotDeleteFile = [];

// e:
var errCanNotTestInternetFiles = [], errUsingDefaultSet = [], errCouldNotSaveFile = [], errSelectACategory = [], errSelectAConfig = [];
var ErrorInCondStatement = [], euDock_Manual = [], euDock_About = [], euDock_Exit = [], errCouldNotOpenFile = [], euDock_Theme = [];
var euDock_ReadMe = [], euDock_Install = [], euDock_Options = [], euDock_Config = [], euDock_Network = [], euDock_Information = [];

// f:
var FailFileDoesNotExist = [], FinishedInstallation = [];

// g:
var grpCurrentUser = [], grpAllUsers = [], GlobalVariables = [], GridFriendlyName = [], GridComputerName = [], GridUserName = [];

// i:
var InstallSuccess = [], InstallFail = [], InstallerHeaderTxt = [], InstallItems = [], InstallProcessStarted = [];
var InstallWarning = [], InstallStillActive = [], InstallSkipped = [], InstallAbortedByUser = [];
var InstallRebootRequired = [], InstallCommands = [], InstallProcessFinished = [], InstallWrongArchitecture = [];
var InstallDownloadSuccess = [], InstallDownloadFail = [];

// l:
var lblAboutWPI = [], ttAboutWPI = [], lblAccordionsSkin = [], lblEditorsSkin = [], lblAllowCheckForInternet = [];
var lblAlwaysShowIcon = [], lblPromptForPassword = [], lblApplications = [], lblWizards = [], lblAlarmAction = [];
var lblAquaDark = [], lblAquaOrange = [], lblAquaSky = [], lblClearBlue = [], lblClearGreen = [], lblClearSilver = [];
var lblArchName = [], lblArchNameString = [], lblArchID = [], lblNumberProcessors = [], lblMHz = [], lblArchType = [];
var lblArrow = [], lblArrowGreen = [], lblBall = [], lblBar = [], lblSimpleGray = [], lblSimpleSilver = [], lblZipper = [];
var lblModernBlack = [], lblModernBlue = [], lblModernRed = [], lblStandard = [], lblWeb = [], lblMD5 = [], lblTheseAreExamples = [];
var lblBaseBoardManufacturer = [], lblBaseBoardModel = [], lblChipsetManufacturer = [], lblChipsetModel = [];
var lblBIOS = [], lblBIOSManufacturer = [], lblBIOSVersion = [], lblSMBIOSVersion = [], lblBIOSCaption = [];
var lblCDROM = [], lblCDBurner = [], lblChangeAllOccurances = [], lblArchBits = [], lblCommand = [], lblCommand1 = [], lblCommand2 = [];
var lblCommand3 = [], lblCommand4 = [], lblCommand5 = [], lblCommand6 = [], lblCommand7 = [], lblCommand8 = [], lblCommand9 = [], lblCommand10 = [];
var lblConfigChoices = [], lblCheckOnLoad = [], lblNumberOfColumns = [], lblCatSortOrder = [], lblDisableCatCheckBox = [], lblSortWithinCats = [];
var lblDisableDepsNotMet = [], lblShowScrollBar = [], lblNoColumnBreak = [], lblUseCountDownTimer = [], lblInstallByCategory = [];
var lblCreateUser = [], lblCreateWindowsUser = [], lblCursor = [], lblForceInstallOnExit = [], lblExtraXForWindow = [], lblExtraYForWindow = [];
var lblControls = [], lblTimer = [], lblCreateShortcut = [], lblShortcutTo = [], lblIconLocation = [], lblHotkey = [];
var lblDefaultGateways = [], lblGateway = [], lblTCPIPGatewayAddress = [], lblDisableHotKeys = [], lblDisableIfDoGray = [];
var lblDeleteUser = [], lblDeleteWindowsUser = [], lblDeleteFiles = [], lblTargetPath = [], lblArguments = [], lblDestination = [];
var lblDHXBlue = [], lblDHXBlack = [], lblDHXSkyBlue = [], lblDarkBlue = [], lblElapsedTime = [], lblDoNotShowIfUSB = [];
var lblDisableInstallCombobox = [], lblMaintainAutoLogonCount = [], lblDoDebuggerCheck = [], lblDoNotShowIfCD = [];
var lblDNSServers = [], lblDNSServersInOrder = [], lblTCPIPDNSServer = [], lblDNSServer = [], lblEnabled = [], lblDisabled = [];
var lblErrorNumber = [], lblErrorDescription = [], legErrorReporting = [], lblExtension = [], lblType = [], lblSwitches = [];
var lblErrorReporting = [], lblDisableErrorReporting = [], lblButNotifyMe = [], lblEnableErrorReporting = [], lblWindowsOS = [], lblPrograms = [];
var lblFile = [], lblNew = [], lblOpen = [], lblSave = [], lblSaveAs = [], lblProperties = [], lblEdit = [], lblTools = [];
var lblFilter = [], lblMain = [], lblOptionsWizard = [], lblConfigWizard = [], lblViewSourceCode = [], lblHelp = [];
var lblFileSystem = [], lblRegistry = [], lblArchitecture = [], lblSecurity = [], lblGridsSkin = [], lblHDDController = [];
var lblFirewall = [], lblAutomaticUpdates = [], lblVirusProtection = [], lblFirstRunDisabled = [], lblDisableSecurityCenter = [];
var lblFirst = [], lblPrevious = [], lblNext = [], lblLast = [], lblAdd = [], lblClone = [], lblDelete = [], lblIEVersion = [];
var lblFreeRAM = [], lblTotalRAM = [], lblCAvailable = [], lblCTotal = [], lblCFileSystem = [], lblOperatingSystem = [];
var lblGlassyBlue = [], lblGlassyCaramel = [], lblGlassyGreenApple = [], lblGlassyRainy = [], lblGlassyRaspberries = [], lblGlassyYellow = [];
var lblHomePage = [], lblForum = [], lblEditionID = [], lblServicePack = [], lblLocale = [], lblInternetConnection = [];
var lblInstall = [], lblExit = [], lblSelections = [], lblSelectDefaults = [], lblSelectAll = [], lblSelectNone = [];
var lblInstallBg = [], lblOptions = [], lblConfig = [], lblSource = [], lblManual = [], lblInstall_2 = [], lblInformation = [];
var lblInstallBgsSkin = [], lblInstallLogosSkin = [], lblProgBarsSkin = [], lblInstallLogo = [], lblInstallLogoPosition = [];
var lblInternet = [], lblOpenAWebSite = [], lblDownloadAProgram = [], lblIPAddresses = [], lblDHCPEnabled = [], lblTCPIPAddress = [];
var lblKeyboard = [], lblPointingDevice = [], lblLoadDesktopBeforeIns = [], lblMenusSkin = [], lblToolbarsSkin = [];
var lblLanguage = [], lblSelectedTheme = [], lblCustomBgPicture = [], lblScreenResolution = [], lblToolTipStyle = [];
var lblLogInstallProcess = [], lblLogFilePath = [], lblUseMultipleDefaults = [], lblShowOptionsButton = [], lblShowConfigButton = [];
var lblMainWindowWidth = [], lblMainWindowHeight = [], lblShowToolTips = [], lblUseTransitions = [], lblIndentText = [];
var lblMetric = [], lblAutomatic = [], lblAutomaticMetric = [], lblInterfaceMetric = [], lblShowSourceButton = [];
var lblModern = [], lblSilver = [], lblExecuteAfter = [], lblRestartComputer = [], lblRestartComputerType = [], lblRegistryBefore = [];
var lblMonitorResolution = [], lblMonitorColorDepth = [], lblMonitorRefreshRate = [], lblInstallFonts = [], lblExecuteBefore = [];
var lblName = [], lblInstallOrder = [], lblDescription = [], lblUniqueID = [], lblDefault = [], lblCategory = [], lblForced = [];
var lblNavigation = [], lblConfigurations = [], lblDependentOf = [], lblExcludes = [], lblCondition = [], lblGrayedCondition = [];
var lblNetworkFile = [], lblNetwork = [], ttNetwork = [], lblNetworkWizard = [], lblOK = [], lblCancel = [], lblPCSystemType = [];
var lblObtainDNSAutomatically = [], lblUseFollowingDNSAddress = [], lblPreferredDNS = [], lblAlternateDNS = [], lblPCType = [];
var lblOpenWindowAtXCoord = [], lblOpenWindowAtYCoord = [], txtNegOneToCenter = [], lblJSCRIPT = [], lblOther = [], lblWindowOptions = [];
var lblOpenWPI = [], lblSelect = [], lblVerifyInstallHDD = [], txtVerifyInstallHDD = [], lblPaths = [], lblDOS = [];
var lblOptionsFile = [], lblConfigFile = [], lblWindowsFile = [], lblThemeFile = [], lblPCManufacturer = [], lblPCModel = [];
var lblOrder = [], lblOvalLightGreen = [], lblOvalLightOrange = [], lblOvalLightRed = [], lblOvalPinkGreen = [], lblOvalSilver = [];
var lblOvalBlack = [], lblOvalBlackSilver = [], lblOvalGray = [], lblOvalLightBlue = [], lblOvalLightGray = [], lblPickUserWhenInstall = [];
var lblPictureDetails = [], lblPictureWidth = [], lblPictureHeight = [], lblTextLocation = [], lblPNPDeviceID = [], lblInsertCondValues = [];
var lblPowerOptionsProperties = [], lblUSSFButton = [], lblDefaultImage = [], lblGenUIDImage = [], lblProgram = [], lblRandomTheme = [];
var lblProgramName = [], lblShortDescription = [], lblProperty = [], lblValue = [], lblPt = [], lblPx = [], lblSec = [];
var lblReadMe = [], legReadMe = [], lblRebootAfterApplied = [], lblAutoLogonUser = [], lblClearAutoLogonUser = [];
var lblRegistryAfter = [], lblPictureFile = [], lblReOpenAfterInstall = [], lblScreenSaverSettings = [], lblShowCommandInInstaller = [];
var lblRegString = [], lblRegBinary = [], lblRegDWORD = [], lblRegQWORD = [], lblRegMultiString = [], lblRegExpandableString = [];
var lblSBDark = [], lblGray = [], lblMT = [], lblClear = [], lblLight = [], lblSelectedSkin = [], txtCouldNotCopySkin = [];
var lblShowDownloadOutput = [], lblShowExtraButtons = [], lblSysMenuEnabled = [], lblMinimizeEnabled = [], lblMaximizeEnabled = [];
var lblShowInstallerImages = [], lblAlwaysShowOutputWindow = [], lblStartingWindowState = [], lblShowInTaskBar = [], lblViewing = [];
var lblShowWindowBorder = [], lblBorderType = [], lblInnerBorder = [], lblBorderStyle = [], lblTitleBar = [], lblShowTitleBar = [];
var lblShowWPIAP = [], lblWPIFilesToPlay = [], lblShowInstallAP = [], lblInstallFilesToPlay = [], lblSndInstallWarning = [];
var lblShuffle = [], lblStartBeepAtTMinus = [], lblSystemEnclosureType = [], lblTheme = [], lblTestHere = [],  lblThemeWizard = [];
var lblSndWPIStart = [], lblSndInstallStart = [], lblSndInstallSuccess = [], lblSndInstallFail = [], lblSndInstallFinish = [], lblSndWPIExit = [];
var lblSquareLightBlue = [], lblSquareLightGray = [], lblSquareLightGreen = [], lblSquareLightOrange = [], lblSquareLightRed = [];
var lblTimeStampLogFile = [], lblUpdateWPI = [], legVersion = [], legNotes = [], lblUpdate = [], lblUsedLauncher = [], lblUserDefined = [];
var lblTurnOffMonitor = [], lblTurnOffHardDisks = [], lblSystemStandby = [], lblSystemHibernate = [], lblTimerTitle = [], lblTimerStop = [];
var lblUSSFSilentMode = [], lblVideoController = [], lblSoundDevice = [], lblNetworkAdapter = [], lblWirelessNetworkAdapter = [], lblModem = [];
var lblOSvernumber = [], lblVistaGreenBlack = [], lblVistaModern = [], lblVistaOrangeBlack = [], lblVistaPurpleBlack = [], lblVistaRed = [];
var lblVistaBlue = [], lblVistaBlueBlack = [], lblVistaBlueBlue = [], lblVistaGray = [], lblVistaGrayBlack = [], lblVistaGreen = [], lblOSBuild = [];
var lblVistaProgressBar = [], lblXPProgressBar = [], lblWINSServers = [], lblWINSServersInOrder = [], lblTCPIPWINSServer = [], lblWINSServer = [];
var lblVolume = [], lblWindowCoordinates = [], lblMainWindow = [], lblInstallerWindow = [], lblWindowResolution = [], optCustom = [], lblWindows8=[];
var lblWindows7 = [], lblWood = [], lblSystem = [], lblFolder = [], lblDrive = [], lblXP = [], lblVista = [], lblMD5 = [], lblDark = [];
var legAppearance = [], lblAppearanceBehavior = [], lblTipPositionType = [], legBorder = [], lblBorderSize = [], lblBorderColor = [];
var legBodyText = [], lblBodyTextColor = [], lblBodyBgColor = [], lblBodyBgImage = [], lblBodyTextAlign = [], lblBodyFontFace = [], lblBodyFontSize = [];
var legCheckForReboot = [], lblCheckPFRO = [], legCopyAudio = [], lblCopyAudioFolderToHD = [], lblDeleteAudioFolder = [], lblCommands = [];
var legCommands = [], legConditions = [], lblFunctions = [], legCreateRegKey = [], lblCreateRegKey = [], legCriticalBatteryAlarm = [];
var legDefaultInstallPath = [], lblActivateCriticalBatteryAlarm = [], legDimensions = [], lblTipWidth = [], lblTipHeight = [];
var legDependentOf = [], legExcludes = [], legCondition = [], legGrayedCondition = [], legFormatOptions = [], lblQuickFormat = [];
var legFormatDrive = [], lblFormatDrive = [], lblDriveLetter = [], lblVolumeLabel = [], lblFileSystem2 = [], lblClusterSize = [];
var legGlobalOptions = [], lblEnableCompression = [], legHibernate = [], lblEnableHibernation = [], legJoinWorkgroup = [], lblWorkgroup = [];
var legInstallationError = [], lblAbortInstallIfFailure = [], lblExecuteCommandIfFailure = [], lblContinueWhereFailed = [], ListofProgsToInstall = [];
var legLocation = [], lblTipXpos = [], lblTipYpos = [], legLayoutStyle = [], lblLayoutStyle = [], legLogos = [], lblShowLogos = [];
var legLowBatteryAlarm = [], lblActivateLowBatteryAlarm = [], legMapNetworkDrive = [], lblMapNetworkDrive = [], lblReconnectAtLogon = [];
var legName = [], legUniqueID = [], legDescription = [], legInstallOrder = [], legOptions = [], legCategory = [], legConfigurations = [];
var legPictureFile = [], legWidth = [], legHeight = [], legTextLocation = [], legPicturePreview = [], legPowerSchemes = [], lblCustomScheme = [];
var legPowerButtons = [], lblWhenCloseLid = [], lblWhenPressPower = [], lblWhenPressSleep = [], lblSecurityCenterSettings = [];
var legReturnCodeReqReboot = [], lblRebootCode = [], lblRepeatCommandUntilOther = [], legSecurityCenterSettings = [], lblDomainName = [];
var legScreenSaver = [], lblScreenSaver = [], lblWait = [], lblScreenSaverIsSecure = [], legSetFirewall = [], lblSetFirewall = [];
var legSetAutoLogonUser = [], lblSetAutoLogonUser = [], legSetFilePrinterSharing = [], lblSetFilePrinterSharing = [], lblSharePath = [];
var legSetPageFileSize = [], lblSetPageFileSize = [], lblInitialSize = [], lblMaximumSize = [], lblNoPageFile = [], lblShareName = [];
var legSettingsForPowerScheme = [], lblWhenComputerIs = [], lblDesktopPluggedIn = [], lblRunningOnBatteries = [], lblShareFolder = [];
var legShadow = [], lblShadowType = [], lblShadowColor = [], lblShadowStrength = [], legShareFolder = [], legTransparency = [];
var legSkins = [], lblWindowsSkin = [], lblTabsSkin = [], lblSlidersSkin = [], lblButtonsSkin = [], lblCursorsSkin = [], legTextPadding = [];
var legTitleText = [], lblTitleTextColor = [], lblTitleBgColor = [], lblTitleBgImage = [], lblTitleTextAlign = [], lblTitleFontFace = [];
var legTransitions = [], lblTransition = [], lblDuration = [], lblTitleFontSize = [], legUSSF = [], lblUSSF = [], lblComputerName = [];
var legUserInformation = [], lblFriendlyName = [], legWriteRegKey = [], lblWriteRegKey = [], lblValueName = [], lblValueData = [];
var legWindowsUserInformation = [], lblUserName = [], lblUserPassword = [], lblConfirmPassword = [], lblAdministrator = [], legFeatures = [];
var lblLicense = [], lblHardware = [], lblEMail = [], legSoundsScheme = [], lblSoundsScheme = [], lblReleased = [], legDonations = [];
var lblObtainIPAutomatically = [], lblUseFollowingIPAddress = [], lblIPAddress = [], lblSubnetMask = [], lblDefaultGateway = [];
var lblEjectCDWhenDone = [], lblDownloading = [], legAudioPlayer = [], lblNumberOfCores = [], lblNumberOfLogicalProcessors = [], lblProductKey = [];
var lblKeyboardLayout = [];

// m:
var msgStartInstall = [], msgForceInstall = [];

// n:
var NoLanguageFile = [], NewLanguageSelected = [], NotALanguageFile = [];
var NoLogFileSpecified = [], NotOpenRebootFile = [];

// o:
var optDesktop = [], optFavorites = [], optMyDocuments = [], optQuickLaunch = [], optStartMenu = [], optStartMenuPrograms = [], optStartup = [];
var optLayoutStyle1 = [], optLayoutStyle2 = [], optLayoutStyle3 = [], optLayoutStyle4 = [], optHighPerformance = [], optPowerSaver = [];
var optAfter = [], optMinute = [], optMinutes = [], optHour = [], optHours = [], optNever = [], optBalanced = [], optBySystemDefault = [];
var optAurora = [], optBubbles = [], optMystify = [], optRibbons = [], optWindowsEnergy = [], optWindowsLogo = [], optCenter = [];
var optBorderStyleNormal = [], optBorderStyleComplex = [], optBorderStyleRaised = [], optBorderStyleStatic = [], optBorderStyleSunken = [];
var optBorderTypeThick = [], optBorderTypeThin = [], optBorderTypeDialog = [], optClassic = [], optWeb = [], optMaximum = [];
var optDefault = [], optAll = [], optNone = [], optDoNothing = [], optStandBy = [], optHibernate = [], optShutDown2 = [], optWindowsXP = [];
var optFile = [], optRegistry = [], optOperatingSystem = [], optDrives = [], optNTFS = [], optFAT32 = [], optFAT = [], optStarfield = [];
var optHomeOfficeDesk = [], optPortableLaptop = [], optPresentation = [], optAlwaysOn = [], optMinPowerMan = [], optMaxBattery = [];
var optNoneSS = [], opt3DFlowerBox = [], opt3DFlyingObjects = [], opt3DPipes = [], opt3DText = [], optBeziers = [], optBlank = [];
var optNormal = [], optStatic = [], optVisible = [], optSticky = [], optFloat = [], optFixed = [], optMarquee = [], optMystify = [];
var optOther = [], optApplications = [], optDrivers = [], optGames = [], optMultiMedia = [], optOffice = [], optRegistryTweaks = [];
var optPaths = [], optDOS = [], optSystem = [], optUtilities = [], optSecurity = [], optSimple = [], optComplex = [], optRight = [];
var optRestart = [], optShutDown = [], lblRestartDelay = [], lblDoNotLoadDesktop = [], optStandard = [], optWidescreen = [];
var optTop = [], optBottom = [], optLeft = [], optWindowStateNormal = [], optWindowStateMinimized = [], optWindowStateMaximized = [];

// r:
var ReturnedCode = [];

// t:
var txtInstallRebootRequired = [], txtReturnCodeReqReboot = [], txtInstalledVersion = [], txtLatestVersion = [], txtPickNetworkUser = [];
var txtSeconds = [], TreatingAsFalseCond = [], ttInformation = [], txtRestartDelay = [], txtDoNotLoadDesktop = [], ttReadMe = [];
var txtRandomTheme = [], txtInstallViewing = [], tabCommands = [], ttCommands = [], tabDependencies = [], ttDependencies = [];
var ttTestToolTip = [],  ttTheme = [], tabChangeLog = [], txtInstallSkipped = [], tabDetails = [], ttDetails = [], tabFeatures = [];
var txtInstallWarning = [], txtMustAddCommand = [], txtInstallAbortedFailure = [], txtValueCanNotBe0Or1 = [], txtPasswordsDontMatch = [];
var tabArchitecture = [], tabMyComputer = [], tabVariables = [], tabConditions = [], tabJScript = [], tabConfigurations = [];
var tabGeneral = [], ttGeneral = [], tabHardware = [], tabLicense = [], tabLinks = [], tabProjectTeam = [], tabSounds = [];
var tabInterface = [], tabInstaller = [], tabAudioPlayer = [], tabTools = [], tabMiscellaneous = [], tabStyle = [], tabVersion = [];
var tabPowerSchemes = [], tabAlarms = [], tabAdvanced = [], tabHibernate = [], tabToolTips = [], ttToolTips = [], tipClose = [];
var tabUser = [], tabIPSettings = [], tabDNS = [], tabWINS = [], tabWindow = [], ttWindow = [], tranRandom = [], ttManual = [];
var tranBoxIn = [], tranBoxOut = [], tranCircleIn = [], tranCircleOut = [], tranIrisCrossOut = [], tranIrisStarIn = [], tranIrisStarOut = [];
var tranGradientWipeRight = [], tranGradientWipeLeft = [], tranGradientWipeDown = [], tranGradientWipeUp = [], tranZigZag = [];
var tranIrisPlusIn = [], tranIrisPlusOut = [], tranIrisDiamondIn = [], tranIrisDiamondOut = [], tranIrisCrossIn = [];
var tranRadialWipeClock = [], tranRadialWipeWedge = [], tranRadialWipeRadial = [], tranPixelate = [], ttUser = [], txtAbortMessage = [];
var tranRandomBarsHorizontal = [], tranRandomBarsVertical = [], tranFade = [], tranInset = [], txtCantDeleteItem = [], txtCommand = [];
var tranRandomDissolve = [], tranSplitVerticalIn = [], tranSplitVerticalOut = [], tranSplitHorizontalIn = [], tranSplitHorizontalOut = [];
var tranSlide = [], tranSlidePush = [], tranSlideSwap = [], tranSpiral = [], ttIPSettings = [], ttDNS = [], ttWINS = [];
var tranStretch = [], tranStretchPush = [], tranStretchSpin = [], tranWheel = [], txtCanNotStartInstall = [], txtCanNotSwitchWizards = [];
var tranStripsLeftDown = [], tranStripsLeftUp = [], tranStripsRightDown = [], tranStripsRightUp = [], txtCheckForUpdate = [], txtUpdateError = [];
var tranVerticalBlinds = [], tranHorizontalBlinds = [], tranCheckerboardAcross = [], tranCheckerboardDown = [], txtForHelpPressF1 = [];
var tranWipeUp = [], tranWipeDown = [], tranWipeRight = [], tranWipeLeft = [], txtCanNotSwitchOptions = [], txtCanNotSwitchConfig = [];
var ttInstall = [], ttExit = [], ttSelectAll = [], ttSelectNone = [], ttSelectDefaults = [], ttConfig = [], ttOptions = [], ttSource = [];
var ttInterface = [], ttInstaller = [], ttAudioPlayer = [], ttTools = [], ttMiscellaneous = [], txtYPixelsMax = [], txtInformation = [];
var txtConfigChoices = [], txtCheckOnLoad = [], txtNumberOfColumns = [], txtCatSortOrder = [], txtDisableCatCheckBox = [], txtSortWithinCats = [];
var txtCopyAudioFolderToHD = [], txtDeleteAudioFolder = [], txtDisableDepsNotMet = [], txtShowScrollBar = [], txtNoColumnBreak = [];
var txtDeleteCommandConfirm = [], txtUseCountDownTimer = [], txtInstallByCategory = [], txtForceInstallOnExit = [], txtExtraXForWindow = [];
var txtDeleteConfirm = [], txtErrorRegEditFileExists = [], txtErrorExtractFileExists = [], txtXPixelsMax = [], txtExtraYForWindow = [];
var txtDetectedPreviousInstall = [], txtDisableIfDoGray = [], txtDiscardChanges = [], txtDoNotShowIfCD = [], txtFileExistsReplace = [];
var txtInstallSuccess = [], txtInstallFailed = [], txtUseTransitions = [], txtIndentText = [], txtIPSettings = [], txtShowSourceButton = [];
var txtLanguage = [], txtSelectedTheme = [], txtCustomBgPicture = [], txtScreenResolution = [], txtToolTipStyle = [], txtShowToolTips = [];
var txtLogInstallProcess = [], txtLogFilePath = [], txtUseMultipleDefaults = [], txtShowOptionsButton = [], txtShowConfigButton = [];
var txtMonitorResolution = [], txtMonitorColorDepth = [], txtMonitorRefreshRate = [], txtInstallFonts = [], txtExecuteBefore = [];
var txtName = [], txtInstallOrder = [], txtDescription = [], txtUniqueID = [], txtDefault = [], txtCategory = [], txtForced = [];
var txtNew = [], txtExecuteAfter = [], txtRestartComputer = [], txtRegistryBefore = [], txtNoInternetConnection = [], txtInstallDownloading = [];
var txtNewThemeSelected = [], txtConfigurations = [], txtDependentOf = [], txtExcludes = [], txtCondition = [], txtGrayedCondition = [];
var txtNumberFailedInstalls = [], txtOptionsFileSaved = [], txtConfigFileSaved = [], txtPictureWidth = [], txtPictureHeight = [];
var txtOptionsBeingUpdated = [], txtConfigBeingUpdated = [], txtNetworkBeingUpdated = [], txtPleaseWait = [], txtBackupMade = [];
var txtPathMustBeInQuotes = [], txtBothMustBeInQuotes = [], txtTextLocation = [], txtUSSFButton = [], txtDefaultImage = [], txtGenUIDImage = [];
var txtPressAltG = [], txtCanNotSaveToCD = [], txtProblemRetrievingXML = [], txtRegistryAfter = [], txtPictureFile = [], txtReOpenAfterInstall = [];
var txtSaveNetworkAs = [], txtSettingNetworkOptions = [], txtSaveOptionsAs = [], txtSaveConfigAs = [], txtShowExtraButtons = [];
var txtSavingOptionsFile = [], txtSavingConfigFile = [], txtSavingNetworkFile = [], txtShowInTaskBar = [], txtStartBeepAtTMinus = [];
var txtShowInstallAP = [], txtSysMenuEnabled = [], txtMinimizeEnabled = [], txtMaximizeEnabled = [], txtStartingWindowState = [];
var txtShowWindowBorder = [], txtBorderType = [], txtInnerBorder = [], txtBorderStyle = [], lblTitleBar = [], txtShowTitleBar = [];
var txtThatIsThisItem = [], txtDiscardChangesContinue = [], txtThemeBeingUpdated = [], txtSavingThemeFile = [], txtUpdateConfig = [];
var txtUpdateConfig2 = [], txtUSSFError = [], txtUSSFError2_Notes = [], txtUSSFError3_Error = [], txtUSSFError3_Notes = [];
var txtUSSFError0_Error = [], txtUSSFError0_Notes = [], txtUSSFError1_Error = [], txtUSSFError1_Notes = [], txtUSSFError2_Error = [];
var txtUSSFError4_Error = [], txtUSSFError4_Notes = [], txtUSSFError5_Error = [], txtUSSFError5_Notes = [], txtUSSFError6_Error = [];
var txtUSSFfailure = [], txtUSSFError6_Notes = [], txtUSSFError7_Error = [], txtUSSFError7_Notes = [], txtWPIInformation = [];
var txtUSSFSilentMode = [], txtUSSFType15_Type = [], txtUSSFType15_Notes = [], txtWindowAutoClose1 = [], txtWindowAutoClose2 = [];
var txtUSSFType0_Type = [], txtUSSFType0_Notes = [], txtUSSFType1_Type = [], txtUSSFType1_Notes = [], txtUSSFType2_Type = [], txtUSSFType2_Notes = [];
var txtUSSFType12_Type = [], txtUSSFType12_Notes = [], txtUSSFType13_Type = [], txtUSSFType13_Notes = [], txtUSSFType14_Type = [], txtUSSFType14_Notes = [];
var txtUSSFType3_Type = [], txtUSSFType3_Notes = [], txtUSSFType4_Type = [], txtUSSFType4_Notes = [], txtUSSFType5_Type = [], txtUSSFType5_Notes = [];
var txtUSSFType6_Type = [], txtUSSFType6_Notes = [], txtUSSFType7_Type = [], txtUSSFType7_Notes = [], txtUSSFType8_Type = [], txtUSSFType8_Notes = [];
var txtUSSFType9_Type = [], txtUSSFType9_Notes = [], txtUSSFType10_Type = [], txtUSSFType10_Notes = [], txtUSSFType11_Type = [], txtUSSFType11_Notes = [];
var txtWPIManual = [], txtExpandAll = [], txtCollapseAll = [], tabPicture = [], ttPicture = [];

//u:
var UnableToResumeInstall = [];

// w:
var WPIInstallLogFile = [];