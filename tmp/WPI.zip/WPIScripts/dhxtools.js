//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// Windows Post - Install Wizard
// dhxtools.js
//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

function AutoSizeWindow(xWin, divID)
{
   position="dhxtools.js";
   whatfunc = "AutoSizeWindow()";

   var x, y;

   if ( ! xWin)
   return;

   x = xWin.getDimension()[0];
   y = xWin.getDimension()[1];

   document.getElementById(divID).scrollLeft = 1000;
   if (document.getElementById(divID).scrollLeft > 0)
   {
      x += document.getElementById(divID).scrollLeft;
      y -= 17;
   }

   document.getElementById(divID).scrollTop = 1000;
   if (document.getElementById(divID).scrollTop > 0)
   y += document.getElementById(divID).scrollTop;

   if (y < 100)
   return;

   xWin.setDimension(x, y);
   xWin.center();
}
