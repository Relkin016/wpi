﻿//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
// Windows Post - Install Wizard
// optionswizard_languagecombo.js
//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

// This is seperate to preserve the UTF - 8 formatting.

function CreateLanguageCombo()
{
   position = "optionswizard_languagecombo.js";
   whatfunc = "CreateLanguageCombo()";

   LanguageCombo = new dhtmlXCombo("LanguageZone", "alfa19", 200, "image");
   LanguageCombo.enableOptionAutoPositioning(true);
   LanguageCombo.setOptionHeight(150);
   LanguageCombo.attachEvent("onSelectionChange", HandleLanguageSelection);

   LanguageCombo._addOption(
   {
      value : "zz", text : getText(optBySystemDefault), img_src : "../Common/imgs/Flags/_empty.gif"
   }
   );

   LanguageCombo._addOption(
   {
      value : "ar", text : "العربية", img_src : "../Common/imgs/Flags/af.gif"
   }
   );
   // Arabic
   LanguageCombo._addOption(
   {
      value : "bg", text : "Български", img_src : "../Common/imgs/Flags/bg.gif"
   }
   );
   // Bulgarian
   LanguageCombo._addOption(
   {
      value : "br", text : "Brasileira", img_src : "../Common/imgs/Flags/br.gif"
   }
   );
   // Portuguese (Brazil)
   LanguageCombo._addOption(
   {
      value : "cn", text : "Chinese, Simplified", img_src : "../Common/imgs/Flags/cn.gif"
   }
   );
   // Simplified Chinese
   LanguageCombo._addOption(
   {
      value : "zh", text : "Chinese, Traditional", img_src : "../Common/imgs/Flags/cn.gif"
   }
   );
   // Traditional Chinese - Taiwan
   LanguageCombo._addOption(
   {
      value : "cz", text : "Čeština", img_src : "../Common/imgs/Flags/cz.gif"
   }
   );
   // Czech
   LanguageCombo._addOption(
   {
      value : "da", text : "Dansk", img_src : "../Common/imgs/Flags/da.gif"
   }
   );
   // Danish
   LanguageCombo._addOption(
   {
      value : "de", text : "Deutsch", img_src : "../Common/imgs/Flags/de.gif"
   }
   );
   // German
   LanguageCombo._addOption(
   {
      value : "en", text : "English", img_src : "../Common/imgs/Flags/us.gif"
   }
   );
   // English
   LanguageCombo._addOption(
   {
      value : "fr", text : "Français", img_src : "../Common/imgs/Flags/fr.gif"
   }
   );
   // French
   LanguageCombo._addOption(
   {
      value : "fi", text : "Suomi", img_src : "../Common/imgs/Flags/fi.gif"
   }
   );
   // Finnish
   LanguageCombo._addOption(
   {
      value : "gr", text : "Ελληνικά", img_src : "../Common/imgs/Flags/gr.gif"
   }
   );
   // Greek
   LanguageCombo._addOption(
   {
      value : "hr", text : "Hrvatski", img_src : "../Common/imgs/Flags/hr.gif"
   }
   );
   // Croatian
   LanguageCombo._addOption(
   {
      value : "iw", text : "עברית", img_src : "../Common/imgs/Flags/il.gif"
   }
   );
   // Hebrew
   LanguageCombo._addOption(
   {
      value : "in", text : "Pañjābī", img_src : "../Common/imgs/Flags/in.gif"
   }
   );
   // Punjabi
   LanguageCombo._addOption(
   {
      value : "hu", text : "Magyar", img_src : "../Common/imgs/Flags/hu.gif"
   }
   );
   // Hungarian
   LanguageCombo._addOption(
   {
      value : "it", text : "Italiano", img_src : "../Common/imgs/Flags/it.gif"
   }
   );
   // Italian
   LanguageCombo._addOption(
   {
      value : "jp", text : "Japanese", img_src : "../Common/imgs/Flags/jp.gif"
   }
   );
   // Japanese
   LanguageCombo._addOption(
   {
      value : "kp", text : "Korean", img_src : "../Common/imgs/Flags/kp.gif"
   }
   );
   // Korean
   LanguageCombo._addOption(
   {
      value : "lt", text : "Lietuvių", img_src : "../Common/imgs/Flags/lt.gif"
   }
   );
   // Lithuanian
   LanguageCombo._addOption(
   {
      value : "nl", text : "Nederlands", img_src : "../Common/imgs/Flags/nl.gif"
   }
   );
   // Dutch
   LanguageCombo._addOption(
   {
      value : "no", text : "Norsk", img_src : "../Common/imgs/Flags/no.gif"
   }
   );
   // Norwegian
   LanguageCombo._addOption(
   {
      value : "pl", text : "Polski", img_src : "../Common/imgs/Flags/pl.gif"
   }
   );
   // Polish
   LanguageCombo._addOption(
   {
      value : "pt", text : "Português", img_src : "../Common/imgs/Flags/pt.gif"
   }
   );
   // Portuguese
   LanguageCombo._addOption(
   {
      value : "ro", text : "Român", img_src : "../Common/imgs/Flags/ro.gif"
   }
   );
   // Romanian
   LanguageCombo._addOption(
   {
      value : "ru", text : "Русский", img_src : "../Common/imgs/Flags/ru.gif"
   }
   );
   // Russian
   LanguageCombo._addOption(
   {
      value : "si", text : "Slovenski", img_src : "../Common/imgs/Flags/sl.gif"
   }
   );
   // Slovenski Prevod
   LanguageCombo._addOption(
   {
      value : "sk", text : "Slovenský", img_src : "../Common/imgs/Flags/sk.gif"
   }
   );
   // Slovak
   LanguageCombo._addOption(
   {
      value : "es", text : "Español", img_src : "../Common/imgs/Flags/es.gif"
   }
   );
   // Spanish
   LanguageCombo._addOption(
   {
      value : "sv", text : "Svenska", img_src : "../Common/imgs/Flags/sv.gif"
   }
   );
   // Swedish
   LanguageCombo._addOption(
   {
      value : "th", text : "Thai", img_src : "../Common/imgs/Flags/th.gif"
   }
   );
   // Thai
   LanguageCombo._addOption(
   {
      value : "tr", text : "Türkçe", img_src : "../Common/imgs/Flags/tr.gif"
   }
   );
   // Turkish
   LanguageCombo._addOption(
   {
      value : "ua", text : "Українська", img_src : "../Common/imgs/Flags/ua.gif"
   }
   );
   // Ukranian

}
