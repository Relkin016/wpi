function SetupTheme()
{
	position="customthemecode.js";
	whatfunc="SetupTheme()";

	document.getElementById("bgpiclayer").style.backgroundColor=Theme_BGColor;

	if (Theme_BackgroundRepeat.toLowerCase() != "stretch")
	{
	    if (BgPicture != '' && FileExists(wpipath+"\\Graphics\\"+BgPicture))
			document.getElementById("bgpiclayer").style.backgroundImage='url("../Graphics/'+BgPicture+'")';
		else
		{
			if (FileExists(wpipath+"\\Themes\\"+Theme+"\\Wallpaper.jpg"))
				document.getElementById("bgpiclayer").style.backgroundImage='url("../Themes/'+Theme+'/Wallpaper.jpg")';
			if (FileExists(wpipath+"\\Themes\\"+Theme+"\\Wallpaper.png"))
				document.getElementById("bgpiclayer").style.backgroundImage='url("../Themes/'+Theme+'/Wallpaper.png")';
		}
		
		document.getElementById("bgpiclayer").style.backgroundRepeat=Theme_BackgroundRepeat;
		document.getElementById("bgpiclayer").style.backgroundPosition=Theme_BackgroundPosition;
	}


	document.getElementById("td_titleimg").style.height=Theme_TitleBGHeight+"px";
	document.getElementById("td_titleimg").style.backgroundColor=Theme_TitleBGColor;
	document.getElementById("td_titleimg").style.backgroundImage='url("../Themes/'+Theme+'/TitleBG.png")';
	document.getElementById("td_titleimg").style.backgroundRepeat=Theme_TitleBGImageRepeat;
	if (FileExists(wpipath+"\\Themes\\"+Theme+"\\Title.png"))
	{
		SetThemeImage("titleimg","Title.png");
		document.getElementById("titleimg").width=Theme_TitleImageWidth;
		document.getElementById("titleimg").height=Theme_TitleImageHeight;
		document.getElementById("div_titleimg").style.textAlign=Theme_TitleImageAlign;
	}
	else
	{
		var txt;

		txt='<p style="font-family:'+Theme_TitleTextFont+'; font-size:'+Theme_TitleTextSize+'; color:'+Theme_TitleTextColor+'; font-weight:'+Theme_TitleTextWeight+'; font-style:'+Theme_TitleTextStyle+';">Windows Post-Install Wizard</p>';
		document.getElementById("div_titleimg").innerHTML=txt;
		document.getElementById("div_titleimg").style.textAlign=Theme_TitleTextAlign;
	}


	if (Theme_FrameColor != "")
	{
		document.getElementById("Frame1").style.backgroundColor=Theme_FrameColor;
		document.getElementById("Frame2").style.backgroundColor=Theme_FrameColor;
		document.getElementById("Frame3").style.backgroundColor=Theme_FrameColor;
		document.getElementById("Frame4").style.backgroundColor=Theme_FrameColor;
	}

	if (FileExists(wpipath+"\\Themes\\"+Theme+"\\Frame.png"))
	{
		document.getElementById("Frame1").style.backgroundImage='url("../Themes/'+Theme+'/Frame.png")';
		document.getElementById("Frame2").style.backgroundImage='url("../Themes/'+Theme+'/Frame.png")';
		document.getElementById("Frame3").style.backgroundImage='url("../Themes/'+Theme+'/Frame.png")';
		document.getElementById("Frame4").style.backgroundImage='url("../Themes/'+Theme+'/Frame.png")';
	}


	if (Theme_SidePanelBGColor != "")
		document.getElementById("td_sidepanel").style.backgroundColor=Theme_SidePanelBGColor;

	document.getElementById("td_sidepanel").style.width=Theme_SidePanelWidth+"px";

	if (FileExists(wpipath+"\\Themes\\"+Theme+"\\SidePanel.png"))
	{
		document.getElementById("sidepanel").style.backgroundImage='url("../Themes/'+Theme+'/SidePanel.png")';
		document.getElementById("sidepanel").style.backgroundRepeat=Theme_SidePanelBGImageRepeat;
	}


	if (Theme_MainPanelBGColor != "")
		document.getElementById("layerboxes").style.backgroundColor=Theme_MainPanelBGColor;

	if (FileExists(wpipath+"\\Themes\\"+Theme+"\\MainPanel.png"))
	{
		document.getElementById("layerboxes").style.backgroundImage='url("../Themes/'+Theme+'/MainPanel.png")';
		document.getElementById("layerboxes").style.backgroundRepeat=Theme_MainPanelBGImageRepeat;
	}


	document.getElementById("div_logo").style.width=Theme_LogoImageWidth+"px";
	document.getElementById("div_logo").style.height=Theme_LogoImageHeight+"px";
	document.getElementById("div_logo").style.right=Theme_LogoImageRight+"px";
	document.getElementById("div_logo").style.bottom=Theme_LogoImageBottom+"px";
	document.getElementById("div_logo").style.visibility="visible";


	document.getElementById("td_bottomimg").style.height=Theme_BottomBGHeight+"px";
	document.getElementById("td_bottomimg").style.backgroundColor=Theme_BottomBGColor;
	document.getElementById("td_bottomimg").style.backgroundImage='url("../Themes/'+Theme+'/BottomBG.png")';
	document.getElementById("td_bottomimg").style.backgroundRepeat=Theme_BottomBGImageRepeat;
	if (FileExists(wpipath+"\\Themes\\"+Theme+"\\Bottom.png"))
	{
		SetThemeImage("bottomimg","Bottom.png");
		document.getElementById("bottomimg").width=Theme_BottomImageWidth;
		document.getElementById("bottomimg").height=Theme_BottomImageHeight;
		document.getElementById("div_bottomimg").style.textAlign=Theme_BottomImageAlign;
	}
	else
	{
		if (Theme_BottomText != "")
		{
			var txt;

			txt='<p style="font-family:'+Theme_BottomTextFont+'; font-size:'+Theme_BottomTextSize+'; color:'+Theme_BottomTextColor+'; font-weight:'+Theme_BottomTextWeight+'; font-style:'+Theme_BottomTextStyle+';">'+Theme_BottomText+'</p>';
			document.getElementById("div_bottomimg").innerHTML=txt;
			document.getElementById("div_bottomimg").style.textAlign=Theme_BottomTextAlign;
		}
	}


	if (Theme_ExitButtonLocation.toLowerCase()=="left")
		document.getElementById("div_exitleft").style.visibility="visible";
	else
		document.getElementById("div_exitright").style.visibility="visible";
}
