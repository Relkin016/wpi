function SetupTheme()
{
	position="customthemecode.js";
	whatfunc="SetupTheme()";

	document.getElementById("bgpiclayer").style.backgroundColor=Theme_BGColor;

	if (Theme_BackgroundRepeat.toLowerCase() != "stretch")
	{
	    if (BgPicture != '' && FileExists(wpipath+"\\Graphics\\"+BgPicture))
			document.getElementById("bgpiclayer").style.backgroundImage='url("../Graphics/'+BgPicture+'")';
		else
		{
			if (FileExists(wpipath+"\\Themes\\"+Theme+"\\Wallpaper.jpg"))
				document.getElementById("bgpiclayer").style.backgroundImage='url("../Themes/'+Theme+'/Wallpaper.jpg")';
			if (FileExists(wpipath+"\\Themes\\"+Theme+"\\Wallpaper.png"))
				document.getElementById("bgpiclayer").style.backgroundImage='url("../Themes/'+Theme+'/Wallpaper.png")';
		}
		
		document.getElementById("bgpiclayer").style.backgroundRepeat=Theme_BackgroundRepeat;
		document.getElementById("bgpiclayer").style.backgroundPosition=Theme_BackgroundPosition;
	}


	document.getElementById("div_logo").style.width=Theme_LogoImageWidth+"px";
	document.getElementById("div_logo").style.height=Theme_LogoImageHeight+"px";
	document.getElementById("div_logo").style.right=Theme_LogoImageRight+"px";
	document.getElementById("div_logo").style.bottom=Theme_LogoImageBottom+"px";
	document.getElementById("div_logo").style.visibility="visible";
	
	
	LayoutMenuBar();
	LayoutMenuBarConfigs();

	LayoutMainToolBar();
	LayoutMainToolBarConfigs();

	SetNOSSAState(true);

	document.getElementById("MenuBar").style.display="block";
 	document.getElementById("MainToolBar").style.display="block";

	FillInPathBox(configFile);

	FillInNumItems();

	SetUserInfo();

	document.getElementById("WPI_Version").innerHTML=ShortVersion;
}
