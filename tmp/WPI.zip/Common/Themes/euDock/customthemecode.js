function SetupTheme()
{
	position="customthemecode.js";
	whatfunc="SetupTheme()";

	document.getElementById("bgpiclayer").style.backgroundColor=Theme_BGColor;

	if (Theme_BackgroundRepeat.toLowerCase() != "stretch")
	{
	    if (BgPicture != '' && FileExists(wpipath+"\\Graphics\\"+BgPicture))
			document.getElementById("bgpiclayer").style.backgroundImage='url("../Graphics/'+BgPicture+'")';
		else
		{
			if (FileExists(wpipath+"\\Themes\\"+Theme+"\\Wallpaper.jpg"))
				document.getElementById("bgpiclayer").style.backgroundImage='url("../Themes/'+Theme+'/Wallpaper.jpg")';
			if (FileExists(wpipath+"\\Themes\\"+Theme+"\\Wallpaper.png"))
				document.getElementById("bgpiclayer").style.backgroundImage='url("../Themes/'+Theme+'/Wallpaper.png")';
		}
		
		document.getElementById("bgpiclayer").style.backgroundRepeat=Theme_BackgroundRepeat;
		document.getElementById("bgpiclayer").style.backgroundPosition=Theme_BackgroundPosition;
	}


	document.getElementById("td_titleimg").style.height=Theme_TitleBGHeight+"px";
	document.getElementById("td_titleimg").style.backgroundColor=Theme_TitleBGColor;
	document.getElementById("td_titleimg").style.backgroundImage='url("../Themes/'+Theme+'/TitleBG.png")';
	document.getElementById("td_titleimg").style.backgroundRepeat=Theme_TitleBGImageRepeat;
	if (FileExists(wpipath+"\\Themes\\"+Theme+"\\Title.png"))
	{
		SetThemeImage("titleimg","Title.png");
		document.getElementById("titleimg").width=Theme_TitleImageWidth;
		document.getElementById("titleimg").height=Theme_TitleImageHeight;
		document.getElementById("div_titleimg").style.textAlign=Theme_TitleImageAlign;
	}
	else
	{
		var txt;

		txt='<p style="font-family:'+Theme_TitleTextFont+'; font-size:'+Theme_TitleTextSize+'px; color:'+Theme_TitleTextColor+'; font-weight:'+Theme_TitleTextWeight+'; font-style:'+Theme_TitleTextStyle+';">Windows Post-Install Wizard';
		document.getElementById("div_titleimg").innerHTML=txt;
		document.getElementById("div_titleimg").style.textAlign=Theme_TitleTextAlign;
	}

	document.getElementById("div_logo").style.width=Theme_LogoImageWidth+"px";
	document.getElementById("div_logo").style.height=Theme_LogoImageHeight+"px";
	document.getElementById("div_logo").style.right=Theme_LogoImageRight+"px";
	document.getElementById("div_logo").style.bottom=Theme_LogoImageBottom+"px";
	document.getElementById("div_logo").style.visibility="visible";
	
	document.getElementById("td_bottomimg").style.height=Theme_BottomBGHeight+"px";
	document.getElementById("td_bottomimg").style.backgroundColor=Theme_BottomBGColor;
	document.getElementById("td_bottomimg").style.backgroundImage='url("../Themes/'+Theme+'/BottomBG.png")';
	document.getElementById("td_bottomimg").style.backgroundRepeat=Theme_BottomBGImageRepeat;
	if (FileExists(wpipath+"\\Themes\\"+Theme+"\\Bottom.png"))
	{
		SetThemeImage("bottomimg","Bottom.png");
		document.getElementById("bottomimg").width=Theme_BottomImageWidth;
		document.getElementById("bottomimg").height=Theme_BottomImageHeight;
		document.getElementById("div_bottomimg").style.textAlign=Theme_BottomImageAlign;
	}
}


	var DockType;			// 11=Horizontal, 12=Vertical
	var DockLocation;		// 1=Up, 2=Down, 3=Left, 4=Right

    euEnv.imageBasePath="./Themes/euDock/js/";

    var dock = new euDock();

    dock.setAnimation(euMOUSE,0.3);

	if (DockType==0)
	{
		if (DockLocation>2)
			DockLocation=2;
	}
	if (DockType==1)
	{
		if (DockLocation<3)
			DockLocation=3;
	}

	if (DockLocation==1)
		dock.setScreenAlign(euUP,3);
	else if ((DockLocation==2))
	    dock.setScreenAlign(euDOWN,3);
	else if (DockLocation==3)
	    dock.setScreenAlign(euLEFT,3);
	else
	    dock.setScreenAlign(euRIGHT,3);


	if (DockType==11)
	{
		dock.setBar({
		    left      :{euGhost:{       ghost     : "./Themes/euDock/barImages/bar-dockBg-l.png",
			                            eyeball   : "./Themes/euDock/barImages/bar-eyes.png",
				                        eyespot_1 : "./Themes/euDock/barImages/bar-eye-spot.png",
					                    eyespot_2 : "./Themes/euDock/barImages/bar-eye-spot.png",
						                spotCoord1: {x:17,y:16,rad:7},
							            spotCoord2: {x:33,y:17,rad:5},
								        PngObjIE  : euImageNoFadingIE_PNG
									    }},
	        horizontal:{euImage:{image:"./Themes/euDock/barImages/dockBg-c-o.gif"}},
		    right     :{euImage:{image:"./Themes/euDock/barImages/dockBg-r.png"}}
		});
	}
	else
	{
	   dock.setBar({
		    top       :{euImage:{image:"./Themes/euDock/barImages/dockBg-u.png"}},
			vertical  :{euImage:{image:"./Themes/euDock/barImages/dockBg-c-v.gif"}},
	        bottom    :{euImage:{image:"./Themes/euDock/barImages/dockBg-d.png"}},
		    left      :{euImage:{image:"./Themes/euDock/barImages/dockBg-l.png"}},
			horizontal:{euImage:{image:"./Themes/euDock/barImages/dockBg-c-o.gif"}},
	        right     :{euImage:{image:"./Themes/euDock/barImages/dockBg-r.png"}}
   		});
   	}

	dock.setIconsOffset(2);

	strFile=wpipath+"\\ReadMe.txt";
	if (FileExists(strFile))
	{
		dock.addIcon(new Array(
			{euImage:{image : "../Themes/"+Theme+"/Dock_ReadMe01.png"}},
			{euLabel:{
				object	: {euImage:{image:"../Themes/"+Theme+"/Dock_ReadMe01.png"}},
				txt		: getText(euDock_ReadMe),
//				style   : "background:#eeefff;border-style:solid;border-color:#9fb6b6;border-width:2px;",
				style	: "font-size:16pt;",
				anchor	: euDOWN,
				offsetX	: 0,
				offsetY : -30}}),
			{
				fadingStep	: 0.1,
				fadingType	: euFIXED,
				link		: "javascript:ToggleReadMe();"
			});
	}

	dock.addIcon(new Array(
		{euImage:{image : "../Themes/"+Theme+"/Dock_Install01.png"}},
        {euLabel:{
			object	: {euImage:{image:"../Themes/"+Theme+"/Dock_Install01.png"}},
            txt		: getText(euDock_Install),
//			style   : "background:#eeefff;border-style:solid;border-color:#9fb6b6;border-width:2px;",
            style   : "font-size:16pt;",
            anchor  : euDOWN,
            offsetX : 0,
            offsetY : -30}}),
        {
			fadingStep	: 0.1,
			fadingType	: euFIXED,
			link		: "javascript:checkInstall('install');"
		});

    if (ShowExtraButtons)
    {
        if (DoNotShowIfCD && hdd=="")
            null;
        else
        {
			dock.addIcon(new Array(
				{euImage:{image : "../Themes/"+Theme+"/Dock_Options01.png"}},
		        {euLabel:{
					object	: {euImage:{image:"../Themes/"+Theme+"/Dock_Options01.png"}},
		            txt		: getText(euDock_Options),
//					style   : "background:#eeefff;border-style:solid;border-color:#9fb6b6;border-width:2px;",
		            style   : "font-size:16pt;",
				    anchor  : euDOWN,
		            offsetX : 0,
				    offsetY : -30}}),
		        {
					fadingStep	: 0.1,
					fadingType	: euFIXED,
					link		: "javascript:ToggleOptions();"
				});

			dock.addIcon(new Array(
				{euImage:{image : "../Themes/"+Theme+"/Dock_Config01.png"}},
		        {euLabel:{
					object	: {euImage:{image:"../Themes/"+Theme+"/Dock_Config01.png"}},
		            txt		: getText(euDock_Config),
//					style   : "background:#eeefff;border-style:solid;border-color:#9fb6b6;border-width:2px;",
		            style   : "font-size:16pt;",
				    anchor  : euDOWN,
		            offsetX : 0,
				    offsetY : -30}}),
		        {
					fadingStep	: 0.1,
					fadingType	: euFIXED,
					link		: "javascript:ToggleConfig();"
				});

			dock.addIcon(new Array(
				{euImage:{image : "../Themes/"+Theme+"/Dock_Network01.png"}},
		        {euLabel:{
					object	: {euImage:{image:"../Themes/"+Theme+"/Dock_Network01.png"}},
		            txt		: getText(euDock_Network),
//					style   : "background:#eeefff;border-style:solid;border-color:#9fb6b6;border-width:2px;",
		            style   : "font-size:16pt;",
				    anchor  : euDOWN,
		            offsetX : 0,
				    offsetY : -30}}),
		        {
					fadingStep	: 0.1,
					fadingType	: euFIXED,
					link		: "javascript:ToggleNetwork();"
				});

			dock.addIcon(new Array(
				{euImage:{image : "../Themes/"+Theme+"/Dock_Theme01.png"}},
		        {euLabel:{
					object	: {euImage:{image:"../Themes/"+Theme+"/Dock_Theme01.png"}},
		            txt		: getText(euDock_Theme),
//					style   : "background:#eeefff;border-style:solid;border-color:#9fb6b6;border-width:2px;",
		            style   : "font-size:16pt;",
				    anchor  : euDOWN,
		            offsetX : 0,
				    offsetY : -30}}),
		        {
					fadingStep	: 0.1,
					fadingType	: euFIXED,
					link		: "javascript:ToggleTheme();"
				});

			dock.addIcon(new Array(
				{euImage:{image : "../Themes/"+Theme+"/Dock_Information01.png"}},
		        {euLabel:{
					object	: {euImage:{image:"../Themes/"+Theme+"/Dock_Information01.png"}},
		            txt		: getText(euDock_Information),
//					style   : "background:#eeefff;border-style:solid;border-color:#9fb6b6;border-width:2px;",
		            style   : "font-size:16pt;",
				    anchor  : euDOWN,
		            offsetX : 0,
				    offsetY : -30}}),
		        {
					fadingStep	: 0.1,
					fadingType	: euFIXED,
					link		: "javascript:ToggleInformation();"
				});

			dock.addIcon(new Array(
				{euImage:{image : "../Themes/"+Theme+"/Dock_Manual01.png"}},
		        {euLabel:{
					object	: {euImage:{image:"../Themes/"+Theme+"/Dock_Manual01.png"}},
		            txt		: getText(euDock_Manual),
//					style   : "background:#eeefff;border-style:solid;border-color:#9fb6b6;border-width:2px;",
		            style   : "font-size:16pt;",
				    anchor  : euDOWN,
		            offsetX : 0,
				    offsetY : -30}}),
		        {
					fadingStep	: 0.1,
					fadingType	: euFIXED,
					link		: "javascript:ToggleManual();"
				});

			dock.addIcon(new Array(
				{euImage:{image : "../Themes/"+Theme+"/Dock_About01.png"}},
		        {euLabel:{
					object	: {euImage:{image:"../Themes/"+Theme+"/Dock_About01.png"}},
		            txt		: getText(euDock_About),
//					style   : "background:#eeefff;border-style:solid;border-color:#9fb6b6;border-width:2px;",
		            style   : "font-size:16pt;",
				    anchor  : euDOWN,
		            offsetX : 0,
				    offsetY : -30}}),
		        {
					fadingStep	: 0.1,
					fadingType	: euFIXED,
					link		: "javascript:ToggleAboutWPI();"
				});
		}
    }

	dock.addIcon(new Array(
		{euImage:{image : "../Themes/"+Theme+"/Dock_Exit01.png"}},
        {euLabel:{
			object	: {euImage:{image:"../Themes/"+Theme+"/Dock_Exit01.png"}},
			txt		: getText(euDock_Exit),
//			style   : "background:#eeefff;border-style:solid;border-color:#9fb6b6;border-width:2px;",
			style   : "font-size:16pt;",
		    anchor  : euDOWN,
			offsetX : 0,
			offsetY : -30}}),
		{
			fadingStep	: 0.1,
			fadingType	: euFIXED,
			link		: "javascript:checkInstall('exit');"
		});
