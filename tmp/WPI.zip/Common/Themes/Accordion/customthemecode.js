function SetupTheme()
{
	position="customthemecode.js";
	whatfunc="SetupTheme()";

	document.getElementById("bgpiclayer").style.backgroundColor=Theme_BGColor;

	if (Theme_BackgroundRepeat.toLowerCase() != "stretch")
	{
	    if (BgPicture != '' && FileExists(wpipath+"\\Graphics\\"+BgPicture))
			document.getElementById("bgpiclayer").style.backgroundImage='url("../Graphics/'+BgPicture+'")';
		else
		{
			if (FileExists(wpipath+"\\Themes\\"+Theme+"\\Wallpaper.jpg"))
				document.getElementById("bgpiclayer").style.backgroundImage='url("../Themes/'+Theme+'/Wallpaper.jpg")';
			if (FileExists(wpipath+"\\Themes\\"+Theme+"\\Wallpaper.png"))
				document.getElementById("bgpiclayer").style.backgroundImage='url("../Themes/'+Theme+'/Wallpaper.png")';
		}
		
		document.getElementById("bgpiclayer").style.backgroundRepeat=Theme_BackgroundRepeat;
		document.getElementById("bgpiclayer").style.backgroundPosition=Theme_BackgroundPosition;
	}


	document.getElementById("div_logo").style.width=Theme_LogoImageWidth+"px";
	document.getElementById("div_logo").style.height=Theme_LogoImageHeight+"px";
	document.getElementById("div_logo").style.right=Theme_LogoImageRight+"px";
	document.getElementById("div_logo").style.bottom=Theme_LogoImageBottom+"px";
	document.getElementById("div_logo").style.visibility="visible";


	MainNavAccordion = new dhtmlXAccordion("accordMain","dhx_skyblue");
	MainNavAccordion.setIconsPath("../Themes/"+Theme+"/");
	MainNavAccordion.setSizes();

	MainNavAccordion.addItem("a1", getText(lblApplications));
	MainNavAccordion.addItem("a2", getText(lblWizards));
	MainNavAccordion.addItem("a3", getText(lblHelp));

	MainNavAccordion.cells("a1").setIcon("Applications.png");
	MainNavAccordion.cells("a2").setIcon("Wizards.png");
	MainNavAccordion.cells("a3").setIcon("Help.png");

	MainNavAccordion.cells("a1").attachObject("a1Guts");
	MainNavAccordion.cells("a2").attachObject("a2Guts");
	MainNavAccordion.cells("a3").attachObject("a3Guts");

	MainNavAccordion.cells("a1").open();

	MainNavAccordion.setEffect(true);


	if (Configurations.length>0)
	{
		for (var i=0; i<Configurations.length; i++)
		{
			var objDiv=document.getElementById("configsDIV");
			var newDiv=document.createElement("div");
			newDiv.style.padding="0 0 4 0";

			var txt='<a class="accordLinkText" href; onMouseOver="DoMouseOver(\'configsbutton'+i+'\',1);" onMouseDown="DoMouseDown(\'configsbutton'+i+'\',1); htm();" onMouseOut="DoMouseOut(\'configsbutton'+i+'\',1);" onClick="check(\''+Configurations[i]+'\');">';
			txt +='<img id="configsbutton'+i+'" src="" align="absbottom" border="0"><br>'+Configurations[i]+'</a>';

			newDiv.innerHTML=txt;
			objDiv.appendChild(newDiv);

	        SetThemeImage("configsbutton"+i,"Check.png");
		}
	}


	FillInPathBox(configFile);

	FillInNumItems();

	SetUserInfo();

	document.getElementById("WPI_Version").innerHTML=ShortVersion;
}
